static const int th_len[] = {
  50, 30, 13, 166, 28, 32, 45, 95, 74, 53, 
};
static const int th_begin[] = {
  0, 50, 80, 93, 259, 287, 319, 364, 459, 533, 
};
static const float threshold[] = {
  1.0133762, 1.3857973, 1.4269438, 1.4819334, 1.4831469, 1.7455714, 1.8719811, 
  1.9040995, 1.9985417, 2.0501423, 2.0724814, 2.7220669, 2.7612932, 2.8236852, 
  2.8961425, 3.534771, 3.6537354, 3.8416142, 4.1242771, 4.3392076, 4.4799981, 
  5.2143683, 5.256906, 6.0529432, 6.0734386, 6.3864751, 6.4018564, 6.6726718, 
  6.7193065, 6.7556982, 6.9504814, 7.0894871, 7.2389922, 7.4374428, 7.4496298, 
  7.6566401, 7.7818065, 7.7833424, 9.0385056, 10.116214, 10.598005, 10.59855, 
  13.429989, 14.150509, 14.188652, 14.916195, 14.982363, 14.990356, 16.556215, 
  16.663128, 11.5, 15.5, 16.5, 17.5, 18.5, 19.5, 20.5, 21.5, 22.5, 23.5, 24.5, 
  25.5, 26, 26.5, 27.5, 28.5, 29.5, 30.5, 33.5, 34.5, 35.5, 36.5, 38, 39.5, 
  40.5, 41.5, 43.5, 44.5, 45.5, 46.5, 4.5, 6.5, 7.5, 8.5, 9.5, 10.5, 11.5, 
  12.5, 13.5, 14.5, 15.5, 16.5, 17.5, 38223.664, 38427.918, 38436.25, 
  38444.836, 38476.168, 38519.336, 38629.75, 38744.414, 39266.5, 39572.664, 
  39601.586, 39696, 39820.086, 40030.914, 40054.918, 40102.25, 40110.668, 
  40190.664, 40291.25, 40512.914, 40542.75, 40573.5, 40581.086, 40638.664, 
  40662.164, 40705.086, 42004.164, 42110.164, 42144.586, 42193.75, 42315.836, 
  42338.5, 42342.332, 42347.336, 42378.168, 42378.914, 42386.664, 42593.5, 
  42597.25, 42890.5, 42909.164, 42919.25, 42928.418, 42960.5, 42962.664, 
  42965.086, 42967.75, 42973, 42978.414, 42983.5, 42999.414, 43020.25, 
  43032.082, 43089.164, 43121.086, 43130.25, 43142.664, 43579.086, 43811.168, 
  43988.418, 46165.5, 46168.75, 46674.668, 46675.836, 48385.5, 48412.75, 
  48488.336, 48488.75, 48506.836, 48536.25, 48538.914, 48869.164, 48926.914, 
  49033.75, 49077.914, 49091.5, 49114.75, 49174.25, 49175.75, 49211.25, 
  49315.414, 49367, 49380, 50361.5, 50829.914, 51040.832, 51041.25, 51158.664, 
  51237.336, 51257.25, 52218.332, 52374.418, 52425.668, 52494.336, 52509.5, 
  52705.836, 52979.75, 52986.5, 53032.332, 53041.164, 53226.086, 53459.414, 
  53522.918, 53681.164, 53982.586, 54153.336, 54658.414, 54777.414, 54936, 
  54944.664, 54989.75, 55006.5, 55034.164, 55215.914, 55228, 55247.75, 
  55252.75, 55438.582, 55463.5, 55467.582, 55469.75, 55471.414, 55571.336, 
  55693.168, 55739.25, 56156.914, 56221.664, 56575.086, 56884.168, 57010.668, 
  57109.664, 57171.586, 57387.086, 57434.164, 57512, 57609.75, 57618.75, 
  57715.414, 57858.164, 57858.75, 57860.25, 57863.75, 57867.664, 57869.25, 
  57892.582, 57904, 57907.5, 57908.332, 58053, 58080.668, 58106.25, 58213.082, 
  58371.25, 58422.418, 58427, 58589.164, 58975.086, 59092.086, 59649.5, 
  59799.918, 60107.836, 61624.164, 61638.75, 63247.75, 63564.582, 64980.75, 
  0.08203125, 0.09765625, 0.13671875, 0.48828125, 0.5390625, 0.56640625, 
  0.57421875, 0.58203125, 0.58984375, 0.61328125, 0.62109375, 0.62890625, 
  0.64453125, 0.65625, 0.66015625, 0.68359375, 0.73828125, 0.75390625, 
  0.76171875, 0.76953125, 0.78515625, 0.80078125, 0.81640625, 0.83984375, 
  0.84375, 0.87109375, 0.87890625, 0.91015625, -0.48442966, -0.10097416, 
  8.0514263e-05, 0.12402178, 0.34150475, 0.41337216, 0.41340184, 0.41567713, 
  0.43360233, 0.47131458, 0.56734669, 0.58185899, 0.62864703, 0.70401257, 
  0.70973194, 0.71608543, 0.76401591, 0.7661218, 0.81129378, 0.82867074, 
  0.87512326, 0.89075083, 0.90350568, 0.90580904, 0.9149735, 0.93217611, 
  0.933599, 0.93582463, 0.95368659, 0.95442021, 0.97933555, 0.98412246, 
  0.026881585, 0.06037489, 0.17098659, 0.2994284, 0.32727331, 0.3292231, 
  0.34817049, 0.3598029, 0.3618004, 0.38221502, 0.39393532, 0.42228758, 
  0.42952609, 0.47350454, 0.49330762, 0.51276547, 0.5707078, 0.57873166, 
  0.59175217, 0.60564721, 0.61664677, 0.62923443, 0.65276605, 0.65633094, 
  0.65828425, 0.67313194, 0.67759407, 0.67857659, 0.67932439, 0.6816659, 
  0.69496322, 0.70433736, 0.70769101, 0.72092324, 0.73229623, 0.73983908, 
  0.74634176, 0.77473974, 0.79429287, 0.82564437, 0.83258814, 0.8661983, 
  0.88233954, 0.89323485, 0.93844271, 0.52452803, 0.61206067, 0.69835722, 
  0.69891709, 0.69988704, 0.87344176, 0.88730133, 0.91340744, 1.0746858, 
  1.1182585, 1.1207601, 1.1240551, 1.1762288, 1.1987727, 1.208467, 1.2641263, 
  1.267345, 1.343154, 1.3460705, 1.4159675, 1.4215848, 1.4239693, 1.4241045, 
  1.4481304, 1.45837, 1.5356817, 1.5622704, 1.5646319, 1.5658594, 1.5765674, 
  1.5831909, 1.5856602, 1.6029475, 1.6077334, 1.6132669, 1.6493546, 1.7289193, 
  1.7298434, 1.7331947, 1.7358749, 1.7444521, 1.7490606, 1.7499223, 1.7660329, 
  1.7915938, 1.7962813, 1.8165548, 1.8193693, 1.8199024, 1.8420799, 1.8425919, 
  1.8438309, 1.8606105, 1.8702013, 1.8710251, 1.8713291, 1.8721454, 1.8736832, 
  1.8851622, 1.8858354, 1.889482, 1.8954086, 1.8960409, 1.9224164, 1.927876, 
  1.9281662, 1.9395951, 1.9412969, 1.9415832, 1.9481568, 1.9499364, 1.9552248, 
  1.9751372, 1.980921, 1.9834358, 2.0074396, 2.0094342, 2.0124784, 2.0222645, 
  2.0241079, 2.0382149, 2.0466995, 2.0520449, 2.0538778, 2.0649133, 2.0700319, 
  2.0990455, 2.1101437, 2.1166947, 2.1173041, 2.137228, 2.1698403, 2.1790295, 
  2.2240114, 2.237201, 0.92118788, 1.1207027, 1.1438389, 1.1494443, 1.2544897, 
  1.3902445, 1.4174745, 1.4814873, 1.531518, 1.5581944, 1.5599304, 1.575822, 
  1.6655328, 1.755, 1.8525789, 2.0260885, 2.1210494, 2.1729412, 2.1757691, 
  2.218533, 2.5057392, 2.7748542, 3.16992, 3.1935287, 3.5433674, 4.0550532, 
  4.9191332, 5.2445745, 5.2526388, 5.3596878, 5.3738775, 5.7931366, 5.8343191, 
  7.2542439, 7.3427587, 7.4773722, 7.6437287, 7.6471052, 7.7297506, 9.2592831, 
  9.5952206, 10.846271, 11.594856, 11.951736, 12.588888, 12.626787, 14.053047, 
  16.371529, 18.243557, 18.297127, 19.849491, 21.697777, 22.047527, 25.585985, 
  33.012756, 39.409687, 44.430161, 44.46875, 45.68998, 46.98, 55.696327, 
  64.876419, 69.893677, 96.092896, 101.54973, 167.77431, 292.73871, 317.29428, 
  415.02307, 420.28278, 462.02802, 190833.16, 195103.72, 271457.53, 0.08984375, 
  0.11328125, 0.16015625, 0.2265625, 0.27734375, 0.28515625, 0.2890625, 
  0.32421875, 0.33203125, 0.34765625, 0.3515625, 0.37890625, 0.41015625, 
  0.41796875, 0.42578125, 0.43359375, 0.44921875, 0.48828125, 0.51171875, 
  0.52734375, 0.56640625, 0.58984375, 0.6015625, 0.63671875, 0.64453125, 
  0.66796875, 0.67578125, 0.69140625, 0.70703125, 0.72265625, 0.73828125, 
  0.74609375, 0.75390625, 0.76171875, 0.78515625, 0.79296875, 0.80078125, 
  0.80859375, 0.81640625, 0.82421875, 0.83984375, 0.85546875, 0.86328125, 
  0.87109375, 0.87890625, 0.88671875, 0.89453125, 0.91796875, 0.94140625, 
  0.94921875, 0.95703125, 0.96484375, 0.97265625, 
};

#include <stdlib.h>

/*
 * \brief function to convert a feature value into bin index.
 * \param val feature value, in floating-point
 * \param fid feature identifier
 * \return bin index corresponding to given feature value
 */
static inline int quantize(float val, unsigned fid) {
  const size_t offset = th_begin[fid];
  const float* array = &threshold[offset];
  int len = th_len[fid];
  int low = 0;
  int high = len;
  int mid;
  float mval;
  // It is possible th_begin[i] == [total_num_threshold]. This means that
  // all features i, (i+1), ... are not used for any of the splits in the model.
  // So in this case, just return something
  if (offset == 586 || val < array[0]) {
    return -10;
  }
  while (low + 1 < high) {
    mid = (low + high) / 2;
    mval = array[mid];
    if (val == mval) {
      return mid * 2;
    } else if (val < mval) {
      high = mid;
    } else {
      low = mid;
    }
  }
  if (array[low] == val) {
    return low * 2;
  } else if (high == len) {
    return len * 2;
  } else {
    return low * 2 + 1;
  }
}

#include "header.h"

const unsigned char is_categorical[] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
};

size_t get_num_output_group(void) {
  return 1;
}

size_t get_num_feature(void) {
  return 10;
}

const char* get_pred_transform(void) {
  return "sigmoid";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_global_bias(void) {
  return -0.0;
}

static inline float pred_transform(float margin) {
  const float alpha = (float)1.0;
  return 1.0f / (1 + expf(-alpha * margin));
}
float predict(union Entry* data, int pred_margin) {

  for (int i = 0; i < 10; ++i) {
    if (data[i].missing != -1 && !is_categorical[i]) {
      data[i].qvalue = quantize(data[i].fvalue, i);
    }
  }
  float sum = 0.0f;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if (!(data[0].missing != -1) || (data[0].qvalue < 48)) {
    if (!(data[8].missing != -1) || (data[8].qvalue < 46)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 52)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 20)) {
            sum += (float)0.49565216899;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 74)) {
              sum += (float)-0.32307696342;
            } else {
              sum += (float)0.33333337307;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 288)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 56)) {
              sum += (float)-0.22666667402;
            } else {
              sum += (float)-0.54339623451;
            }
          } else {
            sum += (float)0.20000001788;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 148)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 76)) {
              sum += (float)0.52941179276;
            } else {
              sum += (float)0.30000001192;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 104)) {
              sum += (float)-0.27804878354;
            } else {
              sum += (float)0.40800002217;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 34)) {
              sum += (float)-0;
            } else {
              sum += (float)0.30000001192;
            }
          } else {
            sum += (float)0.57530868053;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
        sum += (float)0.57391309738;
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 68)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 40)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 36)) {
              sum += (float)-0.44842106104;
            } else {
              sum += (float)0.047482017428;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 48)) {
              sum += (float)-0.37777778506;
            } else {
              sum += (float)-0.56589502096;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 54)) {
              sum += (float)-0.51978611946;
            } else {
              sum += (float)0.44000002742;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
              sum += (float)-0.045783132315;
            } else {
              sum += (float)0.49615386128;
            }
          }
        }
      }
    }
  } else {
    if (!(data[8].missing != -1) || (data[8].qvalue < 120)) {
      if (!(data[9].missing != -1) || (data[9].qvalue < 58)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 142)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 272)) {
              sum += (float)0.31200000644;
            } else {
              sum += (float)-0.36923080683;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 54)) {
              sum += (float)-0.51724141836;
            } else {
              sum += (float)-0.24705883861;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
            sum += (float)0.57037043571;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
              sum += (float)-0.085714295506;
            } else {
              sum += (float)0.40000003576;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 58)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 90)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)-0.15000000596;
            } else {
              sum += (float)0.52542376518;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 34)) {
              sum += (float)-0.30000001192;
            } else {
              sum += (float)0.066666670144;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
            sum += (float)0.59318959713;
          } else {
            sum += (float)0.15000000596;
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 84)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
          sum += (float)0.49565216899;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 58)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
              sum += (float)-0.54766356945;
            } else {
              sum += (float)0.13846154511;
            }
          } else {
            sum += (float)0.40000003576;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 92)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 180)) {
            sum += (float)-0.054545458406;
          } else {
            sum += (float)0.27272728086;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
            sum += (float)0.15000000596;
          } else {
            sum += (float)0.54782611132;
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 46)) {
    if (!(data[8].missing != -1) || (data[8].qvalue < 46)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 80)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 16)) {
            sum += (float)0.38145047426;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 74)) {
              sum += (float)-0.3285921514;
            } else {
              sum += (float)0.21072563529;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 44)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
              sum += (float)-0.42796519399;
            } else {
              sum += (float)-0.044163879007;
            }
          } else {
            sum += (float)0.13839039207;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 26)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 36)) {
              sum += (float)0.094490900636;
            } else {
              sum += (float)0.42560124397;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 158)) {
              sum += (float)0.16448009014;
            } else {
              sum += (float)-0.28367471695;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 186)) {
            sum += (float)0.43233910203;
          } else {
            sum += (float)0.13181173801;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 10)) {
        sum += (float)0.44054171443;
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 54)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 80)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 90)) {
              sum += (float)-0.33508783579;
            } else {
              sum += (float)-0.43886774778;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
              sum += (float)-0.3833090663;
            } else {
              sum += (float)0.17529965937;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 34)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 82)) {
              sum += (float)0.15858179331;
            } else {
              sum += (float)-0.37335035205;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)-0.29848018289;
            } else {
              sum += (float)0.4463429451;
            }
          }
        }
      }
    }
  } else {
    if (!(data[8].missing != -1) || (data[8].qvalue < 118)) {
      if (!(data[9].missing != -1) || (data[9].qvalue < 62)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 92)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 262)) {
              sum += (float)0.3805449605;
            } else {
              sum += (float)-0.17631575465;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 8)) {
              sum += (float)0.090284027159;
            } else {
              sum += (float)-0.38175961375;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 166)) {
              sum += (float)0.44234496355;
            } else {
              sum += (float)0.1273342669;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
              sum += (float)0.38622406125;
            } else {
              sum += (float)-0.12751117349;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 66)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 72)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)-0.043966073543;
            } else {
              sum += (float)0.42626214027;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
              sum += (float)-0.04455191642;
            } else {
              sum += (float)0.27627429366;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 110)) {
            sum += (float)0.46142607927;
          } else {
            sum += (float)0.14339630306;
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 84)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
          sum += (float)0.40661433339;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 56)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
              sum += (float)-0.40757057071;
            } else {
              sum += (float)0.11011419445;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 40)) {
              sum += (float)0.064682580531;
            } else {
              sum += (float)0.32548210025;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 90)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 46)) {
            sum += (float)0.2664937675;
          } else {
            sum += (float)-0.10655981302;
          }
        } else {
          sum += (float)0.42479851842;
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 46)) {
    if (!(data[9].missing != -1) || (data[9].qvalue < 60)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 18)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
            sum += (float)-0.027664167807;
          } else {
            sum += (float)-0.39668276906;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 14)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 82)) {
              sum += (float)0.061390761286;
            } else {
              sum += (float)0.36813461781;
            }
          } else {
            sum += (float)0.71614176035;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 42)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 80)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
              sum += (float)0.028741041198;
            } else {
              sum += (float)0.45728126168;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 44)) {
              sum += (float)-0.30958545208;
            } else {
              sum += (float)0.084119014442;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 230)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)-0.3913551271;
            } else {
              sum += (float)-0.27689445019;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 76)) {
              sum += (float)-0.17981955409;
            } else {
              sum += (float)-0.39728587866;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 66)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 10)) {
              sum += (float)0.23556345701;
            } else {
              sum += (float)-0.29539054632;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 30)) {
              sum += (float)-0.15695235133;
            } else {
              sum += (float)0.46741491556;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 50)) {
              sum += (float)-0.40863281488;
            } else {
              sum += (float)-0.06543391943;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 76)) {
              sum += (float)0.11834177375;
            } else {
              sum += (float)-0.31501507759;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 126)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 8)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
              sum += (float)-0.15220604837;
            } else {
              sum += (float)0.37580442429;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 10)) {
              sum += (float)0.32510226965;
            } else {
              sum += (float)0.44805178046;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 94)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 54)) {
              sum += (float)0.39385709167;
            } else {
              sum += (float)-0.18208603561;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 54)) {
              sum += (float)-0.1366186589;
            } else {
              sum += (float)0.35356476903;
            }
          }
        }
      }
    }
  } else {
    if (!(data[8].missing != -1) || (data[8].qvalue < 120)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 88)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 54)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 48)) {
            sum += (float)0.11391591281;
          } else {
            sum += (float)0.39993530512;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 120)) {
              sum += (float)0.22273531556;
            } else {
              sum += (float)-0.25544336438;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 58)) {
              sum += (float)0.056615907699;
            } else {
              sum += (float)0.36552938819;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 226)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
              sum += (float)0.23978820443;
            } else {
              sum += (float)-0.23185744882;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
              sum += (float)-0.43843394518;
            } else {
              sum += (float)-0.10586383194;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
              sum += (float)0.38994604349;
            } else {
              sum += (float)0.25430676341;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 56)) {
              sum += (float)-0.034492123872;
            } else {
              sum += (float)0.3523862958;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 84)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
          sum += (float)0.33564814925;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 58)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
              sum += (float)-0.3510633707;
            } else {
              sum += (float)0.088030278683;
            }
          } else {
            sum += (float)0.29772475362;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 50)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 4)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 46)) {
              sum += (float)0.33278551698;
            } else {
              sum += (float)0.010863559321;
            }
          } else {
            sum += (float)-0.20986768603;
          }
        } else {
          sum += (float)0.38022130728;
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 52)) {
    if (!(data[9].missing != -1) || (data[9].qvalue < 60)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 78)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 162)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 60)) {
              sum += (float)0.29481160641;
            } else {
              sum += (float)-0.28020036221;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 12)) {
              sum += (float)-0.19248448312;
            } else {
              sum += (float)0.53469961882;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 50)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
              sum += (float)-0.30854770541;
            } else {
              sum += (float)0.40378856659;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 44)) {
              sum += (float)-0.15643301606;
            } else {
              sum += (float)0.50338858366;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 42)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 122)) {
              sum += (float)0.12654276192;
            } else {
              sum += (float)-0.35596713424;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 84)) {
              sum += (float)-0.10707647353;
            } else {
              sum += (float)0.45745313168;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 40)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 148)) {
              sum += (float)-0.28710541129;
            } else {
              sum += (float)-0.35870432854;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
              sum += (float)-0.32784205675;
            } else {
              sum += (float)-0.11582245678;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 134)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 6)) {
              sum += (float)0.13859431446;
            } else {
              sum += (float)-0.34191760421;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 78)) {
              sum += (float)0.42247000337;
            } else {
              sum += (float)0.00017521927657;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 2)) {
            sum += (float)0.090498566628;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 194)) {
              sum += (float)-0.36199784279;
            } else {
              sum += (float)-0.25556412339;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 154)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 10)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
              sum += (float)0.15914903581;
            } else {
              sum += (float)-0.44973108172;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 246)) {
              sum += (float)0.34692782164;
            } else {
              sum += (float)0.15694998205;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 100)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 30)) {
              sum += (float)-0.23873659968;
            } else {
              sum += (float)0.043838277459;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 48)) {
              sum += (float)0.037531860173;
            } else {
              sum += (float)0.37981292605;
            }
          }
        }
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 46)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 62)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 250)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 36)) {
              sum += (float)0.2478621155;
            } else {
              sum += (float)-0.094149924815;
            }
          } else {
            sum += (float)-0.33214756846;
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 10)) {
            sum += (float)0.024826889858;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 0)) {
              sum += (float)0.086354523897;
            } else {
              sum += (float)0.41748002172;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 94)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 58)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 40)) {
              sum += (float)0.13100421429;
            } else {
              sum += (float)-0.3331682384;
            }
          } else {
            sum += (float)0.26434645057;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 0)) {
            sum += (float)0.043665193021;
          } else {
            sum += (float)0.31813192368;
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 54)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          sum += (float)0.10934084654;
        } else {
          sum += (float)0.36527776718;
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 312)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 172)) {
              sum += (float)0.33583426476;
            } else {
              sum += (float)0.041775800288;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
              sum += (float)-0.0032326334622;
            } else {
              sum += (float)0.32839256525;
            }
          }
        } else {
          sum += (float)-0.42842537165;
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 52)) {
    if (!(data[9].missing != -1) || (data[9].qvalue < 82)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 98)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 28)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 158)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
              sum += (float)-0.18628913164;
            } else {
              sum += (float)0.32839912176;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 144)) {
              sum += (float)-0.3244510591;
            } else {
              sum += (float)0.27204295993;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 52)) {
              sum += (float)0.061510819942;
            } else {
              sum += (float)-0.31474113464;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 248)) {
              sum += (float)0.27471292019;
            } else {
              sum += (float)-0.12863007188;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 4)) {
          sum += (float)0.2883054018;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 40)) {
              sum += (float)-0.035454448313;
            } else {
              sum += (float)-0.33953535557;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 40)) {
              sum += (float)-0.30714166164;
            } else {
              sum += (float)-0.19538164139;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 84)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            sum += (float)-0.010078351945;
          } else {
            sum += (float)0.30382299423;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 86)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
              sum += (float)0.047444425523;
            } else {
              sum += (float)-0.32084834576;
            }
          } else {
            sum += (float)0.069820605218;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 178)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 70)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 36)) {
              sum += (float)-0.084654800594;
            } else {
              sum += (float)0.23440770805;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
              sum += (float)0.21654237807;
            } else {
              sum += (float)0.40013003349;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 174)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 136)) {
              sum += (float)0.10409548879;
            } else {
              sum += (float)-0.45776364207;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 64)) {
              sum += (float)0.36053824425;
            } else {
              sum += (float)-0.085023649037;
            }
          }
        }
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 42)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 88)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 62)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 132)) {
              sum += (float)0.18362398446;
            } else {
              sum += (float)-0.25483807921;
            }
          } else {
            sum += (float)0.40117257833;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 58)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 44)) {
              sum += (float)0.083953857422;
            } else {
              sum += (float)-0.33290719986;
            }
          } else {
            sum += (float)0.23478342593;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
          sum += (float)0.31245115399;
        } else {
          sum += (float)0.034991767257;
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 70)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 96)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 4)) {
              sum += (float)-0.33102801442;
            } else {
              sum += (float)0.12625488639;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 48)) {
              sum += (float)0.34364560246;
            } else {
              sum += (float)0.18254062533;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 116)) {
              sum += (float)-0.45297569036;
            } else {
              sum += (float)-0.096865102649;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
              sum += (float)0.33901655674;
            } else {
              sum += (float)0.084842644632;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 72)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 62)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)-0.13300070167;
            } else {
              sum += (float)0.3121534884;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
              sum += (float)-0.13306158781;
            } else {
              sum += (float)0.30284899473;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 108)) {
            sum += (float)0.34346434474;
          } else {
            sum += (float)0.089023172855;
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 50)) {
    if (!(data[9].missing != -1) || (data[9].qvalue < 50)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 154)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
              sum += (float)-0.26010069251;
            } else {
              sum += (float)0.36747506261;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 24)) {
              sum += (float)0.050387967378;
            } else {
              sum += (float)-0.30581885576;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 16)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 92)) {
              sum += (float)0.12534120679;
            } else {
              sum += (float)-0.25626096129;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 126)) {
              sum += (float)0.030191946775;
            } else {
              sum += (float)0.416041255;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 44)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 24)) {
              sum += (float)-0.25657686591;
            } else {
              sum += (float)0.0013856443111;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 68)) {
              sum += (float)-0.022342793643;
            } else {
              sum += (float)-0.30621930957;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 128)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 20)) {
              sum += (float)0.04518340528;
            } else {
              sum += (float)0.56236201525;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 36)) {
              sum += (float)0.21535077691;
            } else {
              sum += (float)-0.27682065964;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 56)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 28)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 30)) {
              sum += (float)-0.010995094664;
            } else {
              sum += (float)-0.29322907329;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
              sum += (float)0.009811937809;
            } else {
              sum += (float)0.37431618571;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 2)) {
            sum += (float)0.32640016079;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)-0.32683482766;
            } else {
              sum += (float)-0.19425596297;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 154)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 18)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 34)) {
              sum += (float)0.27805832028;
            } else {
              sum += (float)-0.22717607021;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 70)) {
              sum += (float)0.36679205298;
            } else {
              sum += (float)0.16383431852;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 98)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 22)) {
              sum += (float)0.33867821097;
            } else {
              sum += (float)-0.12778431177;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 42)) {
              sum += (float)-0.098776809871;
            } else {
              sum += (float)0.28121650219;
            }
          }
        }
      }
    }
  } else {
    if (!(data[8].missing != -1) || (data[8].qvalue < 102)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 54)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          sum += (float)0.07251804322;
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 64)) {
              sum += (float)0.09698074311;
            } else {
              sum += (float)0.332028687;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
              sum += (float)-0.074160814285;
            } else {
              sum += (float)0.29572552443;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 102)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 8)) {
              sum += (float)-0.13991516829;
            } else {
              sum += (float)0.29428428411;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 28)) {
              sum += (float)-0.15876111388;
            } else {
              sum += (float)0.24435459077;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 60)) {
            sum += (float)0.036335080862;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 70)) {
              sum += (float)0.10596742481;
            } else {
              sum += (float)0.31796884537;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 280)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 64)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
              sum += (float)-0.079226702452;
            } else {
              sum += (float)0.27517619729;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)0.28199660778;
            } else {
              sum += (float)-0.21196205914;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
            sum += (float)-0.060578465462;
          } else {
            sum += (float)-0.33715322614;
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 138)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 20)) {
              sum += (float)0.33413779736;
            } else {
              sum += (float)0.014436398633;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 52)) {
              sum += (float)-0.079368971288;
            } else {
              sum += (float)0.31783288717;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 214)) {
            sum += (float)-0.033739246428;
          } else {
            sum += (float)-0.2719334662;
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 54)) {
    if (!(data[9].missing != -1) || (data[9].qvalue < 50)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 154)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 160)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 60)) {
              sum += (float)0.081672638655;
            } else {
              sum += (float)-0.25689223409;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 32)) {
              sum += (float)-0.32499438524;
            } else {
              sum += (float)-0.051578465849;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 144)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 10)) {
              sum += (float)-0.16436111927;
            } else {
              sum += (float)0.25293567777;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 128)) {
              sum += (float)-0.17909607291;
            } else {
              sum += (float)0.31986665726;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 44)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 56)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 78)) {
              sum += (float)0.080479472876;
            } else {
              sum += (float)-0.25631651282;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 24)) {
              sum += (float)-0.11325259507;
            } else {
              sum += (float)0.29248550534;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 34)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 146)) {
              sum += (float)-0.30219390988;
            } else {
              sum += (float)0.077969826758;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
              sum += (float)-0.27209383249;
            } else {
              sum += (float)-0.122345604;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 4)) {
            sum += (float)0.05236691609;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 50)) {
              sum += (float)-0.31352967024;
            } else {
              sum += (float)-0.044006008655;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 58)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
              sum += (float)0.0026218248531;
            } else {
              sum += (float)0.33784127235;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 170)) {
              sum += (float)-0.31902649999;
            } else {
              sum += (float)-0.0085293864831;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 132)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 76)) {
              sum += (float)0.016924904659;
            } else {
              sum += (float)0.31638592482;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 80)) {
              sum += (float)0.20469580591;
            } else {
              sum += (float)0.39174479246;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 24)) {
            sum += (float)-0.39287409186;
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 90)) {
              sum += (float)-0.010012623854;
            } else {
              sum += (float)0.22915749252;
            }
          }
        }
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 64)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 68)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 274)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
              sum += (float)-0.082925245166;
            } else {
              sum += (float)0.25490748882;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
              sum += (float)-0.29162201285;
            } else {
              sum += (float)0.11132474244;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 58)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
              sum += (float)0.22270227969;
            } else {
              sum += (float)-0.24382331967;
            }
          } else {
            sum += (float)0.28655433655;
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 132)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 76)) {
              sum += (float)0.036126196384;
            } else {
              sum += (float)0.32672309875;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 102)) {
              sum += (float)-0.18230713904;
            } else {
              sum += (float)0.20356141031;
            }
          }
        } else {
          sum += (float)-0.16421309114;
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 48)) {
        sum += (float)0.31866189837;
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 130)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 50)) {
              sum += (float)-0.1247170791;
            } else {
              sum += (float)0.25298374891;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 30)) {
              sum += (float)-0.36089617014;
            } else {
              sum += (float)0.14839178324;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 6)) {
            sum += (float)0.02473895438;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 68)) {
              sum += (float)0.10990658402;
            } else {
              sum += (float)0.29559502006;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 44)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
        sum += (float)0.11635296047;
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 70)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 12)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 94)) {
              sum += (float)-0.099424161017;
            } else {
              sum += (float)0.40635511279;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 88)) {
              sum += (float)0.099791176617;
            } else {
              sum += (float)-0.2740856111;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 330)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 146)) {
              sum += (float)-0.2618381381;
            } else {
              sum += (float)-0.30325266719;
            }
          } else {
            sum += (float)-0.016936015338;
          }
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 28)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 156)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 134)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 110)) {
              sum += (float)0.16113075614;
            } else {
              sum += (float)-0.21221585572;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 6)) {
              sum += (float)-0.17462061346;
            } else {
              sum += (float)0.50965607166;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 142)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 28)) {
              sum += (float)-0.045879822224;
            } else {
              sum += (float)-0.29841792583;
            }
          } else {
            sum += (float)0.30188646913;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 46)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 62)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 156)) {
              sum += (float)0.31950268149;
            } else {
              sum += (float)0.023180639371;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
              sum += (float)-0.12387565523;
            } else {
              sum += (float)0.200831756;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 106)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
              sum += (float)0.16962793469;
            } else {
              sum += (float)0.41231071949;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 48)) {
              sum += (float)-0.16105590761;
            } else {
              sum += (float)0.27898684144;
            }
          }
        }
      }
    }
  } else {
    if (!(data[8].missing != -1) || (data[8].qvalue < 74)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 30)) {
        sum += (float)0.31274276972;
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
          sum += (float)-0.23795072734;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 314)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 80)) {
              sum += (float)0.18876372278;
            } else {
              sum += (float)0.29494541883;
            }
          } else {
            sum += (float)-0.25255766511;
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 28)) {
          sum += (float)0.27689927816;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 84)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 50)) {
              sum += (float)-0.10051258653;
            } else {
              sum += (float)-0.53599399328;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 224)) {
              sum += (float)0.025753378868;
            } else {
              sum += (float)-0.2435413748;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 30)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 82)) {
              sum += (float)0.18299718201;
            } else {
              sum += (float)-0.21188041568;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 50)) {
              sum += (float)0.31467565894;
            } else {
              sum += (float)0.6399499774;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 86)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 54)) {
              sum += (float)-0.2063382566;
            } else {
              sum += (float)0.23082922399;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 96)) {
              sum += (float)0.085799299181;
            } else {
              sum += (float)0.29183506966;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 56)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 150)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 322)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 100)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
              sum += (float)-0.20242904127;
            } else {
              sum += (float)0.21372081339;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 18)) {
              sum += (float)-0.011727632023;
            } else {
              sum += (float)-0.2559979856;
            }
          }
        } else {
          sum += (float)0.22539812326;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 52)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 40)) {
              sum += (float)-0.18796226382;
            } else {
              sum += (float)0.28941902518;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 112)) {
              sum += (float)0.12480515987;
            } else {
              sum += (float)-0.29123592377;
            }
          }
        } else {
          sum += (float)-0.29616841674;
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 28)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 152)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 138)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 110)) {
              sum += (float)0.1126485467;
            } else {
              sum += (float)-0.1754988879;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
              sum += (float)-0.08107175678;
            } else {
              sum += (float)0.49430713058;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 142)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 42)) {
              sum += (float)-0.28996375203;
            } else {
              sum += (float)-0.13407668471;
            }
          } else {
            sum += (float)0.22228223085;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 118)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 18)) {
              sum += (float)0.31173783541;
            } else {
              sum += (float)-0.031122026965;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 244)) {
              sum += (float)0.33661729097;
            } else {
              sum += (float)0.13490313292;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
              sum += (float)-0.15285523236;
            } else {
              sum += (float)0.19519791007;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 72)) {
              sum += (float)-0.088439293206;
            } else {
              sum += (float)0.13067416847;
            }
          }
        }
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 64)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 94)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 270)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 122)) {
              sum += (float)0.21860559285;
            } else {
              sum += (float)0.022383227944;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
              sum += (float)-0.24839167297;
            } else {
              sum += (float)0.01477844175;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 58)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 30)) {
              sum += (float)0.1864335835;
            } else {
              sum += (float)-0.25813472271;
            }
          } else {
            sum += (float)0.25689890981;
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 132)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
            sum += (float)0.30465126038;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 44)) {
              sum += (float)0.19139444828;
            } else {
              sum += (float)-0.15884900093;
            }
          }
        } else {
          sum += (float)-0.12756358087;
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 64)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 184)) {
            sum += (float)-0.075782969594;
          } else {
            sum += (float)0.24493616819;
          }
        } else {
          sum += (float)0.3100913465;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 258)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 96)) {
              sum += (float)-0.12693105638;
            } else {
              sum += (float)0.24502760172;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 6)) {
              sum += (float)-0.41063827276;
            } else {
              sum += (float)0.096229754388;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 6)) {
            sum += (float)0.019349634647;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
              sum += (float)0.26977169514;
            } else {
              sum += (float)0.056580737233;
            }
          }
        }
      }
    }
  }
  if (!(data[9].missing != -1) || (data[9].qvalue < 80)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 138)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 242)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 206)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 64)) {
              sum += (float)0.17311605811;
            } else {
              sum += (float)-0.11765045673;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 14)) {
              sum += (float)-0.21865737438;
            } else {
              sum += (float)0.33553645015;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 58)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 52)) {
              sum += (float)-0.11207630485;
            } else {
              sum += (float)0.20876042545;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 318)) {
              sum += (float)-0.25864166021;
            } else {
              sum += (float)0.08792758733;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 52)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 72)) {
              sum += (float)-0.16759049892;
            } else {
              sum += (float)-0.28348374367;
            }
          } else {
            sum += (float)0.037535723299;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 116)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
              sum += (float)-0.24656783044;
            } else {
              sum += (float)-0.05860183388;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 146)) {
              sum += (float)-0.080336809158;
            } else {
              sum += (float)-0.27288517356;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 100)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 282)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
            sum += (float)-0.13281007111;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 26)) {
              sum += (float)0.19742955267;
            } else {
              sum += (float)0.41101810336;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 44)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 48)) {
              sum += (float)-0.24476422369;
            } else {
              sum += (float)0.040297258645;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
              sum += (float)-0.14690163732;
            } else {
              sum += (float)0.25781941414;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 26)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 128)) {
            sum += (float)0.13427245617;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 52)) {
              sum += (float)-0.26069843769;
            } else {
              sum += (float)0.080993205309;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 40)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 268)) {
              sum += (float)0.25376978517;
            } else {
              sum += (float)-0.20036394894;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 118)) {
              sum += (float)-0.39076605439;
            } else {
              sum += (float)0.0018992727855;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 62)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 186)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 68)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 46)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 40)) {
              sum += (float)-0.24834395945;
            } else {
              sum += (float)0.22778567672;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 32)) {
              sum += (float)0.18074125051;
            } else {
              sum += (float)0.42833903432;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 34)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 74)) {
              sum += (float)0.11671478301;
            } else {
              sum += (float)-0.30894392729;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
              sum += (float)-0.48274204135;
            } else {
              sum += (float)0.24947954714;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 236)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 192)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 66)) {
              sum += (float)-0.063819274306;
            } else {
              sum += (float)0.17783546448;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 36)) {
              sum += (float)0.18165542185;
            } else {
              sum += (float)0.4742616713;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 264)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 32)) {
              sum += (float)-0.24277538061;
            } else {
              sum += (float)0.15765666962;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 70)) {
              sum += (float)0.2891767323;
            } else {
              sum += (float)-0.028411095962;
            }
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 64)) {
          sum += (float)0.047792132944;
        } else {
          sum += (float)0.30548197031;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 254)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 24)) {
              sum += (float)0.23525635898;
            } else {
              sum += (float)-0.057749405503;
            }
          } else {
            sum += (float)-0.29326871037;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 94)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 34)) {
              sum += (float)0.28016290069;
            } else {
              sum += (float)-0.57291942835;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 174)) {
              sum += (float)0.30006277561;
            } else {
              sum += (float)0.060825780034;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 72)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
        sum += (float)0.22056061029;
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 170)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 168)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 326)) {
              sum += (float)-0.22581586242;
            } else {
              sum += (float)0.130623281;
            }
          } else {
            sum += (float)0.1483720392;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 32)) {
            sum += (float)-0.031718548387;
          } else {
            sum += (float)-0.28382751346;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 238)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 210)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 62)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
              sum += (float)-0.021972863004;
            } else {
              sum += (float)0.25138348341;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 116)) {
              sum += (float)0.019484536722;
            } else {
              sum += (float)-0.14950639009;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 24)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 140)) {
              sum += (float)-0.27060067654;
            } else {
              sum += (float)0.08387157321;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 52)) {
              sum += (float)0.19430656731;
            } else {
              sum += (float)0.59654927254;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 92)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 266)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 86)) {
              sum += (float)-0.15393212438;
            } else {
              sum += (float)0.22099123895;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 38)) {
              sum += (float)-0.060114409775;
            } else {
              sum += (float)0.22273014486;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 38)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 58)) {
              sum += (float)-0.15603204072;
            } else {
              sum += (float)0.18496914208;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 58)) {
              sum += (float)-0.24801768363;
            } else {
              sum += (float)-0.049054238945;
            }
          }
        }
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 66)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 98)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 26)) {
              sum += (float)-0.16989529133;
            } else {
              sum += (float)0.16386158764;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 28)) {
              sum += (float)-0.30825185776;
            } else {
              sum += (float)0.20570228994;
            }
          }
        } else {
          sum += (float)0.25637453794;
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 286)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 176)) {
            sum += (float)0.27879887819;
          } else {
            sum += (float)-0.015260030515;
          }
        } else {
          sum += (float)-0.014639129862;
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
        sum += (float)0.30432480574;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 16)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 94)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 46)) {
              sum += (float)0.28225362301;
            } else {
              sum += (float)-0.53700000048;
            }
          } else {
            sum += (float)0.29922753572;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 252)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 84)) {
              sum += (float)-0.016164042056;
            } else {
              sum += (float)0.25516372919;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 22)) {
              sum += (float)-0.50967460871;
            } else {
              sum += (float)0.1698141098;
            }
          }
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 28)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 74)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 74)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            sum += (float)0.053059782833;
          } else {
            sum += (float)0.31601214409;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 204)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 26)) {
              sum += (float)-0.45959019661;
            } else {
              sum += (float)-0.055625308305;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 14)) {
              sum += (float)0.21165473759;
            } else {
              sum += (float)-0.14551278949;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 24)) {
          sum += (float)0.29545646906;
        } else {
          sum += (float)0.03447990492;
        }
      }
    } else {
      sum += (float)0.29978612065;
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 170)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 168)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 328)) {
              sum += (float)-0.19488634169;
            } else {
              sum += (float)0.1296210736;
            }
          } else {
            sum += (float)0.10933516175;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 42)) {
            sum += (float)-0.018900569528;
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 92)) {
              sum += (float)-0.27783173323;
            } else {
              sum += (float)-0.070671416819;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 82)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 180)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
              sum += (float)-0.12566035986;
            } else {
              sum += (float)0.029649889097;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 316)) {
              sum += (float)-0.21672350168;
            } else {
              sum += (float)0.25131192803;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 178)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 130)) {
              sum += (float)0.0439613536;
            } else {
              sum += (float)-0.29089516401;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 240)) {
              sum += (float)0.30656570196;
            } else {
              sum += (float)0.033690586686;
            }
          }
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 14)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 48)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 36)) {
            sum += (float)-0.1019751057;
          } else {
            sum += (float)0.25641879439;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 222)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 168)) {
              sum += (float)-0.22594711185;
            } else {
              sum += (float)0.14417466521;
            }
          } else {
            sum += (float)-0.28168767691;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 36)) {
            sum += (float)0.30090263486;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 94)) {
              sum += (float)-0.42015630007;
            } else {
              sum += (float)0.091519191861;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)-0.089720770717;
            } else {
              sum += (float)0.10915099829;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 134)) {
              sum += (float)0.31791311502;
            } else {
              sum += (float)0.62879276276;
            }
          }
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 110)) {
        sum += (float)0.22072185576;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 34)) {
          sum += (float)0.064330846071;
        } else {
          sum += (float)-0.25501441956;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 44)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 184)) {
          sum += (float)0.29011961818;
        } else {
          sum += (float)0.086534947157;
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 76)) {
          sum += (float)-0.026594165713;
        } else {
          sum += (float)0.16039738059;
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 108)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 126)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 114)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 68)) {
              sum += (float)-0.10911176354;
            } else {
              sum += (float)0.26281806827;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 76)) {
              sum += (float)-0.29064121842;
            } else {
              sum += (float)-0.035592164844;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
            sum += (float)-0.17141081393;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
              sum += (float)0.11816267669;
            } else {
              sum += (float)0.58824145794;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 278)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 228)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 198)) {
              sum += (float)-0.23821729422;
            } else {
              sum += (float)0.056465100497;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
              sum += (float)-0.27817234397;
            } else {
              sum += (float)-0.088394761086;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 292)) {
            sum += (float)0.58231252432;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 104)) {
              sum += (float)0.11332101375;
            } else {
              sum += (float)-0.22225101292;
            }
          }
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 18)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 32)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 290)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 60)) {
              sum += (float)0.10038923472;
            } else {
              sum += (float)0.4172424376;
            }
          } else {
            sum += (float)-0.16785809398;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 220)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
              sum += (float)-0.27804148197;
            } else {
              sum += (float)-0.032551895827;
            }
          } else {
            sum += (float)-0.29866272211;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 140)) {
              sum += (float)0.21462900937;
            } else {
              sum += (float)-0.20731630921;
            }
          } else {
            sum += (float)0.32993030548;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 104)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 36)) {
              sum += (float)-0.066032342613;
            } else {
              sum += (float)-0.4819881618;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 142)) {
              sum += (float)0.23275302351;
            } else {
              sum += (float)-0.0046810959466;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 12)) {
    if (!(data[9].missing != -1) || (data[9].qvalue < 56)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 182)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 166)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
            sum += (float)0.19118511677;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
              sum += (float)0.068432606757;
            } else {
              sum += (float)-0.19166053832;
            }
          }
        } else {
          sum += (float)-0.39793294668;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
          sum += (float)-0.18182520568;
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 130)) {
            sum += (float)0.31143063307;
          } else {
            sum += (float)0.0094127198681;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 10)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 0)) {
          sum += (float)0.21890649199;
        } else {
          sum += (float)-0.15234650671;
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 100)) {
          sum += (float)0.28719303012;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 6)) {
            sum += (float)0.17065787315;
          } else {
            sum += (float)-0.10855287313;
          }
        }
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 18)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 156)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 30)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 140)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 88)) {
              sum += (float)0.19665639102;
            } else {
              sum += (float)-0.12285394222;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 8)) {
              sum += (float)-0.043460201472;
            } else {
              sum += (float)0.59944349527;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 86)) {
            sum += (float)0.01555744186;
          } else {
            sum += (float)-0.27042073011;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 34)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 136)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 26)) {
              sum += (float)-0.23223353922;
            } else {
              sum += (float)-0.018422879279;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 20)) {
              sum += (float)0.32757520676;
            } else {
              sum += (float)-0.032102417201;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 48)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 324)) {
              sum += (float)-0.26990005374;
            } else {
              sum += (float)0.059660337865;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 232)) {
              sum += (float)0.26593357325;
            } else {
              sum += (float)-0.17419454455;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 136)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 74)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 16)) {
              sum += (float)-0.18833760917;
            } else {
              sum += (float)0.010838214308;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)0.036843642592;
            } else {
              sum += (float)0.21523223817;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
            sum += (float)-0.19091890752;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
              sum += (float)0.13390786946;
            } else {
              sum += (float)0.32427331805;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 196)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
              sum += (float)-0.25150930882;
            } else {
              sum += (float)0.11663290113;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 202)) {
              sum += (float)0.68447071314;
            } else {
              sum += (float)-0.14361396432;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 96)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 32)) {
              sum += (float)-0.19517041743;
            } else {
              sum += (float)-0.012872596271;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
              sum += (float)-0.15571446717;
            } else {
              sum += (float)0.19451007247;
            }
          }
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 112)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 8)) {
          sum += (float)0.26402536035;
        } else {
          sum += (float)0.010428101756;
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 102)) {
          sum += (float)-0.35391491652;
        } else {
          sum += (float)0.25003480911;
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 72)) {
        sum += (float)0.086264126003;
      } else {
        sum += (float)0.29405093193;
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 0)) {
          sum += (float)-0.028228199109;
        } else {
          sum += (float)-0.29209160805;
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 284)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 86)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
              sum += (float)-0.14571101964;
            } else {
              sum += (float)0.11620717496;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
              sum += (float)0.057321362197;
            } else {
              sum += (float)-0.21779640019;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 294)) {
            sum += (float)0.5377022624;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 30)) {
              sum += (float)-0.12307693064;
            } else {
              sum += (float)0.48850485682;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 306)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 20)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 140)) {
              sum += (float)0.18225693703;
            } else {
              sum += (float)-0.16879457235;
            }
          } else {
            sum += (float)0.32031366229;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 42)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
              sum += (float)-0.14430525899;
            } else {
              sum += (float)0.0059424177743;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
              sum += (float)0.043028529733;
            } else {
              sum += (float)0.24184001982;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 66)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 64)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 8)) {
              sum += (float)0.025668995455;
            } else {
              sum += (float)-0.32163506746;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 8)) {
              sum += (float)0.60747730732;
            } else {
              sum += (float)0.21552540362;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 50)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
              sum += (float)0.16571334004;
            } else {
              sum += (float)-0.18623439968;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
              sum += (float)-0.076798789203;
            } else {
              sum += (float)-0.29804220796;
            }
          }
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
      if (!(data[9].missing != -1) || (data[9].qvalue < 102)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 124)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 160)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
              sum += (float)0.15335807204;
            } else {
              sum += (float)-0.18671391904;
            }
          } else {
            sum += (float)0.26491871476;
          }
        } else {
          sum += (float)-0.33594033122;
        }
      } else {
        sum += (float)0.25854122639;
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 72)) {
        sum += (float)0.075178056955;
      } else {
        sum += (float)0.29028847814;
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 218)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 212)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 190)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 150)) {
              sum += (float)-0.0038284368347;
            } else {
              sum += (float)-0.21930615604;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 34)) {
              sum += (float)-0.16474564373;
            } else {
              sum += (float)0.17971724272;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
            sum += (float)-0.19605402648;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 14)) {
              sum += (float)0.046029493213;
            } else {
              sum += (float)0.49252343178;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 96)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 8)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 276)) {
              sum += (float)-0.046284481883;
            } else {
              sum += (float)0.34388381243;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 28)) {
              sum += (float)-0.17458432913;
            } else {
              sum += (float)0.090284429491;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 54)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 10)) {
              sum += (float)-0.16788262129;
            } else {
              sum += (float)0.090177722275;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
              sum += (float)-0.24806201458;
            } else {
              sum += (float)-0.12574499846;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 2)) {
        sum += (float)0.28999230266;
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 26)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 162)) {
              sum += (float)0.15026435256;
            } else {
              sum += (float)-0.32271283865;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 28)) {
              sum += (float)-0.050157703459;
            } else {
              sum += (float)0.25043740869;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 52)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 32)) {
              sum += (float)-0.15913455188;
            } else {
              sum += (float)0.18355894089;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
              sum += (float)0.051458816975;
            } else {
              sum += (float)0.28283107281;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 78)) {
    if (!(data[7].missing != -1) || (data[7].qvalue < 22)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 16)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 104)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 20)) {
            sum += (float)-0.069612979889;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 14)) {
              sum += (float)0.33447480202;
            } else {
              sum += (float)0.076290182769;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 2)) {
            sum += (float)0.16878974438;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
              sum += (float)-0.2249057591;
            } else {
              sum += (float)0.17426158488;
            }
          }
        }
      } else {
        sum += (float)0.46716022491;
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 12)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 50)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 26)) {
            sum += (float)0.047884691507;
          } else {
            sum += (float)0.34074896574;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 10)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
              sum += (float)0.21369887888;
            } else {
              sum += (float)-0.034400656819;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
              sum += (float)-0.31815513968;
            } else {
              sum += (float)-0.13802906871;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 38)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 182)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 42)) {
              sum += (float)-0.12473969162;
            } else {
              sum += (float)0.01352425199;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
              sum += (float)-0.21163895726;
            } else {
              sum += (float)-0.019390195608;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 38)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 52)) {
              sum += (float)0.075240716338;
            } else {
              sum += (float)0.33200219274;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 86)) {
              sum += (float)-0.14727266133;
            } else {
              sum += (float)0.22812752426;
            }
          }
        }
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 78)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 98)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 176)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 30)) {
            sum += (float)0.19749863446;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 40)) {
              sum += (float)0.09172154963;
            } else {
              sum += (float)-0.29689279199;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 298)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
              sum += (float)0.24880947173;
            } else {
              sum += (float)0.014986512251;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 112)) {
              sum += (float)-0.032466631383;
            } else {
              sum += (float)-0.17544311285;
            }
          }
        }
      } else {
        sum += (float)0.247973755;
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 82)) {
        sum += (float)0.063351392746;
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 4)) {
          sum += (float)0.046534087509;
        } else {
          sum += (float)0.29260078073;
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 12)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 60)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 108)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 164)) {
          sum += (float)0.093776039779;
        } else {
          sum += (float)0.25703701377;
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 102)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 200)) {
            sum += (float)-0.26297938824;
          } else {
            sum += (float)-0.04698157683;
          }
        } else {
          sum += (float)0.1558291465;
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 88)) {
        sum += (float)0.085430569947;
      } else {
        sum += (float)0.28101652861;
      }
    }
  } else {
    if (!(data[9].missing != -1) || (data[9].qvalue < 8)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 124)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 120)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 90)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
              sum += (float)-0.14540995657;
            } else {
              sum += (float)0.25052946806;
            }
          } else {
            sum += (float)-0.24611125886;
          }
        } else {
          sum += (float)0.52091270685;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 48)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 320)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 18)) {
              sum += (float)0.038927789778;
            } else {
              sum += (float)-0.26137265563;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 80)) {
              sum += (float)0.23641078174;
            } else {
              sum += (float)-0.20977331698;
            }
          }
        } else {
          sum += (float)0.15327328444;
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 152)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
              sum += (float)-0.32036921382;
            } else {
              sum += (float)0.0091358022764;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
              sum += (float)-0.091258890927;
            } else {
              sum += (float)0.23019810021;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 114)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 38)) {
              sum += (float)0.230952546;
            } else {
              sum += (float)-0.20093102753;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 310)) {
              sum += (float)0.21443559229;
            } else {
              sum += (float)-0.075141005218;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 172)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
              sum += (float)0.10397827625;
            } else {
              sum += (float)-0.27844548225;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
              sum += (float)0.44226363301;
            } else {
              sum += (float)-0.063261367381;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 84)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 302)) {
              sum += (float)-0.0020319900941;
            } else {
              sum += (float)-0.24521267414;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 40)) {
              sum += (float)0.44541564584;
            } else {
              sum += (float)-0.069294728339;
            }
          }
        }
      }
    }
  }
  if (!(data[9].missing != -1) || (data[9].qvalue < 100)) {
    if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
      sum += (float)0.2886287272;
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 2)) {
          sum += (float)-0.0069172312506;
        } else {
          sum += (float)-0.27900156379;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 60)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 114)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 32)) {
              sum += (float)0.35155719519;
            } else {
              sum += (float)0.097871921957;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 10)) {
              sum += (float)-0.15954776108;
            } else {
              sum += (float)0.09286300838;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 304)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 300)) {
              sum += (float)-0.026842013001;
            } else {
              sum += (float)0.19799768925;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 188)) {
              sum += (float)-0.22631286085;
            } else {
              sum += (float)0.30483311415;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 42)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 62)) {
        sum += (float)-0.21981754899;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 48)) {
          sum += (float)0.21833822131;
        } else {
          sum += (float)0.04938371107;
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 56)) {
        sum += (float)0.26464986801;
      } else {
        sum += (float)-0.01244406309;
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
    sum += (float)0.28020939231;
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 82)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 78)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 124)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
              sum += (float)0.33307486773;
            } else {
              sum += (float)-0.099754460156;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 66)) {
              sum += (float)0.055628202856;
            } else {
              sum += (float)-0.27676320076;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 164)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 36)) {
              sum += (float)0.64341717958;
            } else {
              sum += (float)-0.034598920494;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
              sum += (float)-0.16307282448;
            } else {
              sum += (float)-0.0023845578544;
            }
          }
        }
      } else {
        sum += (float)-0.27537819743;
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 234)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 208)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 144)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 122)) {
              sum += (float)-0.054759215564;
            } else {
              sum += (float)0.18069817126;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 188)) {
              sum += (float)-0.17721152306;
            } else {
              sum += (float)0.040033683181;
            }
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 38)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
              sum += (float)-0.085017889738;
            } else {
              sum += (float)0.31198370457;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 216)) {
              sum += (float)0.29429790378;
            } else {
              sum += (float)0.034224111587;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 98)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 296)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)-0.14686356485;
            } else {
              sum += (float)0.10662041605;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 308)) {
              sum += (float)0.37984752655;
            } else {
              sum += (float)-0.0077416035347;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 256)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 106)) {
              sum += (float)-0.068975590169;
            } else {
              sum += (float)-0.28502440453;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 260)) {
              sum += (float)0.3777897656;
            } else {
              sum += (float)-0.09290920198;
            }
          }
        }
      }
    }
  }

  sum = sum + (float)(-0);
  if (!pred_margin) {
    return pred_transform(sum);
  } else {
    return sum;
  }
}
