static const int th_len[] = {
  10, 6, 67, 180, 97, 35, 73, 64, 32, 
};
static const int th_begin[] = {
  0, 10, 16, 83, 263, 360, 395, 468, 532, 
};
static const float threshold[] = {
  8.5, 9.5, 10.5, 11.5, 12.5, 13.5, 14.5, 15.5, 16.5, 17.5, 0.5, 2.5, 3.5, 4.5, 
  5.5, 6.5, 0.26280659, 0.30145776, 0.3082124, 0.33080837, 0.33855149, 
  0.38389271, 0.40647578, 0.44542927, 0.4654488, 0.4665114, 0.4862833, 
  0.48810303, 0.48823622, 0.48904812, 0.4913379, 0.50625491, 0.51504451, 
  0.5151177, 0.55303335, 0.55389249, 0.5598048, 0.57669753, 0.58856273, 
  0.59340847, 0.60404992, 0.632056, 0.63464618, 0.64494264, 0.65450466, 
  0.67883658, 0.70607173, 0.73592705, 0.76163518, 0.76695752, 0.77069348, 
  0.77953184, 0.7826606, 0.79188871, 0.79197848, 0.82058161, 0.82504863, 
  0.83091968, 0.8399111, 0.84877777, 0.85227132, 0.86007667, 0.86658454, 
  0.8694272, 0.87978834, 0.88178837, 0.88391221, 0.89267766, 0.89415842, 
  0.90019906, 0.90713972, 0.91069603, 0.92023075, 0.93633866, 0.93740445, 
  0.93753612, 0.93919563, 0.93939012, 0.94687122, 0.96162426, 0.9624244, 
  0.96391314, 0.97452801, -1492.7782, -1492.5929, -1486.9408, -1438.9088, 
  -999.23163, -981.22675, -965.42596, -961.14685, -951.62811, -950.52478, 
  -943.81189, -17.249001, -11.826834, 3.6577501, 33.0005, 35.207249, 39.280666, 
  49.562164, 56.933666, 68.060577, 79.16275, 82.555916, 95.312088, 95.69175, 
  123.60634, 162.10901, 165.79591, 169.55092, 182.03134, 182.19925, 183.32541, 
  184.25009, 191.17609, 192.62991, 195.20499, 195.67741, 212.6785, 236.72484, 
  239.65726, 254.95432, 255.13434, 270.21527, 274.38977, 300.56598, 321.366, 
  321.68274, 327.17407, 331.02951, 331.38275, 337.51416, 338.22565, 339.74808, 
  409.82016, 419.82675, 428.50323, 430.12192, 435.43427, 436.48575, 445.36615, 
  454.80206, 460.793, 463.05765, 479.68991, 479.94348, 492.12415, 529.50208, 
  565.80249, 566.00122, 597.37634, 609.69092, 655.21875, 665.28284, 672.00891, 
  684.6759, 690.57648, 723.91425, 797.599, 803.0495, 803.39484, 803.76184, 
  833.87317, 834.14233, 837.302, 948.42395, 973.18921, 975.46326, 1037.7012, 
  1070.3599, 1116.4377, 1150.6405, 1151.165, 1151.3282, 1152.0979, 1165.5018, 
  1166.2544, 1186.985, 1187.1089, 1187.4435, 1190.8079, 1206.9915, 1209.7529, 
  1229.2297, 1259.2158, 1292.9072, 1295.2058, 1295.9866, 1302.9644, 1311.0874, 
  1313.3351, 1335.4336, 1337.2859, 1339.093, 1341.7512, 1344.4583, 1352.0193, 
  1353.054, 1358.0034, 1381.2488, 1396.3114, 1396.7883, 1399.6267, 1415.4343, 
  1419.7573, 1493.5161, 1493.7749, 1565.0718, 1578.5824, 1664.7371, 1670.0425, 
  1682.6553, 1710.0203, 1721.879, 1771.5273, 1788.7603, 1823.6462, 1837.2317, 
  1845.5994, 1847.3748, 1849.1904, 1852.4447, 1859.6396, 1866.3251, 1869.3081, 
  1872.2273, 1885.7937, 1894.0865, 1899.4484, 1903.6151, 1936.4729, 1959.8884, 
  1963.6121, 1973.5896, 1983.8394, 1984.7576, 1988.3912, 2089.0105, 2115.043, 
  2196.9976, 2240.731, 2268.1948, 2277.2178, 2350.5542, 2433.9697, 2480.1519, 
  2482.5435, 2483.1387, 2520.1719, 2522.7424, 2524.6396, 2548.6035, 2744.7463, 
  2757.3218, 2788.1648, 2797.1221, 3254.2192, 3291.6499, 3494.0637, 3551.998, 
  3704.6782, 3913.1741, 0.014324183, 0.014859611, 0.0207441, 0.024892587, 
  0.026879404, 0.028311737, 0.028322214, 0.02836925, 0.028708555, 0.032899693, 
  0.033214778, 0.036542665, 0.036557429, 0.038852558, 0.039813161, 0.040195815, 
  0.043944892, 0.043997079, 0.044633716, 0.045352865, 0.046798684, 0.047207884, 
  0.048963577, 0.049692333, 0.050908353, 0.058300782, 0.060648441, 0.060980313, 
  0.06830129, 0.076966926, 0.077181384, 0.07923691, 0.081369407, 0.086783916, 
  0.092790969, 0.093492329, 0.094799735, 0.096839741, 0.097862214, 0.10072196, 
  0.10131152, 0.10135812, 0.10375054, 0.10851949, 0.10902482, 0.11535632, 
  0.12103017, 0.12142327, 0.12166037, 0.12663524, 0.14281482, 0.15670425, 
  0.1589565, 0.16011781, 0.16255033, 0.16427287, 0.1708293, 0.17221677, 
  0.17458081, 0.17536771, 0.17684555, 0.18180931, 0.18716818, 0.20145658, 
  0.22813648, 0.24210703, 0.24411996, 0.24677005, 0.26043266, 0.26045457, 
  0.26167619, 0.26329863, 0.27610281, 0.39681506, 0.42760968, 0.46822429, 
  0.47135231, 0.48412341, 0.53028953, 0.58791196, 0.61542535, 0.74104714, 
  0.75640392, 0.76987481, 1.2045507, 1.8398471, 1.8821061, 2.0967135, 
  2.2688556, 9.6078262, 14.985391, 17.439602, 17.447453, 25.75672, 31.185154, 
  31.499981, 65.926636, 0.034576349, 0.062846139, 0.071310386, 0.096263155, 
  0.09637925, 0.098636195, 0.10353023, 0.11328327, 0.11603814, 0.13015631, 
  0.1475006, 0.1612542, 0.17098634, 0.21512383, 0.23329446, 0.24581292, 
  0.24889733, 0.25190222, 0.2520124, 0.26982653, 0.49342552, 0.70000684, 
  0.90435147, 0.97991562, 1.0136775, 1.4074299, 2.3717752, 2.4644279, 
  2.5119274, 4.7064166, 4.733078, 14.712797, 15.708934, 25.026823, 82.789993, 
  0.28397429, 0.42622095, 0.54603994, 0.55265188, 0.5964905, 0.59817827, 
  0.63850641, 0.65588659, 0.82005095, 0.82210016, 0.97730267, 1.1972058, 
  1.2172768, 1.3267035, 1.3451121, 1.4241807, 1.4351392, 1.4366884, 1.4519598, 
  1.4765853, 1.499301, 1.5346061, 1.5471224, 1.5491796, 1.5756263, 1.6180303, 
  1.6313236, 1.6375742, 1.6484215, 1.6531899, 1.6608586, 1.6791438, 1.6804321, 
  1.7266812, 1.7307518, 1.7322429, 1.753495, 1.763252, 1.7710185, 1.7757722, 
  1.7840517, 1.8188753, 1.8439116, 1.8568673, 1.8778741, 1.8806876, 1.8814045, 
  1.8825623, 1.8861551, 1.8861709, 1.8874116, 1.8879042, 1.9222848, 1.940284, 
  1.9662488, 1.9853103, 1.9878309, 2.0002754, 2.0145361, 2.0292861, 2.0306883, 
  2.0331173, 2.0520253, 2.0535395, 2.0537448, 2.0720932, 2.0735283, 2.080411, 
  2.0931821, 2.1484308, 2.1848254, 2.2610331, 2.2652407, 0.098033845, 
  0.11054495, 0.11979584, 0.12384076, 0.17563051, 0.18252179, 0.18359426, 
  0.19367984, 0.19409862, 0.19837953, 0.22136411, 0.26636091, 0.28572193, 
  0.29215366, 0.30568111, 0.32753184, 0.33178771, 0.35367903, 0.45656937, 
  0.46486202, 0.52597773, 0.64334857, 0.67097068, 0.69292498, 0.71890765, 
  0.7373507, 0.81542563, 0.83867991, 0.85742307, 0.91998303, 1.0525818, 
  1.0902591, 1.1649146, 1.1696489, 1.3879989, 1.8396884, 4.2330008, 4.3226194, 
  5.1852584, 6.3634739, 8.5908699, 9.1468782, 10.230376, 10.489944, 31.217422, 
  45.216057, 72.212906, 194.13316, 196.53946, 217.29636, 318.45105, 321.54684, 
  349.62085, 389.54089, 409.2569, 419.81686, 434.5672, 452.97693, 466.22729, 
  479.09784, 534.76013, 1163.9044, 9800.5176, 72453.008, 0.0056489115, 
  0.014317604, 0.014429994, 0.02140291, 0.02163814, 0.032222584, 0.046190057, 
  0.069836736, 0.077375144, 0.082096063, 0.091623992, 0.095317662, 0.10451513, 
  0.12001619, 0.14076698, 0.15550995, 0.26018789, 0.34632093, 0.44289938, 
  0.63674486, 0.64341331, 0.70315027, 1.2851583, 1.3220876, 1.6231005, 
  1.8830404, 4.1026073, 7.356185, 14.148716, 60.897427, 90.766212, 123484.41, 
};

#include <stdlib.h>

/*
 * \brief function to convert a feature value into bin index.
 * \param val feature value, in floating-point
 * \param fid feature identifier
 * \return bin index corresponding to given feature value
 */
static inline int quantize(float val, unsigned fid) {
  const size_t offset = th_begin[fid];
  const float* array = &threshold[offset];
  int len = th_len[fid];
  int low = 0;
  int high = len;
  int mid;
  float mval;
  // It is possible th_begin[i] == [total_num_threshold]. This means that
  // all features i, (i+1), ... are not used for any of the splits in the model.
  // So in this case, just return something
  if (offset == 564 || val < array[0]) {
    return -10;
  }
  while (low + 1 < high) {
    mid = (low + high) / 2;
    mval = array[mid];
    if (val == mval) {
      return mid * 2;
    } else if (val < mval) {
      high = mid;
    } else {
      low = mid;
    }
  }
  if (array[low] == val) {
    return low * 2;
  } else if (high == len) {
    return len * 2;
  } else {
    return low * 2 + 1;
  }
}

#include "header.h"

const unsigned char is_categorical[] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 
};

size_t get_num_output_group(void) {
  return 1;
}

size_t get_num_feature(void) {
  return 9;
}

const char* get_pred_transform(void) {
  return "sigmoid";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_global_bias(void) {
  return -0.0;
}

static inline float pred_transform(float margin) {
  const float alpha = (float)1.0;
  return 1.0f / (1 + expf(-alpha * margin));
}
float predict(union Entry* data, int pred_margin) {

  for (int i = 0; i < 9; ++i) {
    if (data[i].missing != -1 && !is_categorical[i]) {
      data[i].qvalue = quantize(data[i].fvalue, i);
    }
  }
  float sum = 0.0f;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 30)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 64)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 172)) {
              sum += (float)0.58636367321;
            } else {
              sum += (float)0.15000000596;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 50)) {
              sum += (float)-0.066666670144;
            } else {
              sum += (float)0.34736841917;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
            sum += (float)-0.51111114025;
          } else {
            sum += (float)0.47368425131;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 348)) {
          sum += (float)-0.15000000596;
        } else {
          sum += (float)-0.5428571701;
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
        sum += (float)0.56883120537;
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 88)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 34)) {
              sum += (float)-0.57931035757;
            } else {
              sum += (float)0.12000000477;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 102)) {
              sum += (float)0.52000004053;
            } else {
              sum += (float)0.23076924682;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 60)) {
              sum += (float)-0.44262298942;
            } else {
              sum += (float)-0.57904791832;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 76)) {
              sum += (float)-0.087567575276;
            } else {
              sum += (float)-0.46834531426;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 72)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 50)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 352)) {
            sum += (float)0.59894865751;
          } else {
            sum += (float)0.15000000596;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 116)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 30)) {
              sum += (float)0.17647060752;
            } else {
              sum += (float)0.57033711672;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 274)) {
              sum += (float)0.39428573847;
            } else {
              sum += (float)-0;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 110)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 62)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 20)) {
              sum += (float)-0.41538465023;
            } else {
              sum += (float)0.30000001192;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 98)) {
              sum += (float)0.54495418072;
            } else {
              sum += (float)0.31034481525;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 198)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 118)) {
              sum += (float)0.53513514996;
            } else {
              sum += (float)0.10000000894;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 14)) {
              sum += (float)0.38181820512;
            } else {
              sum += (float)-0.23571428657;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 70)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
            sum += (float)-0.12000000477;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 130)) {
              sum += (float)-0;
            } else {
              sum += (float)0.5;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 32)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 72)) {
              sum += (float)-0.48571431637;
            } else {
              sum += (float)0.44347828627;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 188)) {
              sum += (float)-0.25161290169;
            } else {
              sum += (float)-0.48091605306;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 70)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 74)) {
            sum += (float)-0.52000004053;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 136)) {
              sum += (float)0.42857146263;
            } else {
              sum += (float)-0.26666668057;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 4)) {
              sum += (float)0.55167788267;
            } else {
              sum += (float)0.28301888704;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 86)) {
              sum += (float)0.35593223572;
            } else {
              sum += (float)-0.15728156269;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 44)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 308)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 36)) {
              sum += (float)0.4490711987;
            } else {
              sum += (float)0.22184351087;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 318)) {
              sum += (float)-0.2090484798;
            } else {
              sum += (float)0.36450856924;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 8)) {
            sum += (float)0.37975546718;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 72)) {
              sum += (float)-0.0088691227138;
            } else {
              sum += (float)-0.44181120396;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 178)) {
          sum += (float)-0.14049044251;
        } else {
          sum += (float)-0.44891571999;
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
        sum += (float)0.4391682148;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 192)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 96)) {
              sum += (float)-0.37769457698;
            } else {
              sum += (float)-0.45134720206;
            }
          } else {
            sum += (float)0.33603495359;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 64)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 122)) {
              sum += (float)-0.4191300571;
            } else {
              sum += (float)0.23635293543;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 100)) {
              sum += (float)-0.35698050261;
            } else {
              sum += (float)0.239101246;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 64)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 40)) {
        sum += (float)0.46130394936;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 36)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 54)) {
              sum += (float)-0.21829561889;
            } else {
              sum += (float)0.31442695856;
            }
          } else {
            sum += (float)0.43368026614;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 72)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 26)) {
              sum += (float)0.40258485079;
            } else {
              sum += (float)0.16253548861;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 272)) {
              sum += (float)0.17958277464;
            } else {
              sum += (float)-0.31252092123;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 70)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 290)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 128)) {
              sum += (float)0.041200861335;
            } else {
              sum += (float)0.42012953758;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 42)) {
              sum += (float)0.19057260454;
            } else {
              sum += (float)-0.32700878382;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 48)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 72)) {
              sum += (float)-0.39127606153;
            } else {
              sum += (float)0.35034161806;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 188)) {
              sum += (float)-0.078230887651;
            } else {
              sum += (float)-0.33792361617;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 138)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 66)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 68)) {
              sum += (float)-0.36127728224;
            } else {
              sum += (float)0.26965197921;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 118)) {
              sum += (float)0.42487326264;
            } else {
              sum += (float)-0.037403549999;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 66)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)0.098334856331;
            } else {
              sum += (float)0.39623758197;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 116)) {
              sum += (float)-0.35909730196;
            } else {
              sum += (float)0.09314506501;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 60)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 80)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 32)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
            sum += (float)0.39619353414;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
              sum += (float)0.28409209847;
            } else {
              sum += (float)-0.081356421113;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 148)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 22)) {
              sum += (float)0.13872686028;
            } else {
              sum += (float)-0.37431544065;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 56)) {
              sum += (float)0.46952092648;
            } else {
              sum += (float)-0.084910526872;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 238)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 56)) {
              sum += (float)0.45669978857;
            } else {
              sum += (float)0.047898050398;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 86)) {
              sum += (float)-0.3748344779;
            } else {
              sum += (float)0.36923652887;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 110)) {
            sum += (float)-0.4100432694;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 36)) {
              sum += (float)-0.260858953;
            } else {
              sum += (float)0.43718782067;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 38)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 184)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
            sum += (float)0.40304100513;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 28)) {
              sum += (float)-0.03961096704;
            } else {
              sum += (float)0.35077548027;
            }
          }
        } else {
          sum += (float)-0.16267579794;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 286)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 52)) {
              sum += (float)-0.18651074171;
            } else {
              sum += (float)0.26544940472;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 102)) {
              sum += (float)-0.25914162397;
            } else {
              sum += (float)0.28213912249;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 104)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 38)) {
              sum += (float)-0.0074058398604;
            } else {
              sum += (float)0.36452946067;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 204)) {
              sum += (float)0.36166971922;
            } else {
              sum += (float)0.027074543759;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
          sum += (float)0.36510622501;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 40)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 162)) {
              sum += (float)0.26179274917;
            } else {
              sum += (float)-0.2767804563;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
              sum += (float)0.048805132508;
            } else {
              sum += (float)-0.38361415267;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 84)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 132)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 114)) {
              sum += (float)-0.37892481685;
            } else {
              sum += (float)0.53110092878;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 172)) {
              sum += (float)0.26250457764;
            } else {
              sum += (float)-0.26742973924;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 80)) {
              sum += (float)-0.32522302866;
            } else {
              sum += (float)0.29309371114;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 190)) {
              sum += (float)-0.18722014129;
            } else {
              sum += (float)-0.36539453268;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 30)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 64)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 14)) {
            sum += (float)-0.37417966127;
          } else {
            sum += (float)0.34640040994;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 114)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 50)) {
              sum += (float)0.39604946971;
            } else {
              sum += (float)0.23626700044;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 128)) {
              sum += (float)0.29303908348;
            } else {
              sum += (float)-0.40249171853;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 48)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 24)) {
            sum += (float)0.35862624645;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 252)) {
              sum += (float)0.32531306148;
            } else {
              sum += (float)-0.25475516915;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 174)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 42)) {
              sum += (float)-0.37787941098;
            } else {
              sum += (float)0.37325507402;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 92)) {
              sum += (float)-0.36375212669;
            } else {
              sum += (float)0.0058861700818;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 44)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 298)) {
              sum += (float)0.36317053437;
            } else {
              sum += (float)0.19173786044;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 48)) {
              sum += (float)0.030047496781;
            } else {
              sum += (float)0.40143573284;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 62)) {
            sum += (float)0.25818565488;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 88)) {
              sum += (float)-0.34022557735;
            } else {
              sum += (float)-0.07661447674;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 178)) {
          sum += (float)-0.075404539704;
        } else {
          sum += (float)-0.35004609823;
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
          sum += (float)0.3275411129;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 20)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
              sum += (float)0.27080997825;
            } else {
              sum += (float)-0.2256064564;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
              sum += (float)0.27748629451;
            } else {
              sum += (float)-0.34708830714;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 54)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 164)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 108)) {
              sum += (float)-0.25771057606;
            } else {
              sum += (float)0.4661732018;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 176)) {
              sum += (float)0.30519157648;
            } else {
              sum += (float)-0.22504608333;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 76)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 94)) {
              sum += (float)-0.067830316722;
            } else {
              sum += (float)0.51941525936;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 70)) {
              sum += (float)-0.13451081514;
            } else {
              sum += (float)-0.30886170268;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 78)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 40)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 354)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
            sum += (float)0.36816179752;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 96)) {
              sum += (float)0.33273088932;
            } else {
              sum += (float)0.081266708672;
            }
          }
        } else {
          sum += (float)0.089056424797;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 92)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 38)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 20)) {
              sum += (float)-0.37394475937;
            } else {
              sum += (float)0.21389238536;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
              sum += (float)0.3642925024;
            } else {
              sum += (float)0.2743678391;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 282)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 136)) {
              sum += (float)0.29668110609;
            } else {
              sum += (float)-0.042852658778;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 324)) {
              sum += (float)-0.31414121389;
            } else {
              sum += (float)0.1222634688;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 82)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 18)) {
          sum += (float)-0.39416703582;
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.18034699559;
            } else {
              sum += (float)0.26131302118;
            }
          } else {
            sum += (float)-0.27912211418;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 122)) {
            sum += (float)0.34807667136;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 0)) {
              sum += (float)0.23283685744;
            } else {
              sum += (float)-0.23864513636;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 164)) {
            sum += (float)0.41914913058;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 104)) {
              sum += (float)0.13083998859;
            } else {
              sum += (float)-0.20637305081;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 46)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 320)) {
          sum += (float)0.34588336945;
        } else {
          sum += (float)-0.25294604897;
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 138)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 58)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 266)) {
              sum += (float)0.0768205598;
            } else {
              sum += (float)-0.33647087216;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
              sum += (float)0.24520464242;
            } else {
              sum += (float)-0.15712840855;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 86)) {
            sum += (float)0.026401197538;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 54)) {
              sum += (float)-0.33580100536;
            } else {
              sum += (float)-0.0025941496715;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
        sum += (float)0.34384262562;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 102)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 122)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 120)) {
              sum += (float)-0.23564204574;
            } else {
              sum += (float)0.60364663601;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 28)) {
              sum += (float)0.054529204965;
            } else {
              sum += (float)-0.26908692718;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 28)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 240)) {
              sum += (float)-0.22548121214;
            } else {
              sum += (float)0.47366318107;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 116)) {
              sum += (float)-0.32253757119;
            } else {
              sum += (float)0.096172399819;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 74)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 180)) {
          sum += (float)0.34686949849;
        } else {
          sum += (float)-0.099122047424;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 116)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 50)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 44)) {
              sum += (float)-0.33510121703;
            } else {
              sum += (float)0.39160659909;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 88)) {
              sum += (float)0.31239581108;
            } else {
              sum += (float)0.14297635853;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 200)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 78)) {
              sum += (float)0.083199396729;
            } else {
              sum += (float)0.3730737865;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 38)) {
              sum += (float)0.24019999802;
            } else {
              sum += (float)-0.19620013237;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 42)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 304)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 174)) {
              sum += (float)0.37328013778;
            } else {
              sum += (float)0.12129545212;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 56)) {
              sum += (float)0.23947446048;
            } else {
              sum += (float)-0.067816488445;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 68)) {
              sum += (float)-0.19380073249;
            } else {
              sum += (float)0.30915030837;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 192)) {
              sum += (float)-0.059705641121;
            } else {
              sum += (float)-0.23879078031;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 24)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 96)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
              sum += (float)-0.19650602341;
            } else {
              sum += (float)0.053056124598;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 104)) {
              sum += (float)0.33234149218;
            } else {
              sum += (float)0.11655076593;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 124)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)-0.016145722941;
            } else {
              sum += (float)0.29511255026;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 314)) {
              sum += (float)-0.27327758074;
            } else {
              sum += (float)0.079055592418;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 66)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 320)) {
          sum += (float)0.3274038434;
        } else {
          sum += (float)-0.22843356431;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
            sum += (float)0.18800674379;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 6)) {
              sum += (float)0.057683311403;
            } else {
              sum += (float)-0.30932348967;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 302)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 50)) {
              sum += (float)-0.02780370228;
            } else {
              sum += (float)0.23298594356;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 108)) {
              sum += (float)-0.31081703305;
            } else {
              sum += (float)0.066991053522;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 80)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 28)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 134)) {
            sum += (float)-0.32448896766;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 260)) {
              sum += (float)0.65494644642;
            } else {
              sum += (float)0.063135616481;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 188)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 26)) {
              sum += (float)0.25479623675;
            } else {
              sum += (float)-0.23733220994;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 124)) {
              sum += (float)0.47493216395;
            } else {
              sum += (float)-0.16832154989;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 2)) {
          sum += (float)0.27446657419;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
            sum += (float)0.34027349949;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
              sum += (float)-0.31888651848;
            } else {
              sum += (float)-0.24812369049;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 58)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 180)) {
          sum += (float)0.33229520917;
        } else {
          sum += (float)-0.084058716893;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 38)) {
            sum += (float)-0.037614647299;
          } else {
            sum += (float)0.32709369063;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 32)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.38713371754;
            } else {
              sum += (float)0.17374238372;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 276)) {
              sum += (float)0.2788387537;
            } else {
              sum += (float)0.05306256935;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 92)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 24)) {
          sum += (float)-0.35850447416;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 144)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 62)) {
              sum += (float)0.011309231631;
            } else {
              sum += (float)0.28854238987;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 20)) {
              sum += (float)0.24946773052;
            } else {
              sum += (float)-0.37243878841;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 194)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 154)) {
              sum += (float)0.47470036149;
            } else {
              sum += (float)0.066417120397;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 92)) {
              sum += (float)0.22470091283;
            } else {
              sum += (float)-0.29923501611;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 58)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 222)) {
              sum += (float)-0.08777102828;
            } else {
              sum += (float)0.28868553042;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 342)) {
              sum += (float)-0.21117928624;
            } else {
              sum += (float)0.2088547945;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 52)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 78)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 40)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 0)) {
            sum += (float)-0.2752558589;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 14)) {
              sum += (float)0.22487518191;
            } else {
              sum += (float)0.0091033186764;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 46)) {
            sum += (float)0.33889612556;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 36)) {
              sum += (float)-0.19388569891;
            } else {
              sum += (float)0.23272393644;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 214)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)0.32546269894;
            } else {
              sum += (float)0.088864147663;
            }
          } else {
            sum += (float)-0.24857482314;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 90)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 118)) {
              sum += (float)-0.058097667992;
            } else {
              sum += (float)-0.33962854743;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 178)) {
              sum += (float)0.22853843868;
            } else {
              sum += (float)-0.25375455618;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 180)) {
          sum += (float)0.32206973433;
        } else {
          sum += (float)-0.071316711605;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 94)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 48)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 40)) {
              sum += (float)-0.26438111067;
            } else {
              sum += (float)0.26281511784;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 322)) {
              sum += (float)0.29752472043;
            } else {
              sum += (float)0.15272456408;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 202)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 48)) {
              sum += (float)0.061282787472;
            } else {
              sum += (float)0.30087321997;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 258)) {
              sum += (float)-0.47830733657;
            } else {
              sum += (float)0.04329188168;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 92)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 122)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 132)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 44)) {
              sum += (float)-0.035120107234;
            } else {
              sum += (float)-0.1850361973;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 306)) {
              sum += (float)0.58010709286;
            } else {
              sum += (float)-0.016690833494;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 168)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 110)) {
              sum += (float)-0.21094891429;
            } else {
              sum += (float)0.43888804317;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 18)) {
              sum += (float)-0.0084053836763;
            } else {
              sum += (float)-0.28955224156;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 144)) {
            sum += (float)-0.2543489933;
          } else {
            sum += (float)0.38036230206;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
            sum += (float)0.18077470362;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
              sum += (float)-0.31636235118;
            } else {
              sum += (float)-0.26110571623;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 280)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 66)) {
              sum += (float)-0.32714378834;
            } else {
              sum += (float)0.017637306824;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 156)) {
              sum += (float)0.60001957417;
            } else {
              sum += (float)0.0079633165151;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 82)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 296)) {
              sum += (float)-0.40105807781;
            } else {
              sum += (float)0.1869417429;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 106)) {
              sum += (float)-0.29577878118;
            } else {
              sum += (float)0.16474767029;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 94)) {
              sum += (float)0.34691902995;
            } else {
              sum += (float)0.066749751568;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 54)) {
              sum += (float)0.018742583692;
            } else {
              sum += (float)0.29609134793;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 52)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 160)) {
              sum += (float)0.29766273499;
            } else {
              sum += (float)0.11012366414;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 126)) {
              sum += (float)0.14343982935;
            } else {
              sum += (float)-0.15681533515;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 52)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 86)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 28)) {
        sum += (float)0.31478151679;
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 90)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 4)) {
            sum += (float)-0.33387598395;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.058943454176;
            } else {
              sum += (float)0.26186573505;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
            sum += (float)0.30156117678;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 54)) {
              sum += (float)-0.079086564481;
            } else {
              sum += (float)0.34245046973;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 74)) {
          sum += (float)0.17746196687;
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 98)) {
            sum += (float)-0.29276928306;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 74)) {
              sum += (float)-0.2592856288;
            } else {
              sum += (float)0.2841052711;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 236)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 90)) {
            sum += (float)0.025873713195;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 140)) {
              sum += (float)0.30766180158;
            } else {
              sum += (float)0.027941584587;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 254)) {
            sum += (float)-0.31415763497;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 270)) {
              sum += (float)0.31693488359;
            } else {
              sum += (float)-0.03903997317;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
        sum += (float)0.27784883976;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 98)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 24)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 138)) {
              sum += (float)-0.28715571761;
            } else {
              sum += (float)0.4359267652;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 190)) {
              sum += (float)-0.23262473941;
            } else {
              sum += (float)0.13172599673;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 68)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.35477232933;
            } else {
              sum += (float)-0.24124075472;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
              sum += (float)0.017324293032;
            } else {
              sum += (float)-0.28831747174;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 60)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 12)) {
            sum += (float)-0.28591555357;
          } else {
            sum += (float)0.24786201119;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 120)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 78)) {
              sum += (float)0.1226760447;
            } else {
              sum += (float)0.31001701951;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 228)) {
              sum += (float)-0.33305156231;
            } else {
              sum += (float)0.21702741086;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 108)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 142)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 104)) {
              sum += (float)-0.1610455215;
            } else {
              sum += (float)0.25449287891;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 22)) {
              sum += (float)0.1919734627;
            } else {
              sum += (float)-0.10603538156;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 100)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 212)) {
              sum += (float)0.120175533;
            } else {
              sum += (float)-0.15432235599;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 340)) {
              sum += (float)-0.25540825725;
            } else {
              sum += (float)0.0455827564;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 18)) {
        sum += (float)0.22143796086;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 106)) {
            sum += (float)0.3357937336;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
              sum += (float)-0.045916143805;
            } else {
              sum += (float)-0.28859707713;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
            sum += (float)0.11988610774;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
              sum += (float)0.020295660943;
            } else {
              sum += (float)-0.29840317369;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 300)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
            sum += (float)0.32118320465;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
              sum += (float)0.25170877576;
            } else {
              sum += (float)-0.25920322537;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 154)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)0.75617432594;
            } else {
              sum += (float)0.374756217;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 12)) {
              sum += (float)0.24526791275;
            } else {
              sum += (float)-0.086590401828;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 66)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 336)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 42)) {
              sum += (float)0.30992010236;
            } else {
              sum += (float)-0.18558888137;
            }
          } else {
            sum += (float)0.43278715014;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 112)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 358)) {
              sum += (float)-0.29694473743;
            } else {
              sum += (float)0.22178128362;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 356)) {
              sum += (float)0.22690077126;
            } else {
              sum += (float)-0.20723602176;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 0)) {
        sum += (float)0.050317429006;
      } else {
        sum += (float)0.30875888467;
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 8)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 56)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
            sum += (float)-0.2401175499;
          } else {
            sum += (float)0.19595560431;
          }
        } else {
          sum += (float)0.3083088398;
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 78)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 44)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 46)) {
              sum += (float)0.0087659014389;
            } else {
              sum += (float)0.28645539284;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)-0.17516575754;
            } else {
              sum += (float)0.16263112426;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 328)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 206)) {
              sum += (float)0.061595175415;
            } else {
              sum += (float)-0.12707053125;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 346)) {
              sum += (float)0.28314256668;
            } else {
              sum += (float)-0.32475620508;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 130)) {
          sum += (float)0.20119842887;
        } else {
          sum += (float)-0.16600766778;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
          sum += (float)0.076809406281;
        } else {
          sum += (float)0.30309316516;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 182)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
          sum += (float)-0.079906433821;
        } else {
          sum += (float)0.087109275162;
        }
      } else {
        sum += (float)-0.23582531512;
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 116)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 114)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 142)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
              sum += (float)-0.01753683202;
            } else {
              sum += (float)-0.24404156208;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 112)) {
              sum += (float)0.19722366333;
            } else {
              sum += (float)0.90730321407;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 242)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
              sum += (float)0.16342690587;
            } else {
              sum += (float)-0.11053225398;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 18)) {
              sum += (float)0.039314288646;
            } else {
              sum += (float)-0.28698551655;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 84)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 84)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 10)) {
              sum += (float)0.19454829395;
            } else {
              sum += (float)-0.22887085378;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
              sum += (float)-0.1707046628;
            } else {
              sum += (float)0.55598533154;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 130)) {
              sum += (float)0.23255725205;
            } else {
              sum += (float)-0.19012144208;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 144)) {
              sum += (float)-0.28505825996;
            } else {
              sum += (float)-0.099771015346;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 34)) {
          sum += (float)-0.21916045249;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 86)) {
            sum += (float)0.29748719931;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 224)) {
              sum += (float)-0.13904765248;
            } else {
              sum += (float)0.23763373494;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 122)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 288)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 102)) {
              sum += (float)-0.098355919123;
            } else {
              sum += (float)0.15006384254;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 100)) {
              sum += (float)0.16796375811;
            } else {
              sum += (float)-0.15098105371;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 108)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 42)) {
              sum += (float)-0.17866179347;
            } else {
              sum += (float)0.055569522083;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 4)) {
              sum += (float)0.10778661072;
            } else {
              sum += (float)-0.26244741678;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 10)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 138)) {
            sum += (float)-0.10322983563;
          } else {
            sum += (float)0.35119277239;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 234)) {
              sum += (float)0.27181434631;
            } else {
              sum += (float)-0.20904667675;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 102)) {
              sum += (float)0.14738112688;
            } else {
              sum += (float)-0.26415160298;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 42)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            sum += (float)0.24532115459;
          } else {
            sum += (float)-0.18415769935;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 128)) {
              sum += (float)0.18141297996;
            } else {
              sum += (float)-0.16649264097;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 6)) {
              sum += (float)-0.07089060545;
            } else {
              sum += (float)-0.28547620773;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 300)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
            sum += (float)0.30462291837;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 60)) {
              sum += (float)-0.27405127883;
            } else {
              sum += (float)-0.025902077556;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 158)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.47210964561;
            } else {
              sum += (float)0.22604669631;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 20)) {
              sum += (float)0.14883580804;
            } else {
              sum += (float)-0.071002341807;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 334)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 6)) {
              sum += (float)0.26938170195;
            } else {
              sum += (float)-0.1893440932;
            }
          } else {
            sum += (float)0.4416076839;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 112)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 4)) {
              sum += (float)0.065560556948;
            } else {
              sum += (float)-0.27502590418;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 62)) {
              sum += (float)0.21193380654;
            } else {
              sum += (float)-0.17429946363;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
      sum += (float)0.29882591963;
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 28)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 124)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 10)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 56)) {
              sum += (float)-0.061317298561;
            } else {
              sum += (float)0.29097774625;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 184)) {
              sum += (float)0.20314089954;
            } else {
              sum += (float)0.023445801809;
            }
          }
        } else {
          sum += (float)0.3813996613;
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 46)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 96)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 186)) {
              sum += (float)0.27521449327;
            } else {
              sum += (float)0.085708990693;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 52)) {
              sum += (float)-0.077072173357;
            } else {
              sum += (float)0.22108739614;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 108)) {
            sum += (float)0.25724253058;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 186)) {
              sum += (float)0.066606603563;
            } else {
              sum += (float)-0.22277991474;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 10)) {
          sum += (float)0.18845717609;
        } else {
          sum += (float)-0.13313987851;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
          sum += (float)0.050036270171;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
            sum += (float)0.29781913757;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 250)) {
              sum += (float)0.16147612035;
            } else {
              sum += (float)0.015160684474;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 182)) {
        sum += (float)0.00062244728906;
      } else {
        sum += (float)-0.21277238429;
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 244)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 116)) {
              sum += (float)-0.075736492872;
            } else {
              sum += (float)0.36009824276;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 80)) {
              sum += (float)0.12194217741;
            } else {
              sum += (float)-0.2395260185;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 16)) {
            sum += (float)0.1875898838;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 26)) {
              sum += (float)0.10674131662;
            } else {
              sum += (float)-0.24212373793;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 70)) {
            sum += (float)-0.1049753353;
          } else {
            sum += (float)0.1324134022;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 42)) {
            sum += (float)-0.032262492925;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 6)) {
              sum += (float)-0.060756068677;
            } else {
              sum += (float)-0.27559602261;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 98)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 104)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 158)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.11747658253;
            } else {
              sum += (float)-0.041953854263;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 16)) {
              sum += (float)0.20015606284;
            } else {
              sum += (float)-0.26549237967;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
            sum += (float)0.5004580617;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
              sum += (float)-0.11584167182;
            } else {
              sum += (float)0.28901919723;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 106)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 30)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 112)) {
              sum += (float)-0.22532819211;
            } else {
              sum += (float)0.35128825903;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 34)) {
              sum += (float)0.13701175153;
            } else {
              sum += (float)-0.092603877187;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 152)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 76)) {
              sum += (float)-0.15617209673;
            } else {
              sum += (float)0.40437820554;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 48)) {
              sum += (float)-0.066027373075;
            } else {
              sum += (float)-0.28438201547;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 44)) {
    if (!(data[3].missing != -1) || (data[3].qvalue < 84)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 16)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 34)) {
          sum += (float)0.060606669635;
        } else {
          sum += (float)-0.29464516044;
        }
      } else {
        sum += (float)0.31984892488;
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
        sum += (float)0.30226311088;
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 28)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 230)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 208)) {
              sum += (float)0.1862500608;
            } else {
              sum += (float)-0.59290552139;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 14)) {
              sum += (float)0.32530087233;
            } else {
              sum += (float)-0.10058582574;
            }
          }
        } else {
          sum += (float)0.30095505714;
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 188)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
          sum += (float)0.24257832766;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 246)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 126)) {
              sum += (float)-0.2674446106;
            } else {
              sum += (float)-0.04935169965;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 10)) {
              sum += (float)0.13823513687;
            } else {
              sum += (float)-0.26992553473;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 2)) {
          sum += (float)-0.17699061334;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 12)) {
            sum += (float)0.43610212207;
          } else {
            sum += (float)0.11528731138;
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 62)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 166)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 94)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 46)) {
              sum += (float)-0.14514644444;
            } else {
              sum += (float)0.11132221669;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 294)) {
              sum += (float)0.3173147738;
            } else {
              sum += (float)0.058299817145;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 176)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
              sum += (float)-0.031777925789;
            } else {
              sum += (float)0.33116364479;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 6)) {
              sum += (float)0.08595187217;
            } else {
              sum += (float)-0.16067063808;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 196)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 50)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
              sum += (float)-0.19631503522;
            } else {
              sum += (float)0.21960292757;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
              sum += (float)0.39942350984;
            } else {
              sum += (float)0.026033243164;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 112)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 332)) {
              sum += (float)-0.042121127248;
            } else {
              sum += (float)0.29042932391;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 114)) {
              sum += (float)-0.19929789007;
            } else {
              sum += (float)0.16256420314;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
      sum += (float)0.28629389405;
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
        sum += (float)-0.16826164722;
      } else {
        sum += (float)0.0073289885186;
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 10)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 138)) {
            sum += (float)-0.064272962511;
          } else {
            sum += (float)0.31333565712;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 56)) {
              sum += (float)0.10966116935;
            } else {
              sum += (float)-0.13829730451;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 76)) {
              sum += (float)0.0030040882993;
            } else {
              sum += (float)-0.25790831447;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 46)) {
            sum += (float)-0.083188697696;
          } else {
            sum += (float)0.13616143167;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 66)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)0.28121876717;
            } else {
              sum += (float)-0.24634890258;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 8)) {
              sum += (float)-0.0049755135551;
            } else {
              sum += (float)-0.26575943828;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
          sum += (float)0.28481480479;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 36)) {
              sum += (float)-0.29635986686;
            } else {
              sum += (float)-0.1694188416;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 22)) {
              sum += (float)-0.2598310411;
            } else {
              sum += (float)0.145127967;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 180)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
              sum += (float)0.44168156385;
            } else {
              sum += (float)0.052688788623;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 152)) {
              sum += (float)0.17557328939;
            } else {
              sum += (float)-0.12451650947;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 8)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 220)) {
              sum += (float)-0.12562169135;
            } else {
              sum += (float)0.25392979383;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 30)) {
              sum += (float)0.082632035017;
            } else {
              sum += (float)-0.10716357082;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 86)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 32)) {
        sum += (float)0.026767158881;
      } else {
        sum += (float)0.27805677056;
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 228)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
          sum += (float)0.07381593436;
        } else {
          sum += (float)-0.22414776683;
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 2)) {
          sum += (float)0.012270186096;
        } else {
          sum += (float)0.25016114116;
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 126)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 134)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 42)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 90)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 166)) {
              sum += (float)0.14113563299;
            } else {
              sum += (float)-0.084313675761;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 118)) {
              sum += (float)-0.1785915345;
            } else {
              sum += (float)0.24598051608;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 268)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 34)) {
              sum += (float)0.41141268611;
            } else {
              sum += (float)0.17799921334;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 310)) {
              sum += (float)-0.31495839357;
            } else {
              sum += (float)0.32434692979;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 292)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
              sum += (float)-0.21007621288;
            } else {
              sum += (float)0.28017398715;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 162)) {
              sum += (float)0.22839106619;
            } else {
              sum += (float)-0.0066944113933;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 28)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 350)) {
              sum += (float)0.12766522169;
            } else {
              sum += (float)-0.096462033689;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 122)) {
              sum += (float)-0.25888434052;
            } else {
              sum += (float)0.058814059943;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 108)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 26)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 232)) {
              sum += (float)-0.26792496443;
            } else {
              sum += (float)-0.021338868886;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 84)) {
              sum += (float)0.25797894597;
            } else {
              sum += (float)-0.021614782512;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 132)) {
            sum += (float)0.16877682507;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.27532699704;
            } else {
              sum += (float)0.0762129426;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 146)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 40)) {
              sum += (float)-0.13931576908;
            } else {
              sum += (float)0.41454187036;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 56)) {
              sum += (float)-0.2942956686;
            } else {
              sum += (float)-0.060787614435;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 132)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 142)) {
              sum += (float)-0.30416727066;
            } else {
              sum += (float)-0.089808627963;
            }
          } else {
            sum += (float)-0.097126461565;
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 80)) {
        sum += (float)0.2883938849;
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          sum += (float)0.22670121491;
        } else {
          sum += (float)-0.060387309641;
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
        sum += (float)0.013509661891;
      } else {
        sum += (float)-0.13073946536;
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 248)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 124)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 64)) {
              sum += (float)0.052379511297;
            } else {
              sum += (float)-0.22979314625;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 170)) {
              sum += (float)0.5017940402;
            } else {
              sum += (float)-0.12588432431;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 80)) {
            sum += (float)0.12846456468;
          } else {
            sum += (float)-0.24789944291;
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 16)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 146)) {
            sum += (float)-0.21195472777;
          } else {
            sum += (float)0.32635390759;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 4)) {
            sum += (float)0.17623415589;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 48)) {
              sum += (float)0.035617120564;
            } else {
              sum += (float)-0.25125044584;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 284)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 100)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 38)) {
              sum += (float)-0.27724730968;
            } else {
              sum += (float)-0.01138834469;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)0.072829589248;
            } else {
              sum += (float)-0.15982539952;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 338)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
              sum += (float)0.084032349288;
            } else {
              sum += (float)-0.22577609122;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 128)) {
              sum += (float)0.2432448566;
            } else {
              sum += (float)-0.068178936839;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 44)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 110)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 8)) {
              sum += (float)0.076342277229;
            } else {
              sum += (float)0.35708743334;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 114)) {
              sum += (float)-0.33265131712;
            } else {
              sum += (float)0.12284683436;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 52)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 278)) {
              sum += (float)-0.27714559436;
            } else {
              sum += (float)0.12435726076;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 82)) {
              sum += (float)0.25284573436;
            } else {
              sum += (float)-0.16615512967;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 60)) {
    if (!(data[7].missing != -1) || (data[7].qvalue < 58)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 226)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 28)) {
          sum += (float)0.26412370801;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 210)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 58)) {
              sum += (float)-0.24422812462;
            } else {
              sum += (float)0.058952044696;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 112)) {
              sum += (float)-0.060130953789;
            } else {
              sum += (float)-0.42440676689;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 316)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 62)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 54)) {
              sum += (float)0.19524414837;
            } else {
              sum += (float)-0.39502897859;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 130)) {
              sum += (float)0.43515312672;
            } else {
              sum += (float)0.18732094765;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 2)) {
            sum += (float)0.23875802755;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 326)) {
              sum += (float)-0.38672593236;
            } else {
              sum += (float)0.094250015914;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
        sum += (float)0.41231545806;
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 52)) {
          sum += (float)0.20166166127;
        } else {
          sum += (float)-0.094568550587;
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 134)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 150)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 264)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 74)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 126)) {
              sum += (float)0.01787869446;
            } else {
              sum += (float)0.26500359178;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 256)) {
              sum += (float)0.22603926063;
            } else {
              sum += (float)0.53163415194;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 330)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 124)) {
              sum += (float)-0.16263392568;
            } else {
              sum += (float)0.084967568517;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 344)) {
              sum += (float)0.24562720954;
            } else {
              sum += (float)-0.2228846252;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 52)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 34)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 30)) {
              sum += (float)0.20942421257;
            } else {
              sum += (float)-0.19735650718;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 262)) {
              sum += (float)0.58464074135;
            } else {
              sum += (float)0.051126286387;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 60)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 10)) {
              sum += (float)0.14951370656;
            } else {
              sum += (float)-0.14984150231;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 88)) {
              sum += (float)0.17423549294;
            } else {
              sum += (float)-0.13319808245;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 182)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 70)) {
              sum += (float)0.0028966402169;
            } else {
              sum += (float)-0.25387454033;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)0.13762052357;
            } else {
              sum += (float)-0.22911736369;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 40)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 170)) {
              sum += (float)0.048191335052;
            } else {
              sum += (float)0.77217882872;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 118)) {
              sum += (float)-0.1545150429;
            } else {
              sum += (float)0.21474692225;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 96)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 26)) {
              sum += (float)-0.096386581659;
            } else {
              sum += (float)-0.26119950414;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 312)) {
              sum += (float)-0.20281884074;
            } else {
              sum += (float)0.15664795041;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 176)) {
            sum += (float)0.46403473616;
          } else {
            sum += (float)-0.17581146955;
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 86)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 36)) {
        sum += (float)0.081420078874;
      } else {
        sum += (float)0.27783367038;
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
        sum += (float)0.20352400839;
      } else {
        sum += (float)-0.092056691647;
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
      sum += (float)0.2829131186;
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 44)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 64)) {
              sum += (float)-0.092987172306;
            } else {
              sum += (float)0.12930102646;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
              sum += (float)-0.2784050405;
            } else {
              sum += (float)-0.15344415605;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 100)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 68)) {
              sum += (float)-0.011916178279;
            } else {
              sum += (float)0.39710411429;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 32)) {
              sum += (float)-0.21561856568;
            } else {
              sum += (float)-0.010937217623;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 178)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 94)) {
              sum += (float)0.34479576349;
            } else {
              sum += (float)0.11751836538;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
              sum += (float)-0.10615184158;
            } else {
              sum += (float)0.15763501823;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 114)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 68)) {
              sum += (float)-0.019391393289;
            } else {
              sum += (float)0.21822190285;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
              sum += (float)-0.1791908294;
            } else {
              sum += (float)-0.032086070627;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 66)) {
      sum += (float)0.27773764729;
    } else {
      sum += (float)-0.01008127816;
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 120)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 110)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 156)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 82)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 82)) {
              sum += (float)0.096997916698;
            } else {
              sum += (float)-0.059616625309;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 90)) {
              sum += (float)0.0050684716552;
            } else {
              sum += (float)0.36637532711;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 58)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 8)) {
              sum += (float)0.041100382805;
            } else {
              sum += (float)-0.23130232096;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 126)) {
              sum += (float)0.15328703821;
            } else {
              sum += (float)-0.086770817637;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 120)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 216)) {
              sum += (float)-0.093383289874;
            } else {
              sum += (float)0.22671064734;
            }
          } else {
            sum += (float)0.61648178101;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 32)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 68)) {
              sum += (float)0.26668018103;
            } else {
              sum += (float)-0.09503249079;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 168)) {
              sum += (float)0.046200890094;
            } else {
              sum += (float)-0.16586348414;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 106)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 120)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 148)) {
              sum += (float)0.1059621349;
            } else {
              sum += (float)-0.16392454505;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 12)) {
              sum += (float)0.20562656224;
            } else {
              sum += (float)-0.12520372868;
            }
          }
        } else {
          sum += (float)0.35522860289;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 146)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 40)) {
              sum += (float)-0.038034945726;
            } else {
              sum += (float)0.24869756401;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 56)) {
              sum += (float)-0.24894657731;
            } else {
              sum += (float)-0.013399553485;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
            sum += (float)-0.035763252527;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 140)) {
              sum += (float)-0.095282964408;
            } else {
              sum += (float)-0.27300596237;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 66)) {
      sum += (float)0.27032256126;
    } else {
      sum += (float)-0.0085636842996;
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
      sum += (float)0.26636230946;
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 18)) {
          sum += (float)-0.29609364271;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 140)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
              sum += (float)-0.12683956325;
            } else {
              sum += (float)0.15423211455;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
              sum += (float)-0.26269057393;
            } else {
              sum += (float)0.24259419739;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 160)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 136)) {
            sum += (float)0.39350470901;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 150)) {
              sum += (float)-0.029767831787;
            } else {
              sum += (float)0.24721337855;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 10)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 218)) {
              sum += (float)0.023567965254;
            } else {
              sum += (float)0.27003020048;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)-0.014169129543;
            } else {
              sum += (float)-0.17460016906;
            }
          }
        }
      }
    }
  }

  sum = sum + (float)(-0);
  if (!pred_margin) {
    return pred_transform(sum);
  } else {
    return sum;
  }
}
