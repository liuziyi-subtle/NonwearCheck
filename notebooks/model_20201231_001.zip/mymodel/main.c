static const int th_len[] = {
  41, 44, 33, 19, 58, 36, 
};
static const int th_begin[] = {
  0, 41, 85, 118, 137, 195, 
};
static const float threshold[] = {
  0.33813724, 0.434102, 0.47160321, 0.48510009, 0.48763385, 0.49422124, 
  0.50445914, 0.54334676, 0.5548563, 0.55584383, 0.55773896, 0.61997473, 
  0.63348269, 0.68088454, 0.68101573, 0.76845932, 0.82724154, 0.84034848, 
  0.84090757, 0.86524117, 0.86703897, 0.86741155, 0.88542187, 0.8884933, 
  0.90953183, 0.91753793, 0.91974151, 0.9249649, 0.92814183, 0.94910097, 
  0.96315539, 0.96475756, 0.97529978, 0.97866821, 0.97920632, 0.99616367, 
  0.99644172, 0.99819154, 0.99864107, 0.99940073, 0.99968743, 1.2449419, 
  1.2724141, 2.0650768, 2.8365886, 3.214354, 3.683073, 3.8229434, 3.860024, 
  4.0877514, 4.1118889, 4.3575411, 4.8685298, 4.9979544, 5.0002861, 8.2378616, 
  8.2609711, 8.2669449, 8.3051157, 8.3386097, 8.6837206, 9.1037903, 10.696224, 
  10.730721, 10.851654, 11.01248, 18.02508, 18.575129, 21.233706, 21.920692, 
  22.26012, 56.992634, 74.154045, 85.522675, 257.66187, 268.70648, 279.92755, 
  7595.54, 11751.005, 12583.139, 13996.582, 14493.615, 14579.729, 16693.922, 
  350196.31, 1.2532418, 1.2620261, 1.2777283, 1.4345261, 1.8054945, 2.3009524, 
  2.7877765, 3.936492, 3.9393802, 4.4251127, 4.5591745, 4.6816092, 4.7572975, 
  4.780138, 5.187994, 5.3641143, 5.3753357, 5.3955956, 5.5115385, 5.5926495, 
  5.7060814, 5.8355856, 6.4642782, 6.503623, 7.7520924, 9.4436722, 10.544156, 
  18.585178, 18.709312, 22.748825, 23.263859, 28.305035, 158.50726, 0.39283943, 
  0.4784824, 0.48374388, 2.2374358, 4.4652109, 4.5315785, 6.0595918, 6.2516541, 
  6.6745629, 6.8797827, 7.1317272, 7.310339, 7.3494501, 10.564424, 12.148163, 
  14.535927, 48.739182, 104.06779, 197533.41, 133532, 152143, 153899, 198870, 
  200025.5, 211532.5, 270720, 288295, 311581.5, 326813, 366652, 462431.5, 
  626264, 747676, 901293, 924648.5, 1075960.5, 1091022.5, 1115589, 1240538.5, 
  1242137, 1252749.5, 1633199.5, 1635754, 1853090, 1892777.5, 1894151.5, 
  1909766, 2007044.5, 2109241.5, 2252383.5, 2339791.5, 2430256.5, 2536365, 
  2986047, 3000860, 3191991.5, 3211466.5, 3233952, 3329415, 3726331.5, 3820963, 
  3866174.5, 3867017.5, 5099054.5, 6689550.5, 6723729.5, 6940319, 6946623.5, 
  7030269, 7057871, 7406665, 7467714, 7532917, 7594183.5, 7660754, 7716579, 
  8112693, 0.16015625, 0.1875, 0.20703125, 0.24609375, 0.27734375, 0.28515625, 
  0.30859375, 0.33984375, 0.35546875, 0.37890625, 0.38671875, 0.39453125, 
  0.41796875, 0.44140625, 0.47265625, 0.48828125, 0.53515625, 0.5390625, 
  0.54296875, 0.55859375, 0.58984375, 0.59765625, 0.60546875, 0.63671875, 
  0.64453125, 0.66796875, 0.71484375, 0.73828125, 0.75390625, 0.83203125, 
  0.8359375, 0.84765625, 0.85546875, 0.87109375, 0.89453125, 0.91796875, 
};

#include <stdlib.h>

/*
 * \brief function to convert a feature value into bin index.
 * \param val feature value, in floating-point
 * \param fid feature identifier
 * \return bin index corresponding to given feature value
 */
static inline int quantize(float val, unsigned fid) {
  const size_t offset = th_begin[fid];
  const float* array = &threshold[offset];
  int len = th_len[fid];
  int low = 0;
  int high = len;
  int mid;
  float mval;
  // It is possible th_begin[i] == [total_num_threshold]. This means that
  // all features i, (i+1), ... are not used for any of the splits in the model.
  // So in this case, just return something
  if (offset == 231 || val < array[0]) {
    return -10;
  }
  while (low + 1 < high) {
    mid = (low + high) / 2;
    mval = array[mid];
    if (val == mval) {
      return mid * 2;
    } else if (val < mval) {
      high = mid;
    } else {
      low = mid;
    }
  }
  if (array[low] == val) {
    return low * 2;
  } else if (high == len) {
    return len * 2;
  } else {
    return low * 2 + 1;
  }
}

#include "header.h"

const unsigned char is_categorical[] = {
  0, 0, 0, 0, 0, 0, 
};

size_t get_num_output_group(void) {
  return 1;
}

size_t get_num_feature(void) {
  return 6;
}

const char* get_pred_transform(void) {
  return "sigmoid";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_global_bias(void) {
  return -0.0;
}

static inline float pred_transform(float margin) {
  const float alpha = (float)1.0;
  return 1.0f / (1 + expf(-alpha * margin));
}
float predict(union Entry* data, int pred_margin) {

  for (int i = 0; i < 6; ++i) {
    if (data[i].missing != -1 && !is_categorical[i]) {
      data[i].qvalue = quantize(data[i].fvalue, i);
    }
  }
  float sum = 0.0f;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if (!(data[5].missing != -1) || (data[5].qvalue < 30)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
        sum += (float)0.59760040045;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
          sum += (float)0.5586207509;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
            sum += (float)-0.34285718203;
          } else {
            sum += (float)0.30000001192;
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
          sum += (float)0.54893618822;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
            sum += (float)-0;
          } else {
            sum += (float)-0.58222222328;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 108)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 26)) {
            sum += (float)0.58002084494;
          } else {
            sum += (float)0.17538462579;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
            sum += (float)0.2842105329;
          } else {
            sum += (float)-0.44788733125;
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 10)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 38)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 34)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 54)) {
            sum += (float)-0.49090909958;
          } else {
            sum += (float)0.30000001192;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 54)) {
            sum += (float)-0.50769233704;
          } else {
            sum += (float)-0.10000000894;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 82)) {
          sum += (float)0.56326532364;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 28)) {
            sum += (float)0.30000001192;
          } else {
            sum += (float)-0.20000001788;
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 42)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 40)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 52)) {
            sum += (float)-0.5341463685;
          } else {
            sum += (float)0.24705883861;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 86)) {
            sum += (float)0.43448275328;
          } else {
            sum += (float)-0.10000000894;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 62)) {
            sum += (float)-0.46956524253;
          } else {
            sum += (float)0.36000001431;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
            sum += (float)-0.51293379068;
          } else {
            sum += (float)-0.59410727024;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 28)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
        sum += (float)0.4625095427;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            sum += (float)0.03596829623;
          } else {
            sum += (float)0.442083776;
          }
        } else {
          sum += (float)-0.19332359731;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
          sum += (float)0.43016308546;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
            sum += (float)-0;
          } else {
            sum += (float)-0.45234778523;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 108)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
            sum += (float)0.45174333453;
          } else {
            sum += (float)0.18868528306;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 74)) {
            sum += (float)-0.31579479575;
          } else {
            sum += (float)0.40604844689;
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 38)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 88)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 56)) {
            sum += (float)-0.34454423189;
          } else {
            sum += (float)-0.11730224639;
          }
        } else {
          sum += (float)0.21393895149;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 74)) {
          sum += (float)0.45015874505;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 36)) {
            sum += (float)0.31339225173;
          } else {
            sum += (float)-0.079627037048;
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 46)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
            sum += (float)0.32101580501;
          } else {
            sum += (float)-0.35803097486;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 48)) {
            sum += (float)0.10076247156;
          } else {
            sum += (float)0.38877668977;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
            sum += (float)-0.15199100971;
          } else {
            sum += (float)0.19184918702;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 26)) {
            sum += (float)-0.34359532595;
          } else {
            sum += (float)-0.45871341228;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
        sum += (float)0.40243300796;
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
          sum += (float)-0.028115142137;
        } else {
          sum += (float)0.26824104786;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
          sum += (float)0.37366101146;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
            sum += (float)-0.0034252607729;
          } else {
            sum += (float)-0.42609345913;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 106)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
            sum += (float)0.39075505733;
          } else {
            sum += (float)-0.012269360013;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
            sum += (float)0.26371982694;
          } else {
            sum += (float)-0.27696993947;
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 56)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 40)) {
          sum += (float)0.024303613231;
        } else {
          sum += (float)-0.15688593686;
        }
      } else {
        sum += (float)0.38139423728;
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 14)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 50)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
            sum += (float)-0.017988607287;
          } else {
            sum += (float)-0.3668577075;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 80)) {
            sum += (float)0.41836804152;
          } else {
            sum += (float)-0.04417128861;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 48)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 46)) {
            sum += (float)-0.35125541687;
          } else {
            sum += (float)0.16209003329;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 36)) {
            sum += (float)-0.39707219601;
          } else {
            sum += (float)-0.083987243474;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 26)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 110)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 10)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 10)) {
            sum += (float)0.35738107562;
          } else {
            sum += (float)-0.46276131272;
          }
        } else {
          sum += (float)0.36969611049;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
            sum += (float)-0.34027707577;
          } else {
            sum += (float)0.19880089164;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 100)) {
            sum += (float)0.32702988386;
          } else {
            sum += (float)-0.5073865056;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
          sum += (float)0.35994589329;
        } else {
          sum += (float)-0.071262523532;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 10)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 2)) {
            sum += (float)-0.07880744338;
          } else {
            sum += (float)-0.37139314413;
          }
        } else {
          sum += (float)0.079630754888;
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 18)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 36)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 38)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
            sum += (float)0.10424041003;
          } else {
            sum += (float)-0.34755456448;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 50)) {
            sum += (float)-0.34556412697;
          } else {
            sum += (float)0.066523067653;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 60)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 34)) {
            sum += (float)0.36585769057;
          } else {
            sum += (float)-0.1042072773;
          }
        } else {
          sum += (float)0.38071876764;
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 44)) {
          sum += (float)0.36227139831;
        } else {
          sum += (float)-0.13968935609;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
            sum += (float)0.62203210592;
          } else {
            sum += (float)-0.27182614803;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
            sum += (float)-0.24308530986;
          } else {
            sum += (float)-0.36350864172;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
        sum += (float)0.34805843234;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 16)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 12)) {
            sum += (float)0.036101717502;
          } else {
            sum += (float)0.3309994936;
          }
        } else {
          sum += (float)-0.31831794977;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
          sum += (float)0.30835682154;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
            sum += (float)0.0082300519571;
          } else {
            sum += (float)-0.36972117424;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 110)) {
            sum += (float)0.33502483368;
          } else {
            sum += (float)-0.1508757323;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 34)) {
            sum += (float)-0.25323858857;
          } else {
            sum += (float)0.29647502303;
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 14)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 50)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 40)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 46)) {
            sum += (float)-0.29126170278;
          } else {
            sum += (float)0.07971803844;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
            sum += (float)-0.087185055017;
          } else {
            sum += (float)-0.35177963972;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 80)) {
          sum += (float)0.34288311005;
        } else {
          sum += (float)-0.022386459634;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 44)) {
            sum += (float)-0.058658778667;
          } else {
            sum += (float)0.66320538521;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 34)) {
            sum += (float)-0.29259935021;
          } else {
            sum += (float)0.32460251451;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
            sum += (float)0.051973160356;
          } else {
            sum += (float)-0.33004611731;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 86)) {
            sum += (float)-0.34180226922;
          } else {
            sum += (float)-0.036329593509;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      sum += (float)0.33369788527;
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
          sum += (float)0.29325324297;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
            sum += (float)0.0069711552933;
          } else {
            sum += (float)-0.35481777787;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 108)) {
            sum += (float)0.32852733135;
          } else {
            sum += (float)-0.080123946071;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 32)) {
            sum += (float)-0.1685372293;
          } else {
            sum += (float)0.21802097559;
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 20)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 60)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 32)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
            sum += (float)-0.25624188781;
          } else {
            sum += (float)0.13889218867;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 62)) {
            sum += (float)-0.28188976645;
          } else {
            sum += (float)0.12734951079;
          }
        }
      } else {
        sum += (float)0.32345950603;
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 62)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 58)) {
            sum += (float)-0.16437205672;
          } else {
            sum += (float)0.68359434605;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 38)) {
            sum += (float)-0.056699026376;
          } else {
            sum += (float)-0.30624657869;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 32)) {
            sum += (float)0.19561220706;
          } else {
            sum += (float)-0.28517401218;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 72)) {
            sum += (float)-0.32791301608;
          } else {
            sum += (float)-0.23771323264;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      sum += (float)0.32381913066;
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 8)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 112)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
            sum += (float)-0.042707413435;
          } else {
            sum += (float)0.32057702541;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
            sum += (float)0.23490075767;
          } else {
            sum += (float)-0.24188880622;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 68)) {
            sum += (float)-0.20067365468;
          } else {
            sum += (float)0.070259362459;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 48)) {
            sum += (float)0.37416276336;
          } else {
            sum += (float)0.078652173281;
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 20)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 54)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
            sum += (float)-0.2308511734;
          } else {
            sum += (float)0.20558871329;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 70)) {
            sum += (float)-0.066330134869;
          } else {
            sum += (float)-0.31020700932;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 80)) {
          sum += (float)0.31620433927;
        } else {
          sum += (float)-0.031762361526;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 64)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 42)) {
            sum += (float)-0.20084021986;
          } else {
            sum += (float)0.36934900284;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 38)) {
            sum += (float)-0.055463958532;
          } else {
            sum += (float)-0.29096603394;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
            sum += (float)0.055850896984;
          } else {
            sum += (float)-0.30835413933;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 72)) {
            sum += (float)-0.31608724594;
          } else {
            sum += (float)-0.21051287651;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      sum += (float)0.31648078561;
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 8)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 112)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
            sum += (float)-0.030946005136;
          } else {
            sum += (float)0.30980104208;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
            sum += (float)0.22610139847;
          } else {
            sum += (float)-0.22062453628;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 94)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 42)) {
            sum += (float)-0.053884632885;
          } else {
            sum += (float)0.18711934984;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 50)) {
            sum += (float)-0.11074481905;
          } else {
            sum += (float)-0.54942971468;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 66)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 52)) {
            sum += (float)-0.20139355958;
          } else {
            sum += (float)0.18526776135;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 68)) {
            sum += (float)-0.29756179452;
          } else {
            sum += (float)-0.10021867603;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 66)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 54)) {
            sum += (float)0.056002106518;
          } else {
            sum += (float)0.87693440914;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 52)) {
            sum += (float)0.22603113949;
          } else {
            sum += (float)-0.22271156311;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 76)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 26)) {
          sum += (float)-0.023365469649;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 80)) {
            sum += (float)-0.31260570884;
          } else {
            sum += (float)-0.042711336166;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 70)) {
          sum += (float)0.25534254313;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 84)) {
            sum += (float)-0.098131082952;
          } else {
            sum += (float)-0.28791335225;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 24)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      sum += (float)0.31157121062;
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 8)) {
            sum += (float)0.29339110851;
          } else {
            sum += (float)-0.06383612752;
          }
        } else {
          sum += (float)-0.3353151679;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 102)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
            sum += (float)0.29471424222;
          } else {
            sum += (float)0.022694725543;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 4)) {
            sum += (float)0.061396773905;
          } else {
            sum += (float)-0.33327555656;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 34)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 52)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
            sum += (float)0.13670933247;
          } else {
            sum += (float)-0.2230656296;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 56)) {
            sum += (float)-0.27258324623;
          } else {
            sum += (float)0.16807806492;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 78)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 44)) {
            sum += (float)0.09492893517;
          } else {
            sum += (float)0.5071799159;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 36)) {
            sum += (float)0.27985194325;
          } else {
            sum += (float)-0.13684432209;
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 68)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
            sum += (float)0.070657715201;
          } else {
            sum += (float)-0.29865401983;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
            sum += (float)0.38007900119;
          } else {
            sum += (float)-0.25382086635;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 72)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 42)) {
            sum += (float)-0.032221455127;
          } else {
            sum += (float)-0.29531437159;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 68)) {
            sum += (float)0.47500807047;
          } else {
            sum += (float)-0.25655245781;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 42)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      sum += (float)0.30802923441;
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 8)) {
            sum += (float)0.26596641541;
          } else {
            sum += (float)-0.31429222226;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 104)) {
            sum += (float)0.29750260711;
          } else {
            sum += (float)-0.03878043592;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 30)) {
            sum += (float)-0.26998871565;
          } else {
            sum += (float)-0.018209224567;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 84)) {
            sum += (float)0.31107056141;
          } else {
            sum += (float)0.054304465652;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 66)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 44)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
            sum += (float)-0.14637072384;
          } else {
            sum += (float)0.26327461004;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 48)) {
            sum += (float)-0.11921041459;
          } else {
            sum += (float)-0.28783932328;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 58)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 58)) {
            sum += (float)0.1548909992;
          } else {
            sum += (float)0.63661044836;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 56)) {
            sum += (float)-0.16392797232;
          } else {
            sum += (float)0.24228815734;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 76)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 78)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 28)) {
            sum += (float)-0.014641749673;
          } else {
            sum += (float)-0.30000835657;
          }
        } else {
          sum += (float)-0.0079043945298;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 68)) {
          sum += (float)0.27026793361;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 84)) {
            sum += (float)-0.047049891204;
          } else {
            sum += (float)-0.26476478577;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
        sum += (float)0.30479162931;
      } else {
        sum += (float)0.087886109948;
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
          sum += (float)0.24582241476;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
            sum += (float)-0.014121795073;
          } else {
            sum += (float)-0.30356571078;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 96)) {
            sum += (float)0.27446949482;
          } else {
            sum += (float)-0.091269820929;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 40)) {
            sum += (float)-0.14402671158;
          } else {
            sum += (float)0.23973169923;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 66)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 58)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
            sum += (float)0.19489634037;
          } else {
            sum += (float)-0.25207585096;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
            sum += (float)0.11221659184;
          } else {
            sum += (float)-0.21456564963;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 52)) {
          sum += (float)0.506118536;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
            sum += (float)-0.16861262918;
          } else {
            sum += (float)0.15886712074;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 76)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 78)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 28)) {
            sum += (float)-0.012483107857;
          } else {
            sum += (float)-0.29412645102;
          }
        } else {
          sum += (float)-0.0067416355014;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 68)) {
          sum += (float)0.2037922442;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 84)) {
            sum += (float)-0.038413889706;
          } else {
            sum += (float)-0.25099903345;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 22)) {
        sum += (float)0.3024661839;
      } else {
        sum += (float)0.03469574824;
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 12)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 110)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
            sum += (float)-0.035314466804;
          } else {
            sum += (float)0.27598291636;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
            sum += (float)0.19399477541;
          } else {
            sum += (float)-0.17030899227;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 92)) {
            sum += (float)-0.040136553347;
          } else {
            sum += (float)-0.40831619501;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 72)) {
            sum += (float)0.27977082133;
          } else {
            sum += (float)-0.0069101010449;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 64)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 64)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 42)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
            sum += (float)-0.10939674079;
          } else {
            sum += (float)0.29943782091;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 64)) {
            sum += (float)-0.27972483635;
          } else {
            sum += (float)-0.013312813826;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
          sum += (float)0.77584409714;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 60)) {
            sum += (float)-0.12205248326;
          } else {
            sum += (float)0.2372457087;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 78)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 76)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            sum += (float)-0.031369000673;
          } else {
            sum += (float)-0.29585745931;
          }
        } else {
          sum += (float)-0.0075640184805;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
          sum += (float)-0.23423728347;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
            sum += (float)0.28001406789;
          } else {
            sum += (float)-0.073027200997;
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
      sum += (float)0.30003869534;
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
          sum += (float)0.22849561274;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
            sum += (float)-0.0066333939321;
          } else {
            sum += (float)-0.2881526351;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 96)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
            sum += (float)0.30218458176;
          } else {
            sum += (float)0.023569105193;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 6)) {
            sum += (float)0.063941419125;
          } else {
            sum += (float)-0.27982056141;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 60)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 20)) {
            sum += (float)0.13751606643;
          } else {
            sum += (float)-0.18847879767;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 50)) {
            sum += (float)0.24541290104;
          } else {
            sum += (float)-0.12034431845;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 60)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
            sum += (float)-0.020326996222;
          } else {
            sum += (float)0.61405903101;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 30)) {
            sum += (float)0.34952247143;
          } else {
            sum += (float)-0.11028090864;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 70)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 30)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 44)) {
            sum += (float)-0.15918761492;
          } else {
            sum += (float)0.089294135571;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 72)) {
            sum += (float)-0.28839877248;
          } else {
            sum += (float)-0.0068707177415;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 66)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 62)) {
            sum += (float)-0.16659624875;
          } else {
            sum += (float)0.36999607086;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 80)) {
            sum += (float)-0.26285174489;
          } else {
            sum += (float)-0.089350633323;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
      sum += (float)0.29849183559;
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 114)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
            sum += (float)-0.033741313964;
          } else {
            sum += (float)0.22893239558;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 4)) {
            sum += (float)0.083764068782;
          } else {
            sum += (float)-0.2515835166;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 90)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 36)) {
            sum += (float)-0.088932111859;
          } else {
            sum += (float)0.10855562985;
          }
        } else {
          sum += (float)-0.39652308822;
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 64)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 52)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 32)) {
            sum += (float)-0.19214463234;
          } else {
            sum += (float)0.11225499213;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 28)) {
            sum += (float)-0.014525974169;
          } else {
            sum += (float)-0.29354122281;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 42)) {
          sum += (float)0.47784337401;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 60)) {
            sum += (float)-0.082177005708;
          } else {
            sum += (float)0.18287621439;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 76)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 74)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            sum += (float)-0.03172699362;
          } else {
            sum += (float)-0.28351914883;
          }
        } else {
          sum += (float)-0.0058538499288;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 82)) {
          sum += (float)0.22165244818;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 84)) {
            sum += (float)-0.016682378948;
          } else {
            sum += (float)-0.20733229816;
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
      sum += (float)0.29562368989;
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 98)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
            sum += (float)0.21715715528;
          } else {
            sum += (float)-0.25894251466;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
            sum += (float)-0.023534497246;
          } else {
            sum += (float)0.29013115168;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 0)) {
            sum += (float)0.077651895583;
          } else {
            sum += (float)-0.24514615536;
          }
        } else {
          sum += (float)0.2758359611;
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 66)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 30)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
            sum += (float)0.066316671669;
          } else {
            sum += (float)-0.11100054532;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 46)) {
            sum += (float)0.27875626087;
          } else {
            sum += (float)-0.034925311804;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
          sum += (float)-0.060719478875;
        } else {
          sum += (float)0.40474885702;
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 70)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 30)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 48)) {
            sum += (float)-0.073982961476;
          } else {
            sum += (float)0.079148322344;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 70)) {
            sum += (float)-0.27542629838;
          } else {
            sum += (float)-0.0055607692339;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 70)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 32)) {
            sum += (float)0.6431338191;
          } else {
            sum += (float)-0.033146318048;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 64)) {
            sum += (float)-0.26351538301;
          } else {
            sum += (float)-0.077943056822;
          }
        }
      }
    }
  }

  sum = sum + (float)(-0);
  if (!pred_margin) {
    return pred_transform(sum);
  } else {
    return sum;
  }
}
