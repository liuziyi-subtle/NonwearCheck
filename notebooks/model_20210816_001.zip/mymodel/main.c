static const int th_len[] = {
  72, 15, 83, 68, 103, 115, 69, 102, 110, 15, 
};
static const int th_begin[] = {
  0, 72, 87, 170, 238, 341, 456, 525, 627, 737, 
};
static const float threshold[] = {
  -0.5920707, -0.59022146, -0.4741351, -0.30517694, -0.25545317, -0.15823656, 
  -0.15060097, -0.13659811, -0.12604396, -0.099689767, -0.092208117, 
  -0.067855991, -0.063115202, -0.057530567, -0.033761673, -0.024916232, 
  -0.024397168, -0.01881095, -0.0090021286, 0.0012119275, 0.017585374, 
  0.019743707, 0.0198365, 0.01997862, 0.028084934, 0.0285316, 0.05164104, 
  0.051729411, 0.052079402, 0.055163965, 0.055298395, 0.069479324, 0.072118752, 
  0.074999072, 0.13963532, 0.15916479, 0.18711673, 0.1946657, 0.20863527, 
  0.21462122, 0.22635964, 0.25035584, 0.27916652, 0.29952517, 0.31804368, 
  0.35153916, 0.35605496, 0.36677963, 0.36808378, 0.37625575, 0.39523178, 
  0.39578205, 0.40345469, 0.40705895, 0.43228957, 0.47213352, 0.5345906, 
  0.55411929, 0.56457299, 0.61353058, 0.61820972, 0.6350199, 0.64256144, 
  0.66035736, 0.66363919, 0.67671061, 0.67908394, 0.71623147, 0.72236913, 
  0.76276815, 0.79428852, 0.94243956, 1.5, 3, 3.5, 5.5, 7.5, 8.5, 9.5, 10.5, 
  11.5, 12.5, 13.5, 14.5, 15.5, 16.5, 17.5, -0.03557837, -0.00029116235, 
  0.00034249458, 0.0013539194, 0.011521328, 0.024784226, 0.031057753, 
  0.04427065, 0.050989982, 0.082287595, 0.085477859, 0.1138467, 0.12403307, 
  0.20829925, 0.23125802, 0.40083891, 0.44276297, 0.45181459, 0.47760302, 
  0.49918303, 0.50674498, 0.52816665, 0.55296171, 0.58439219, 0.58903956, 
  0.59799564, 0.62352955, 0.62632906, 0.64047307, 0.65340698, 0.65347642, 
  0.65647674, 0.65917945, 0.66188335, 0.6783222, 0.68073666, 0.6831634, 
  0.69070196, 0.70559376, 0.71127498, 0.71525109, 0.76065409, 0.77783769, 
  0.78630888, 0.79971039, 0.80205923, 0.80832267, 0.81257963, 0.81281352, 
  0.81380486, 0.81626701, 0.81748569, 0.82721269, 0.8297888, 0.84057456, 
  0.84322447, 0.85068148, 0.85171926, 0.85189116, 0.87065321, 0.87208366, 
  0.8739661, 0.87496603, 0.87730592, 0.87979162, 0.8822304, 0.88499081, 
  0.88978028, 0.89219964, 0.90000957, 0.9031691, 0.90964329, 0.91839242, 
  0.93368924, 0.93391132, 0.94355786, 0.94364667, 0.94863594, 0.95151269, 
  0.95949471, 0.96050143, 0.96139276, 0.96648586, 0.00017078838, 0.00017207125, 
  0.00017271016, 0.00017724886, 0.00017743747, 0.00023493383, 0.00023497347, 
  0.0091952141, 0.0091994926, 0.0094969179, 0.0096492842, 0.0097311493, 
  0.010248853, 0.010374708, 0.010455832, 0.012144376, 0.012749009, 0.012776142, 
  0.013082648, 0.01559051, 0.01569166, 0.016091987, 0.016213238, 0.016725611, 
  0.017466689, 0.017864754, 0.019477915, 0.019523196, 0.019560507, 0.020546373, 
  0.020675767, 0.020977257, 0.020998362, 0.021579713, 0.023572652, 0.032399781, 
  0.033317212, 0.033446133, 0.034551732, 0.034732923, 0.039849646, 0.042142123, 
  0.042154629, 0.042197213, 0.047838159, 0.050835699, 0.063237861, 0.064800397, 
  0.067369416, 0.091395415, 0.16185944, 0.2206285, 0.31380576, 0.61178958, 
  1.7097274, 3.6093431, 3.7686448, 4.0103841, 4.6695065, 8.7753677, 23.898022, 
  30.569565, 33.704216, 59.993355, 92.397491, 38858.641, 355587.84, 371815.62, 
  0.0030325344, 0.0037502686, 0.0039755227, 0.0041357419, 0.0041474062, 
  0.0043730279, 0.004698419, 0.0049125706, 0.0087940488, 0.011605622, 
  0.011748294, 0.013062446, 0.014113523, 0.014317608, 0.015247554, 0.015897438, 
  0.041517735, 0.041843496, 0.045129366, 0.045603834, 0.047468185, 0.05303736, 
  0.05582248, 0.056599252, 0.07863877, 0.080556653, 0.081967987, 0.096764177, 
  0.10693511, 0.11274308, 0.12001036, 0.12055002, 0.12478262, 0.14037523, 
  0.14432901, 0.1451464, 0.15639621, 0.16137016, 0.16994831, 0.19075418, 
  0.19842193, 0.20253205, 0.20257227, 0.20836556, 0.21293548, 0.21948263, 
  0.22083239, 0.22229604, 0.26754725, 0.27938056, 0.29532388, 0.31177539, 
  0.31286752, 0.32214668, 0.3377403, 0.37099004, 0.37147075, 0.37152404, 
  0.38247567, 0.38695335, 0.43340722, 0.43933177, 0.44689435, 0.47242349, 
  0.49055332, 0.50796562, 0.51609069, 0.53907657, 0.61303902, 0.61505467, 
  0.68186963, 0.7394495, 0.76700187, 0.78554142, 0.79768574, 0.86372209, 
  1.0255756, 1.2707442, 1.9383241, 1.9433945, 2.1024716, 2.1223595, 2.2560761, 
  2.3782959, 2.4777565, 2.5329387, 2.9311385, 4.1476641, 4.3608465, 4.7538395, 
  4.7810826, 4.8283129, 4.9249229, 5.0249038, 5.5194197, 5.6522312, 31.652496, 
  50.229744, 56.818279, 82.668152, 85.427994, 105.18284, 130.68945, 0.44780773, 
  0.78347003, 0.86563981, 0.99953276, 1.0157146, 1.018357, 1.0496181, 
  1.0768335, 1.1170703, 1.1240079, 1.1372225, 1.2812703, 1.3053484, 1.3515832, 
  1.4407353, 1.4537795, 1.5643578, 1.5745587, 1.5939875, 1.5967069, 1.6057444, 
  1.6059847, 1.6418872, 1.6686752, 1.679445, 1.6860161, 1.7018288, 1.7075551, 
  1.7606047, 1.7611082, 1.7718825, 1.7730869, 1.7782512, 1.7883644, 1.7889158, 
  1.7923114, 1.8011335, 1.8032792, 1.8052369, 1.8101617, 1.8158873, 1.8237517, 
  1.8512628, 1.8536968, 1.8555691, 1.8556812, 1.855919, 1.8619549, 1.8757732, 
  1.8793278, 1.8799736, 1.8848147, 1.9047358, 1.9053397, 1.907004, 1.9275842, 
  1.9316301, 1.9540207, 1.9546635, 1.954793, 1.9584572, 1.9619052, 1.9645002, 
  1.9650354, 1.9692082, 1.9724039, 1.9740523, 1.9760468, 1.9771683, 1.9788053, 
  1.9800289, 1.9849932, 1.9878182, 2.004642, 2.0050082, 2.0097427, 2.0144601, 
  2.0174325, 2.0200515, 2.0237644, 2.0242698, 2.0285053, 2.0347877, 2.0350823, 
  2.038775, 2.0672317, 2.0676222, 2.1087925, 2.1156998, 2.1178164, 2.118221, 
  2.1201396, 2.1219096, 2.1220474, 2.1367683, 2.1381698, 2.141712, 2.1421158, 
  2.1484931, 2.1499467, 2.1504192, 2.1556993, 2.1574759, 2.1764488, 2.2209201, 
  2.2265611, 2.2269511, 2.265712, 2.2660596, 2.2680986, 2.269496, 2.2695291, 
  2.2751298, 2.2808166, 2.2831941, 0.035777777, 0.040944446, 0.050000001, 
  0.053285714, 0.070311114, 0.072733335, 0.073688895, 0.08019048, 0.091314286, 
  0.091600001, 0.095600002, 0.09725, 0.36636364, 0.37264889, 0.37271655, 
  0.39137256, 0.44776347, 0.46659648, 0.47252381, 0.477, 0.4813152, 0.4829697, 
  0.49186087, 0.49671221, 0.50358772, 0.51630771, 0.51749527, 0.52050722, 
  0.55392313, 0.6352222, 0.67566007, 0.71023911, 0.78957582, 0.82256037, 
  0.83286953, 0.9063285, 0.91546851, 0.93775237, 1.0372947, 1.2148333, 
  1.2746364, 1.3808765, 1.433913, 1.6581428, 1.7086799, 1.8269176, 1.9036691, 
  1.9115965, 1.9307778, 1.9869151, 1.9886854, 2.3350868, 2.8543811, 2.9036155, 
  2.927238, 3.2885239, 4.4597645, 5.2042532, 6.619, 7.9495316, 8.011137, 
  11.584757, 11.8425, 13.375867, 14.467455, 15.752167, 24.492804, 24.890869, 
  87.187607, 0.042933334, 0.056944445, 0.066142857, 0.10623376, 0.11294444, 
  0.11621429, 0.11807692, 0.16317788, 0.32733834, 0.32853091, 0.33603334, 
  0.35816666, 0.39168423, 0.4116888, 0.4417091, 0.44311905, 0.44352001, 
  0.44624001, 0.44640887, 0.45891178, 0.45949209, 0.46857893, 0.48358154, 
  0.50705796, 0.51804, 0.53499997, 0.53546429, 0.53557563, 0.53820002, 
  0.54671013, 0.5517, 0.56873739, 0.56921744, 0.60386264, 0.61120635, 
  0.62452966, 0.63024759, 0.63421863, 0.6349203, 0.63498485, 0.67141819, 
  0.67652178, 0.6770435, 0.68917644, 0.72809523, 0.74469697, 0.79583156, 
  0.84032393, 0.88004744, 0.8811, 0.95684004, 0.97855794, 0.97977537, 
  0.98458093, 1.0083214, 1.0343399, 1.0464032, 1.04694, 1.0599556, 1.1257806, 
  1.1418245, 1.2444727, 1.3306363, 1.3380696, 1.3717667, 1.4092814, 1.4093571, 
  1.4368596, 1.4443352, 1.4918637, 1.6954546, 1.7344762, 1.7369372, 1.7392381, 
  1.7740834, 1.8568312, 2.5740399, 3.5827932, 3.6667752, 3.9387369, 4.3713331, 
  4.8474545, 5.0681667, 6.6941967, 6.7348242, 7.138998, 8.7349529, 8.7578335, 
  9.0577526, 11.312687, 16.5336, 17.545921, 19.040405, 20.47967, 28.918568, 
  32.526382, 47.113503, 51.958244, 54.377411, 99.399673, 281.2876, 861.30457, 
  0.0092558507, 0.010230549, 0.010570761, 0.010573789, 0.011359407, 
  0.011387056, 0.011388635, 0.012108671, 0.012361884, 0.013040867, 0.013193686, 
  0.014051808, 0.015966173, 0.017401258, 0.023759654, 0.025530953, 0.057365201, 
  0.18906736, 0.19096097, 0.19267611, 0.19349191, 0.20253828, 0.21686561, 
  0.22622362, 0.25955275, 0.28046247, 0.36196858, 0.36243618, 0.44052738, 
  0.4757157, 0.54585385, 0.59331787, 0.63555121, 0.63803399, 0.64041984, 
  0.64778572, 0.66349959, 0.66520011, 0.69591892, 0.71282816, 0.7687813, 
  0.77035892, 0.87985015, 0.93613577, 0.94076443, 0.97834134, 0.97897947, 
  0.98795664, 1.1682298, 1.4120955, 1.8128006, 1.9046037, 1.9324945, 2.0781012, 
  2.1999695, 2.2203617, 2.2420397, 2.3196955, 2.7359972, 4.800106, 5.4386878, 
  6.8765073, 8.0935745, 8.799305, 8.942544, 9.0537643, 10.451971, 10.68358, 
  10.694213, 11.008839, 14.343018, 14.726028, 15.70392, 16.022963, 16.246418, 
  16.795532, 19.878075, 23.267584, 28.692488, 31.658348, 33.523857, 35.319736, 
  35.42609, 43.91893, 44.337471, 44.350922, 44.366619, 47.080753, 50.495445, 
  52.062096, 52.088356, 65.194496, 81.360596, 88.944016, 111.16003, 122.82116, 
  202.93213, 275.51709, 276.05444, 397.02777, 463.41425, 684.95819, 1249.4846, 
  1515.6404, 2033.0591, 4485.9526, 4568.4507, 19366.633, 73882.438, 1845494.8, 
  0.02734375, 0.03515625, 0.04296875, 0.05859375, 0.07421875, 0.08984375, 
  0.10546875, 0.11328125, 0.12109375, 0.12890625, 0.13671875, 0.14453125, 
  0.15234375, 0.16015625, 0.17578125, 
};

#include <stdlib.h>

/*
 * \brief function to convert a feature value into bin index.
 * \param val feature value, in floating-point
 * \param fid feature identifier
 * \return bin index corresponding to given feature value
 */
static inline int quantize(float val, unsigned fid) {
  const size_t offset = th_begin[fid];
  const float* array = &threshold[offset];
  int len = th_len[fid];
  int low = 0;
  int high = len;
  int mid;
  float mval;
  // It is possible th_begin[i] == [total_num_threshold]. This means that
  // all features i, (i+1), ... are not used for any of the splits in the model.
  // So in this case, just return something
  if (offset == 752 || val < array[0]) {
    return -10;
  }
  while (low + 1 < high) {
    mid = (low + high) / 2;
    mval = array[mid];
    if (val == mval) {
      return mid * 2;
    } else if (val < mval) {
      high = mid;
    } else {
      low = mid;
    }
  }
  if (array[low] == val) {
    return low * 2;
  } else if (high == len) {
    return len * 2;
  } else {
    return low * 2 + 1;
  }
}

#include "header.h"

const unsigned char is_categorical[] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
};

size_t get_num_output_group(void) {
  return 1;
}

size_t get_num_feature(void) {
  return 10;
}

const char* get_pred_transform(void) {
  return "sigmoid";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_global_bias(void) {
  return -0.0;
}

static inline float pred_transform(float margin) {
  const float alpha = (float)1.0;
  return 1.0f / (1 + expf(-alpha * margin));
}
float predict(union Entry* data, int pred_margin) {

  for (int i = 0; i < 10; ++i) {
    if (data[i].missing != -1 && !is_categorical[i]) {
      data[i].qvalue = quantize(data[i].fvalue, i);
    }
  }
  float sum = 0.0f;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if (!(data[4].missing != -1) || (data[4].qvalue < 72)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 48)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 20)) {
          sum += (float)0.5731343627;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 38)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 34)) {
              sum += (float)0.40000003576;
            } else {
              sum += (float)-0.36000001431;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 52)) {
              sum += (float)0.44000002742;
            } else {
              sum += (float)0.066666670144;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 20)) {
          sum += (float)0.30000001192;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 32)) {
            sum += (float)0.15000000596;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 114)) {
              sum += (float)-0.15000000596;
            } else {
              sum += (float)-0.55307269096;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 54)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 44)) {
            sum += (float)0.58416885138;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 46)) {
              sum += (float)-0.20000001788;
            } else {
              sum += (float)0.38181820512;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 152)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 102)) {
              sum += (float)0.5;
            } else {
              sum += (float)0.066666670144;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 70)) {
              sum += (float)-0.52173912525;
            } else {
              sum += (float)-0.18620689213;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 0)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 4)) {
              sum += (float)-0.51724141836;
            } else {
              sum += (float)-0.054545458406;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 28)) {
              sum += (float)0.13846154511;
            } else {
              sum += (float)0.57818180323;
            }
          }
        } else {
          sum += (float)0.59094876051;
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 46)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 196)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 74)) {
              sum += (float)0.15000000596;
            } else {
              sum += (float)0.5625;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 204)) {
              sum += (float)-0.33333337307;
            } else {
              sum += (float)0.13846154511;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 94)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 50)) {
              sum += (float)-0;
            } else {
              sum += (float)0.45882356167;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 70)) {
              sum += (float)-0.32727274299;
            } else {
              sum += (float)0.20000001788;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 194)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 48)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
              sum += (float)-0.38517180085;
            } else {
              sum += (float)0.16738197207;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 26)) {
              sum += (float)0.10000000894;
            } else {
              sum += (float)-0.56529784203;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 192)) {
              sum += (float)-0.36000001431;
            } else {
              sum += (float)-0.014634146355;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 196)) {
              sum += (float)0.52941179276;
            } else {
              sum += (float)-0.13846154511;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 110)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 70)) {
          sum += (float)0.56625002623;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 138)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
              sum += (float)0.15000000596;
            } else {
              sum += (float)0.53333336115;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 90)) {
              sum += (float)0.20000001788;
            } else {
              sum += (float)-0.30000001192;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 188)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 96)) {
              sum += (float)0.24545454979;
            } else {
              sum += (float)-0.47118645906;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 68)) {
              sum += (float)0.5;
            } else {
              sum += (float)-0;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 116)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 112)) {
              sum += (float)0.54000002146;
            } else {
              sum += (float)0.23076924682;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 178)) {
              sum += (float)0.16363637149;
            } else {
              sum += (float)-0.36000001431;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 70)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 48)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 36)) {
          sum += (float)0.45689728856;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 66)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
              sum += (float)-0.3580147028;
            } else {
              sum += (float)0.00033325538971;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 134)) {
              sum += (float)0.10892787576;
            } else {
              sum += (float)0.37466233969;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 16)) {
          sum += (float)0.28724235296;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 216)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 82)) {
              sum += (float)0.022542117164;
            } else {
              sum += (float)-0.42496663332;
            }
          } else {
            sum += (float)0.1381469816;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 54)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 44)) {
            sum += (float)0.45154696703;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 50)) {
              sum += (float)-0.066502608359;
            } else {
              sum += (float)0.3751295507;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 152)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 86)) {
              sum += (float)0.43017944694;
            } else {
              sum += (float)0.11880668253;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 10)) {
              sum += (float)0.074432261288;
            } else {
              sum += (float)-0.36845514178;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 2)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
              sum += (float)-0.40082266927;
            } else {
              sum += (float)0.3523889184;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
              sum += (float)0.082915768027;
            } else {
              sum += (float)0.45446178317;
            }
          }
        } else {
          sum += (float)0.45748513937;
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 50)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 200)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 48)) {
            sum += (float)0.41933628917;
          } else {
            sum += (float)-0.011660040356;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 78)) {
            sum += (float)-0.29979339242;
          } else {
            sum += (float)0.16379329562;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 62)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
              sum += (float)0.14819730818;
            } else {
              sum += (float)0.50082564354;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
              sum += (float)-0.28524005413;
            } else {
              sum += (float)0.12308910489;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 196)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 172)) {
              sum += (float)-0.44684568048;
            } else {
              sum += (float)-0.37789168954;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 40)) {
              sum += (float)0.42974004149;
            } else {
              sum += (float)-0.25951433182;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 86)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 134)) {
            sum += (float)0.44773468375;
          } else {
            sum += (float)0.01095579192;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 134)) {
            sum += (float)0.44501623511;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 92)) {
              sum += (float)0.081111460924;
            } else {
              sum += (float)-0.41266289353;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 186)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 84)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 118)) {
              sum += (float)0.33984777331;
            } else {
              sum += (float)-0.095933169127;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
              sum += (float)-0.34165692329;
            } else {
              sum += (float)0.13588914275;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 60)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
              sum += (float)0.46568438411;
            } else {
              sum += (float)0.12144444138;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 188)) {
              sum += (float)0.27140784264;
            } else {
              sum += (float)-0.20375272632;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 38)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 28)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 68)) {
            sum += (float)0.39477849007;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 76)) {
              sum += (float)-0.011074952781;
            } else {
              sum += (float)0.24221014977;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 36)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 32)) {
              sum += (float)-0.25087696314;
            } else {
              sum += (float)0.16261970997;
            }
          } else {
            sum += (float)0.26784312725;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 44)) {
            sum += (float)-0.069773703814;
          } else {
            sum += (float)0.34684669971;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 222)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 20)) {
              sum += (float)0.18606606126;
            } else {
              sum += (float)-0.37226200104;
            }
          } else {
            sum += (float)0.32528787851;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 44)) {
          sum += (float)0.38872733712;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 138)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
              sum += (float)0.13281866908;
            } else {
              sum += (float)0.44384974241;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 68)) {
              sum += (float)-0.3309392333;
            } else {
              sum += (float)0.021359810606;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 2)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
              sum += (float)-0.30477321148;
            } else {
              sum += (float)0.31290623546;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
              sum += (float)0.12064087391;
            } else {
              sum += (float)0.39356333017;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 8)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
              sum += (float)0.38449338078;
            } else {
              sum += (float)-0.013772011735;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 56)) {
              sum += (float)0.4002609551;
            } else {
              sum += (float)0.34418970346;
            }
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 114)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 88)) {
              sum += (float)0.3344001174;
            } else {
              sum += (float)-0.084636718035;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 154)) {
              sum += (float)0.44188299775;
            } else {
              sum += (float)0.11525547504;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 60)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 150)) {
              sum += (float)0.10496006161;
            } else {
              sum += (float)0.46859574318;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
              sum += (float)0.022444531322;
            } else {
              sum += (float)-0.26567557454;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 208)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 32)) {
              sum += (float)0.3383679986;
            } else {
              sum += (float)-0.088392578065;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 28)) {
              sum += (float)0.22951987386;
            } else {
              sum += (float)-0.37559360266;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 34)) {
            sum += (float)0.4064669311;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 200)) {
              sum += (float)-0.23574602604;
            } else {
              sum += (float)0.30811229348;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 110)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 134)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 28)) {
              sum += (float)0.39637002349;
            } else {
              sum += (float)0.28472396731;
            }
          } else {
            sum += (float)0.0091803269461;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 126)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 40)) {
              sum += (float)0.0012903750176;
            } else {
              sum += (float)0.35674569011;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 178)) {
              sum += (float)-0.14670330286;
            } else {
              sum += (float)0.26541528106;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 184)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 94)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 94)) {
              sum += (float)-0.23665641248;
            } else {
              sum += (float)0.37367907166;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)-0.35297706723;
            } else {
              sum += (float)-0.0038836533204;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 116)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 68)) {
              sum += (float)0.39660683274;
            } else {
              sum += (float)0.15478798747;
            }
          } else {
            sum += (float)-0.15006190538;
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 46)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
          sum += (float)0.36762228608;
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 44)) {
            sum += (float)-0.12235181779;
          } else {
            sum += (float)0.29486507177;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 24)) {
            sum += (float)0.098362229764;
          } else {
            sum += (float)0.36532124877;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 96)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
              sum += (float)-0.12173689902;
            } else {
              sum += (float)0.38143885136;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
              sum += (float)0.25747531652;
            } else {
              sum += (float)-0.28445389867;
            }
          }
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 22)) {
              sum += (float)-0.36384662986;
            } else {
              sum += (float)0.12347704917;
            }
          } else {
            sum += (float)0.30553907156;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
            sum += (float)0.076694659889;
          } else {
            sum += (float)0.36254787445;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 68)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 52)) {
              sum += (float)0.35505095124;
            } else {
              sum += (float)0.15871801972;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 134)) {
              sum += (float)0.29898780584;
            } else {
              sum += (float)-0.24729982018;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 4)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
              sum += (float)0.34553000331;
            } else {
              sum += (float)-0.12431883067;
            }
          } else {
            sum += (float)0.36544585228;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 80)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 94)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 94)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 80)) {
              sum += (float)0.019909149036;
            } else {
              sum += (float)0.34677302837;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 66)) {
              sum += (float)0.32733678818;
            } else {
              sum += (float)-0.21541690826;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 186)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 48)) {
              sum += (float)0.23465883732;
            } else {
              sum += (float)-0.23079253733;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 182)) {
              sum += (float)0.57355386019;
            } else {
              sum += (float)0.02611803636;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 58)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 26)) {
            sum += (float)0.31346577406;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 66)) {
              sum += (float)0.12369274348;
            } else {
              sum += (float)-0.2771897614;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 202)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 50)) {
              sum += (float)0.10856742412;
            } else {
              sum += (float)-0.34022003412;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 34)) {
              sum += (float)0.34942048788;
            } else {
              sum += (float)-0.14490607381;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 98)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 98)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 66)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
              sum += (float)0.086170628667;
            } else {
              sum += (float)0.39199063182;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 130)) {
              sum += (float)0.38253116608;
            } else {
              sum += (float)-0.15429799259;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 154)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 128)) {
              sum += (float)0.17689391971;
            } else {
              sum += (float)-0.31954717636;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 168)) {
              sum += (float)0.33637744188;
            } else {
              sum += (float)0.049339581281;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 176)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 96)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 88)) {
              sum += (float)-0.18980932236;
            } else {
              sum += (float)0.2685752809;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)-0.32163757086;
            } else {
              sum += (float)-0.025231519714;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 120)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 124)) {
              sum += (float)0.33707845211;
            } else {
              sum += (float)-0.15547026694;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 126)) {
              sum += (float)-0.31312349439;
            } else {
              sum += (float)-0.014415036887;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 58)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
          sum += (float)0.34170427918;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 62)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 26)) {
              sum += (float)-0.20114253461;
            } else {
              sum += (float)0.15218570828;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)0.039352588356;
            } else {
              sum += (float)0.33365103602;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 126)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 44)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 58)) {
              sum += (float)-0.20035223663;
            } else {
              sum += (float)0.20369592309;
            }
          } else {
            sum += (float)0.3755659759;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 24)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 56)) {
              sum += (float)-0.14413577318;
            } else {
              sum += (float)0.38547587395;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 104)) {
              sum += (float)-0.31568986177;
            } else {
              sum += (float)0.032329361886;
            }
          }
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 18)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 22)) {
              sum += (float)-0.30983752012;
            } else {
              sum += (float)0.10156517476;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 50)) {
              sum += (float)0.30468732119;
            } else {
              sum += (float)0.080011799932;
            }
          }
        } else {
          sum += (float)0.33851993084;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 46)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 16)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
              sum += (float)0.32388135791;
            } else {
              sum += (float)0.012121504173;
            }
          } else {
            sum += (float)0.34514659643;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 206)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
              sum += (float)0.19916136563;
            } else {
              sum += (float)0.32929176092;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
              sum += (float)-0.19047649205;
            } else {
              sum += (float)0.26107734442;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 106)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 46)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 148)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 120)) {
              sum += (float)0.33891528845;
            } else {
              sum += (float)-0.099609367549;
            }
          } else {
            sum += (float)0.43014064431;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 180)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 76)) {
              sum += (float)0.19191986322;
            } else {
              sum += (float)-0.22765648365;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 104)) {
              sum += (float)0.36362785101;
            } else {
              sum += (float)-0.016256846488;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 128)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 126)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 152)) {
              sum += (float)0.37684240937;
            } else {
              sum += (float)0.14609116316;
            }
          } else {
            sum += (float)-0.099588572979;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 176)) {
              sum += (float)-0.10723397881;
            } else {
              sum += (float)0.19398440421;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 16)) {
              sum += (float)0.33225163817;
            } else {
              sum += (float)0.06272765249;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 210)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 78)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 42)) {
              sum += (float)0.22861099243;
            } else {
              sum += (float)-0.090777501464;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 170)) {
              sum += (float)-0.32222425938;
            } else {
              sum += (float)-0.23460806906;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 76)) {
            sum += (float)0.32191324234;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 200)) {
              sum += (float)-0.31532567739;
            } else {
              sum += (float)0.16566327214;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 176)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 104)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 74)) {
              sum += (float)-0.12954808772;
            } else {
              sum += (float)0.18590137362;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 76)) {
              sum += (float)0.18880879879;
            } else {
              sum += (float)-0.28128451109;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 114)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 24)) {
              sum += (float)0.3147367835;
            } else {
              sum += (float)-0.050072424114;
            }
          } else {
            sum += (float)-0.22642740607;
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 68)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 30)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 54)) {
          sum += (float)0.32473513484;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 40)) {
            sum += (float)-0.19242241979;
          } else {
            sum += (float)0.27186983824;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 168)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 60)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 44)) {
              sum += (float)0.32311570644;
            } else {
              sum += (float)0.088830664754;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 54)) {
              sum += (float)-0.22511571646;
            } else {
              sum += (float)0.17929133773;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 138)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 92)) {
              sum += (float)-0.31216433644;
            } else {
              sum += (float)-0.045143757015;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 74)) {
              sum += (float)0.16244387627;
            } else {
              sum += (float)-0.14141395688;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 52)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
            sum += (float)-0.12800107896;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 108)) {
              sum += (float)0.31439509988;
            } else {
              sum += (float)-0.060013469309;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 112)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 64)) {
              sum += (float)0.30084869266;
            } else {
              sum += (float)0.071821637452;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 70)) {
              sum += (float)-0.38194307685;
            } else {
              sum += (float)0.02106814459;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 22)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
              sum += (float)-0.22927726805;
            } else {
              sum += (float)0.24436672032;
            }
          } else {
            sum += (float)0.32424107194;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 4)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
              sum += (float)0.30040580034;
            } else {
              sum += (float)-0.072142608464;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 56)) {
              sum += (float)0.32838514447;
            } else {
              sum += (float)0.23649901152;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 122)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 34)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 160)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 150)) {
              sum += (float)-0.15825299919;
            } else {
              sum += (float)0.18407194316;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 166)) {
              sum += (float)0.68334746361;
            } else {
              sum += (float)0.025604251772;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 192)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 132)) {
              sum += (float)-0.00076399574755;
            } else {
              sum += (float)-0.23578295112;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 130)) {
              sum += (float)-0.14822137356;
            } else {
              sum += (float)0.49733671546;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 118)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 66)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 74)) {
              sum += (float)0.30185824633;
            } else {
              sum += (float)-0.032976005226;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 52)) {
              sum += (float)0.12031102926;
            } else {
              sum += (float)0.4216581285;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 30)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 132)) {
              sum += (float)0.23948705196;
            } else {
              sum += (float)-0.13458067179;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 198)) {
              sum += (float)-0.13179340959;
            } else {
              sum += (float)0.27408087254;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 212)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 82)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 112)) {
              sum += (float)-0.034606207162;
            } else {
              sum += (float)0.49224200845;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 72)) {
              sum += (float)-0.011109802872;
            } else {
              sum += (float)-0.29275396466;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 76)) {
            sum += (float)0.32199069858;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 160)) {
              sum += (float)0.1635222584;
            } else {
              sum += (float)-0.27576360106;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 100)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 78)) {
              sum += (float)0.25708055496;
            } else {
              sum += (float)-0.080235995352;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 64)) {
              sum += (float)0.069192580879;
            } else {
              sum += (float)0.35236489773;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 174)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 118)) {
              sum += (float)0.13179002702;
            } else {
              sum += (float)-0.30270454288;
            }
          } else {
            sum += (float)0.25135722756;
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 82)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 46)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 8)) {
          sum += (float)0.069600999355;
        } else {
          sum += (float)0.31558418274;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
          sum += (float)0.24931637943;
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 16)) {
            sum += (float)0.22776082158;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 218)) {
              sum += (float)-0.25457900763;
            } else {
              sum += (float)0.17687550187;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 34)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 24)) {
            sum += (float)-0.10228987038;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 12)) {
              sum += (float)0.075370907784;
            } else {
              sum += (float)0.31136992574;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 164)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 56)) {
              sum += (float)0.12878644466;
            } else {
              sum += (float)0.35069674253;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 64)) {
              sum += (float)-0.27724432945;
            } else {
              sum += (float)0.01182802394;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 22)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 12)) {
              sum += (float)-0.22000180185;
            } else {
              sum += (float)0.18019118905;
            }
          } else {
            sum += (float)0.31128102541;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 8)) {
              sum += (float)0.29392018914;
            } else {
              sum += (float)-0.0094821620733;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 56)) {
              sum += (float)0.31919071078;
            } else {
              sum += (float)0.22190074623;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 116)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 46)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 140)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 142)) {
              sum += (float)-0.01877325587;
            } else {
              sum += (float)0.33620893955;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)0.14649495482;
            } else {
              sum += (float)0.4222342968;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 34)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 130)) {
              sum += (float)0.033430598676;
            } else {
              sum += (float)-0.3116004169;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 60)) {
              sum += (float)-0.058295670897;
            } else {
              sum += (float)-0.21774928272;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 82)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 78)) {
              sum += (float)0.26324680448;
            } else {
              sum += (float)-0.11080364138;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 98)) {
              sum += (float)0.37616181374;
            } else {
              sum += (float)0.10946605355;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 152)) {
              sum += (float)-0.23429630697;
            } else {
              sum += (float)0.055936522782;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 132)) {
              sum += (float)0.28893432021;
            } else {
              sum += (float)-0.076170511544;
            }
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 170)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 84)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 112)) {
              sum += (float)-0.096993722022;
            } else {
              sum += (float)0.3963624239;
            }
          } else {
            sum += (float)0.45073911548;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 44)) {
              sum += (float)0.062129084021;
            } else {
              sum += (float)-0.2905792594;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 122)) {
              sum += (float)0.0083236657083;
            } else {
              sum += (float)-0.25614851713;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 96)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 116)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 178)) {
              sum += (float)-0.0058978777379;
            } else {
              sum += (float)0.60323363543;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 200)) {
              sum += (float)-0.14861382544;
            } else {
              sum += (float)0.20768490434;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 214)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 154)) {
              sum += (float)0.07561378181;
            } else {
              sum += (float)-0.25917184353;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 108)) {
              sum += (float)0.073662638664;
            } else {
              sum += (float)0.27052810788;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 68)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
      if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 30)) {
              sum += (float)-0.040233284235;
            } else {
              sum += (float)-0.32684084773;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 14)) {
              sum += (float)-0.17764277756;
            } else {
              sum += (float)0.30157783628;
            }
          }
        } else {
          sum += (float)0.28680673242;
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 20)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 176)) {
              sum += (float)0.29353791475;
            } else {
              sum += (float)-0.038306452334;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 6)) {
              sum += (float)-0.30175024271;
            } else {
              sum += (float)0.11376463622;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
            sum += (float)0.31261122227;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
              sum += (float)-0.041441041976;
            } else {
              sum += (float)0.24005828798;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 40)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 36)) {
              sum += (float)0.21365559101;
            } else {
              sum += (float)-0.17645831406;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 210)) {
              sum += (float)0.30256846547;
            } else {
              sum += (float)0.0063140979037;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 120)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 42)) {
              sum += (float)0.068475089967;
            } else {
              sum += (float)0.30825853348;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 66)) {
              sum += (float)-0.30652713776;
            } else {
              sum += (float)-0.012071299367;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 66)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 212)) {
            sum += (float)0.29783758521;
          } else {
            sum += (float)0.049211446196;
          }
        } else {
          sum += (float)0.0478262119;
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 124)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 112)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 54)) {
              sum += (float)-0.032767131925;
            } else {
              sum += (float)0.27098187804;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 106)) {
              sum += (float)-0.071955949068;
            } else {
              sum += (float)0.25018340349;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 68)) {
              sum += (float)0.24439041317;
            } else {
              sum += (float)-0.27229192853;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 152)) {
              sum += (float)0.3232447803;
            } else {
              sum += (float)0.099516421556;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 172)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 102)) {
              sum += (float)0.17678010464;
            } else {
              sum += (float)-0.15435022116;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 80)) {
              sum += (float)0.42982962728;
            } else {
              sum += (float)-0.0040163365193;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 72)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 132)) {
              sum += (float)0.044687367976;
            } else {
              sum += (float)0.31956148148;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 148)) {
              sum += (float)0.31908887625;
            } else {
              sum += (float)-0.094563931227;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 180)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 100)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 114)) {
              sum += (float)-0.1166921556;
            } else {
              sum += (float)0.2931881249;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
              sum += (float)0.14650824666;
            } else {
              sum += (float)-0.28150424361;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 112)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 114)) {
              sum += (float)0.049216337502;
            } else {
              sum += (float)0.81631106138;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 94)) {
              sum += (float)-0.047630392015;
            } else {
              sum += (float)-0.21688766778;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 116)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 112)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 180)) {
              sum += (float)0.12522783875;
            } else {
              sum += (float)-0.11171207577;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)-0.26485073566;
            } else {
              sum += (float)-0.036559667438;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 88)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 148)) {
              sum += (float)-0.053468614817;
            } else {
              sum += (float)0.35686016083;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 206)) {
              sum += (float)-0.2372996062;
            } else {
              sum += (float)0.20827953517;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 64)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 26)) {
        sum += (float)0.22388127446;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 64)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 42)) {
            sum += (float)-0.079275839031;
          } else {
            sum += (float)-0.29579222202;
          }
        } else {
          sum += (float)0.087075844407;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
              sum += (float)-0.23621447384;
            } else {
              sum += (float)0.085835687816;
            }
          } else {
            sum += (float)0.27020427585;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
              sum += (float)0.25774413347;
            } else {
              sum += (float)-0.0023527115118;
            }
          } else {
            sum += (float)0.30692261457;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 156)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 46)) {
              sum += (float)-0.073224432766;
            } else {
              sum += (float)0.31810101867;
            }
          } else {
            sum += (float)0.30501699448;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 66)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 68)) {
              sum += (float)0.27132615447;
            } else {
              sum += (float)-0.070613592863;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 84)) {
              sum += (float)-0.4505392909;
            } else {
              sum += (float)0.20277734101;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 158)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 124)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 76)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 86)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
              sum += (float)0.30303677917;
            } else {
              sum += (float)0.050238799304;
            }
          } else {
            sum += (float)0.36339634657;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 62)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)-0.18622845411;
            } else {
              sum += (float)0.24063542485;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)-0.10401073843;
            } else {
              sum += (float)0.18683756888;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 156)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 130)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
              sum += (float)0.13415057957;
            } else {
              sum += (float)-0.085140101612;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 72)) {
              sum += (float)-0.13036821783;
            } else {
              sum += (float)-0.26228296757;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 160)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 110)) {
              sum += (float)0.31366664171;
            } else {
              sum += (float)-0.10285231471;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 194)) {
              sum += (float)-0.13150669634;
            } else {
              sum += (float)0.051007624716;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 80)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 74)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 48)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 116)) {
              sum += (float)-0.18491628766;
            } else {
              sum += (float)0.43764355779;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 62)) {
              sum += (float)0.067698135972;
            } else {
              sum += (float)-0.2765854001;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 98)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 88)) {
              sum += (float)0.25534725189;
            } else {
              sum += (float)0.85428315401;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 90)) {
              sum += (float)0.25516477227;
            } else {
              sum += (float)-0.18152996898;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 122)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 90)) {
              sum += (float)-0.0064753624611;
            } else {
              sum += (float)-0.25017410517;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 58)) {
              sum += (float)0.23582549393;
            } else {
              sum += (float)-0.10576757789;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 50)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 106)) {
              sum += (float)-0.26867589355;
            } else {
              sum += (float)-0.063336357474;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 106)) {
              sum += (float)0.24771365523;
            } else {
              sum += (float)-0.050612229854;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 58)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 14)) {
        sum += (float)0.23106689751;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 64)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 78)) {
            sum += (float)-0.26091104746;
          } else {
            sum += (float)-0.063441701233;
          }
        } else {
          sum += (float)0.10125023872;
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 8)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 176)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 20)) {
              sum += (float)0.30150336027;
            } else {
              sum += (float)0.017778277397;
            }
          } else {
            sum += (float)-0.042237356305;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 0)) {
            sum += (float)-0.36841496825;
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 20)) {
              sum += (float)-0.07429805398;
            } else {
              sum += (float)0.28576916456;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 18)) {
              sum += (float)-0.1777895689;
            } else {
              sum += (float)0.19946749508;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 88)) {
              sum += (float)0.23274086416;
            } else {
              sum += (float)0.30693715811;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 78)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 42)) {
              sum += (float)0.26895296574;
            } else {
              sum += (float)-0.20012165606;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 122)) {
              sum += (float)0.29849740863;
            } else {
              sum += (float)-0.020025145262;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 170)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 74)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 32)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
              sum += (float)0.08109754324;
            } else {
              sum += (float)0.29490548372;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 138)) {
              sum += (float)-0.2518812716;
            } else {
              sum += (float)0.18942387402;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 100)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 86)) {
              sum += (float)0.24179320037;
            } else {
              sum += (float)-0.0065292250365;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 150)) {
              sum += (float)0.43632149696;
            } else {
              sum += (float)0.13949072361;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 158)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 134)) {
              sum += (float)-0.0023408129346;
            } else {
              sum += (float)-0.18391534686;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 158)) {
              sum += (float)0.18714696169;
            } else {
              sum += (float)-0.057480033487;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 128)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 130)) {
              sum += (float)0.20009447634;
            } else {
              sum += (float)-0.11496206373;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 26)) {
              sum += (float)-0.24460576475;
            } else {
              sum += (float)0.040003597736;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 76)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 72)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 52)) {
              sum += (float)0.1297378093;
            } else {
              sum += (float)-0.18343099952;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 96)) {
              sum += (float)0.52083265781;
            } else {
              sum += (float)0.13691341877;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 170)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
              sum += (float)0.31402778625;
            } else {
              sum += (float)-0.2599773407;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 166)) {
              sum += (float)0.34212818742;
            } else {
              sum += (float)-0.15060473979;
            }
          }
        }
      } else {
        if (!(data[9].missing != -1) || (data[9].qvalue < 20)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 140)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 48)) {
              sum += (float)-0.067809283733;
            } else {
              sum += (float)0.30620768666;
            }
          } else {
            sum += (float)-0.12891286612;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 96)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 198)) {
              sum += (float)-0.062426816672;
            } else {
              sum += (float)0.25705528259;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 136)) {
              sum += (float)-0.28680846095;
            } else {
              sum += (float)-0.024700826034;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].qvalue < 80)) {
    if (!(data[7].missing != -1) || (data[7].qvalue < 28)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 16)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 20)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 184)) {
              sum += (float)0.29218658805;
            } else {
              sum += (float)0.048293482512;
            }
          } else {
            sum += (float)0.020667700097;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 2)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 144)) {
              sum += (float)0.026209773496;
            } else {
              sum += (float)0.27779012918;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
              sum += (float)-0.45013585687;
            } else {
              sum += (float)-0.0070504387841;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
            sum += (float)-0.47339266539;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
              sum += (float)0.001213978976;
            } else {
              sum += (float)0.27539569139;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 108)) {
              sum += (float)-0.13899546862;
            } else {
              sum += (float)0.25562486053;
            }
          } else {
            sum += (float)0.30066004395;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 202)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
            sum += (float)0.36633619666;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 100)) {
              sum += (float)-0.10823119432;
            } else {
              sum += (float)0.10404681414;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 214)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 60)) {
              sum += (float)-0.35906079412;
            } else {
              sum += (float)-0.09158988297;
            }
          } else {
            sum += (float)0.30925491452;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 130)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 40)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
              sum += (float)-0.17414331436;
            } else {
              sum += (float)0.15378767252;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 208)) {
              sum += (float)0.28241708875;
            } else {
              sum += (float)0.077451393008;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 86)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 62)) {
              sum += (float)0.013666435145;
            } else {
              sum += (float)-0.30953025818;
            }
          } else {
            sum += (float)0.23634693027;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 162)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 52)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 146)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 104)) {
              sum += (float)0.083358705044;
            } else {
              sum += (float)-0.19470089674;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 154)) {
              sum += (float)-0.041754294187;
            } else {
              sum += (float)0.55834168196;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 28)) {
            sum += (float)0.2682005167;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 142)) {
              sum += (float)-0.15309798717;
            } else {
              sum += (float)-0.26557707787;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 162)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 202)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 114)) {
              sum += (float)0.17432484031;
            } else {
              sum += (float)-0.11596591026;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 204)) {
              sum += (float)0.60310554504;
            } else {
              sum += (float)0.013571259566;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 150)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)0.56465089321;
            } else {
              sum += (float)0.026275472715;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 170)) {
              sum += (float)0.13292869925;
            } else {
              sum += (float)-0.21720968187;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 120)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 100)) {
              sum += (float)0.25264245272;
            } else {
              sum += (float)-0.0090946601704;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 82)) {
              sum += (float)-0.0016686184099;
            } else {
              sum += (float)-0.16517415643;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 100)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 176)) {
              sum += (float)0.46016430855;
            } else {
              sum += (float)-0.02060880512;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 198)) {
              sum += (float)-0.28657740355;
            } else {
              sum += (float)0.26114287972;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 174)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
              sum += (float)0.22449307144;
            } else {
              sum += (float)-0.18030254543;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 142)) {
              sum += (float)0.29538917542;
            } else {
              sum += (float)0.11381997913;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 100)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
              sum += (float)0.050504419953;
            } else {
              sum += (float)0.2735183537;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 102)) {
              sum += (float)0.060071770102;
            } else {
              sum += (float)-0.2561994195;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].qvalue < 52)) {
    if (!(data[8].missing != -1) || (data[8].qvalue < 16)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 42)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 12)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 176)) {
            sum += (float)0.28697890043;
          } else {
            sum += (float)0.098909057677;
          }
        } else {
          sum += (float)-0.093958429992;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 2)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 54)) {
              sum += (float)-0.13373927772;
            } else {
              sum += (float)0.20830608904;
            }
          } else {
            sum += (float)-0.64245903492;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 10)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 52)) {
              sum += (float)0.27533715963;
            } else {
              sum += (float)-0.17654807866;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 18)) {
              sum += (float)-0.34059423208;
            } else {
              sum += (float)0.17892281711;
            }
          }
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
              sum += (float)-0.27848529816;
            } else {
              sum += (float)0.080934032798;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
              sum += (float)0.23848518729;
            } else {
              sum += (float)-0.084730386734;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 30)) {
            sum += (float)0.2660472095;
          } else {
            sum += (float)-0.0068317973055;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 28)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 26)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 92)) {
              sum += (float)-0.38492834568;
            } else {
              sum += (float)0.2814142406;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 160)) {
              sum += (float)0.29085499048;
            } else {
              sum += (float)0.057578571141;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 62)) {
              sum += (float)-0.12982212007;
            } else {
              sum += (float)0.12257594615;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 38)) {
              sum += (float)-0.072678141296;
            } else {
              sum += (float)0.25066366792;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 172)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 110)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 100)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 88)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 98)) {
              sum += (float)0.075916588306;
            } else {
              sum += (float)0.33262711763;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 92)) {
              sum += (float)-0.25592601299;
            } else {
              sum += (float)0.10473240167;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 104)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 132)) {
              sum += (float)0.24510838091;
            } else {
              sum += (float)0.7864074707;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 98)) {
              sum += (float)0.28665831685;
            } else {
              sum += (float)-0.027234707028;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 188)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 68)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
              sum += (float)-0.097084373236;
            } else {
              sum += (float)0.054874639958;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 44)) {
              sum += (float)-0.017106071115;
            } else {
              sum += (float)-0.15372249484;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 142)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 202)) {
              sum += (float)0.23197133839;
            } else {
              sum += (float)-0.20582892001;
            }
          } else {
            sum += (float)-0.21093806624;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 124)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 228)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 112)) {
              sum += (float)-0.16349972785;
            } else {
              sum += (float)-0.28814700246;
            }
          } else {
            sum += (float)0.38395762444;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 74)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 18)) {
              sum += (float)0.09960039705;
            } else {
              sum += (float)0.37398174405;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 168)) {
              sum += (float)0.4369289279;
            } else {
              sum += (float)-0.15105430782;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 114)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 120)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 110)) {
              sum += (float)0.10525277257;
            } else {
              sum += (float)0.32712644339;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 144)) {
              sum += (float)-0.11167164147;
            } else {
              sum += (float)0.21262775362;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 116)) {
            sum += (float)0.087981760502;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
              sum += (float)-0.29889398813;
            } else {
              sum += (float)-0.06912714988;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].qvalue < 80)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 18)) {
        sum += (float)0.26828846335;
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 58)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 34)) {
            sum += (float)0.21416324377;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
              sum += (float)0.044104870409;
            } else {
              sum += (float)-0.20566119254;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 102)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 56)) {
              sum += (float)0.10754076391;
            } else {
              sum += (float)-0.14498960972;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 142)) {
              sum += (float)0.32905596495;
            } else {
              sum += (float)0.009439907968;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 16)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 32)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
              sum += (float)0.1415040791;
            } else {
              sum += (float)-0.0038207736798;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 14)) {
              sum += (float)-0.45213839412;
            } else {
              sum += (float)-0.061245687306;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 20)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
              sum += (float)0.2498934716;
            } else {
              sum += (float)-0.038712576032;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 84)) {
              sum += (float)0.041543930769;
            } else {
              sum += (float)0.28563040495;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 136)) {
            sum += (float)0.19256395102;
          } else {
            sum += (float)-0.21851193905;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
              sum += (float)-0.071190275252;
            } else {
              sum += (float)0.19429306686;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 6)) {
              sum += (float)0.11216522008;
            } else {
              sum += (float)0.28591382504;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 194)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 122)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 174)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
              sum += (float)-0.079917736351;
            } else {
              sum += (float)0.027185751125;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 92)) {
              sum += (float)0.31523144245;
            } else {
              sum += (float)0.044504594058;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 148)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
              sum += (float)0.089081205428;
            } else {
              sum += (float)0.30541661382;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 182)) {
              sum += (float)-0.1889821291;
            } else {
              sum += (float)0.20142604411;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 140)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 134)) {
              sum += (float)0.16076993942;
            } else {
              sum += (float)-0.098601691425;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 184)) {
              sum += (float)0.38370370865;
            } else {
              sum += (float)0.11251807213;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 120)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 146)) {
              sum += (float)0.075946770608;
            } else {
              sum += (float)-0.2777800858;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
              sum += (float)0.077870264649;
            } else {
              sum += (float)-0.27700316906;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 60)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 132)) {
          sum += (float)-0.0054249628447;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 36)) {
            sum += (float)0.061197225004;
          } else {
            sum += (float)0.4270196259;
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 168)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)0.21607112885;
            } else {
              sum += (float)-0.2534711659;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 124)) {
              sum += (float)0.35679128766;
            } else {
              sum += (float)-0.10387571156;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 162)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)0.10871840268;
            } else {
              sum += (float)0.54144835472;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 138)) {
              sum += (float)0.005697327666;
            } else {
              sum += (float)-0.26657235622;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].qvalue < 56)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 82)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 62)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 10)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
              sum += (float)0.21998952329;
            } else {
              sum += (float)-0.24046812952;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 40)) {
              sum += (float)0.25007677078;
            } else {
              sum += (float)0.06131163612;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 120)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 54)) {
              sum += (float)-0.31676718593;
            } else {
              sum += (float)0.050422430038;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 42)) {
              sum += (float)0.263117522;
            } else {
              sum += (float)-0.19326481223;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 84)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 164)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 12)) {
              sum += (float)0.26401114464;
            } else {
              sum += (float)0.51538336277;
            }
          } else {
            sum += (float)0.083200775087;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 70)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 106)) {
              sum += (float)-0.30834415555;
            } else {
              sum += (float)0.025680953637;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
              sum += (float)0.065929114819;
            } else {
              sum += (float)0.28421750665;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 12)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 10)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 4)) {
            sum += (float)0.028793277219;
          } else {
            sum += (float)-0.38183125854;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 8)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 130)) {
              sum += (float)0.091802015901;
            } else {
              sum += (float)0.25244641304;
            }
          } else {
            sum += (float)-0.17817036808;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
          sum += (float)-0.12418600172;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
            sum += (float)0.047784995288;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 144)) {
              sum += (float)0.28450512886;
            } else {
              sum += (float)0.060457956046;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 122)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 128)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 140)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)0.42522361875;
            } else {
              sum += (float)-0.08621942997;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 126)) {
              sum += (float)0.14828787744;
            } else {
              sum += (float)-0.087226077914;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 72)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 146)) {
              sum += (float)0.30408877134;
            } else {
              sum += (float)-0.26698771119;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 164)) {
              sum += (float)-0.22980801761;
            } else {
              sum += (float)0.09994032234;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 130)) {
          sum += (float)0.73825347424;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 144)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 134)) {
              sum += (float)-0.11463517696;
            } else {
              sum += (float)0.22773210704;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 218)) {
              sum += (float)0.010860475712;
            } else {
              sum += (float)-0.28197035193;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 140)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 156)) {
            sum += (float)0.13673779368;
          } else {
            sum += (float)-0.086425639689;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 184)) {
            sum += (float)0.32945501804;
          } else {
            sum += (float)0.091170333326;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 144)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 102)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 110)) {
              sum += (float)-0.033683154732;
            } else {
              sum += (float)0.54365295172;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 118)) {
              sum += (float)0.047525763512;
            } else {
              sum += (float)-0.20635305345;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 190)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
              sum += (float)-0.27809539437;
            } else {
              sum += (float)-0.015724759549;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 184)) {
              sum += (float)0.07560300827;
            } else {
              sum += (float)-0.16562259197;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].qvalue < 36)) {
    if (!(data[6].missing != -1) || (data[6].qvalue < 16)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 8)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 2)) {
          sum += (float)-0.015514199622;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 186)) {
            sum += (float)0.27737760544;
          } else {
            sum += (float)0.0070015364327;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 104)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
            sum += (float)0.19809424877;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 28)) {
              sum += (float)-0.56963557005;
            } else {
              sum += (float)-0.057909872383;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 14)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 4)) {
              sum += (float)0.24379065633;
            } else {
              sum += (float)-0.12842769921;
            }
          } else {
            sum += (float)0.26531708241;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 146)) {
          sum += (float)0.076528385282;
        } else {
          sum += (float)-0.15745541453;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 6)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
            sum += (float)-0.21192531288;
          } else {
            sum += (float)0.21885623038;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 20)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 38)) {
              sum += (float)-0.10160284489;
            } else {
              sum += (float)0.19972038269;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 20)) {
              sum += (float)0.081996493042;
            } else {
              sum += (float)0.29927673936;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 192)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 86)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 108)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 82)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 84)) {
              sum += (float)0.03412823379;
            } else {
              sum += (float)0.41345012188;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 72)) {
              sum += (float)0.10597383976;
            } else {
              sum += (float)-0.14706765115;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 150)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 152)) {
              sum += (float)0.47862848639;
            } else {
              sum += (float)0.068454541266;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 122)) {
              sum += (float)-0.10238230973;
            } else {
              sum += (float)0.16021490097;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 94)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 78)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 90)) {
              sum += (float)0.091934449971;
            } else {
              sum += (float)0.32253104448;
            }
          } else {
            sum += (float)0.014965551905;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 118)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 34)) {
              sum += (float)0.016639111564;
            } else {
              sum += (float)-0.11512475461;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 162)) {
              sum += (float)0.24311579764;
            } else {
              sum += (float)-0.0055489982478;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
        sum += (float)0.38350325823;
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 168)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 226)) {
              sum += (float)-0.20891317725;
            } else {
              sum += (float)0.3291246891;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 166)) {
              sum += (float)0.2699239254;
            } else {
              sum += (float)-0.10143660009;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 124)) {
            sum += (float)0.31505304575;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 84)) {
              sum += (float)0.09389360249;
            } else {
              sum += (float)-0.20434823632;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
    if (!(data[6].missing != -1) || (data[6].qvalue < 16)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
          sum += (float)-0.38588327169;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 8)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 32)) {
              sum += (float)-0.0084050698206;
            } else {
              sum += (float)-0.20390416682;
            }
          } else {
            sum += (float)0.18940675259;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 44)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 0)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 4)) {
              sum += (float)0.16480579972;
            } else {
              sum += (float)-0.14464826882;
            }
          } else {
            sum += (float)0.28585469723;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 24)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 2)) {
              sum += (float)0.23480831087;
            } else {
              sum += (float)-0.14998300374;
            }
          } else {
            sum += (float)0.24088120461;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 8)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 42)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 26)) {
            sum += (float)-0.27193716168;
          } else {
            sum += (float)0.054902750999;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 2)) {
            sum += (float)-0.12844017148;
          } else {
            sum += (float)0.26726493239;
          }
        }
      } else {
        sum += (float)0.2921782732;
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].qvalue < 192)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 34)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 44)) {
          sum += (float)0.045998334885;
        } else {
          sum += (float)0.26377522945;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 16)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 48)) {
              sum += (float)-0.0011117564281;
            } else {
              sum += (float)0.65117371082;
            }
          } else {
            sum += (float)-0.054844748229;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 136)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 28)) {
              sum += (float)-0.0073127178475;
            } else {
              sum += (float)0.19717565179;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 6)) {
              sum += (float)0.19386968017;
            } else {
              sum += (float)-0.18158623576;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 126)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
          sum += (float)0.31457784772;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 174)) {
              sum += (float)-0.22248606384;
            } else {
              sum += (float)0.073140390217;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 6)) {
              sum += (float)0.22236014903;
            } else {
              sum += (float)-0.08427901566;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 136)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 128)) {
              sum += (float)0.62084126472;
            } else {
              sum += (float)0.0071667772718;
            }
          } else {
            sum += (float)-0.06179908663;
          }
        } else {
          sum += (float)-0.19127079844;
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
    if (!(data[7].missing != -1) || (data[7].qvalue < 136)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 102)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 26)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 42)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
              sum += (float)-0.091829560697;
            } else {
              sum += (float)0.26099416614;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 220)) {
              sum += (float)-0.086449444294;
            } else {
              sum += (float)0.35858106613;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 78)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
              sum += (float)0.23072360456;
            } else {
              sum += (float)-0.04904454574;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 96)) {
              sum += (float)0.17446504533;
            } else {
              sum += (float)0.59973710775;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 158)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 156)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 162)) {
              sum += (float)0.065083697438;
            } else {
              sum += (float)0.34366881847;
            }
          } else {
            sum += (float)0.75986212492;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 92)) {
            sum += (float)0.050313018262;
          } else {
            sum += (float)-0.25295174122;
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 136)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 84)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 104)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 108)) {
              sum += (float)0.074149243534;
            } else {
              sum += (float)-0.17023395002;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 108)) {
              sum += (float)0.44689300656;
            } else {
              sum += (float)0.063313022256;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 170)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 92)) {
              sum += (float)0.35711225867;
            } else {
              sum += (float)-0.24200558662;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 160)) {
              sum += (float)-0.23446048796;
            } else {
              sum += (float)0.76197236776;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
            sum += (float)0.81009155512;
          } else {
            sum += (float)0.10784269869;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 128)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 0)) {
              sum += (float)-0.26874083281;
            } else {
              sum += (float)0.019100321457;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 128)) {
              sum += (float)-0.21095655859;
            } else {
              sum += (float)0.07038345933;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].qvalue < 120)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 12)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 10)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 30)) {
            sum += (float)0.25139400363;
          } else {
            sum += (float)0.046393848956;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 90)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 18)) {
              sum += (float)0.072698123753;
            } else {
              sum += (float)-0.35862141848;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 6)) {
              sum += (float)-0.047677725554;
            } else {
              sum += (float)0.1942024529;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
          sum += (float)-0.071790061891;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
            sum += (float)-0.010652408004;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 148)) {
              sum += (float)0.25422164798;
            } else {
              sum += (float)0.025685887784;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 154)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 132)) {
          sum += (float)0.26299843192;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 82)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 64)) {
              sum += (float)0.076227366924;
            } else {
              sum += (float)0.25505486131;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 110)) {
              sum += (float)-0.24158088863;
            } else {
              sum += (float)0.013212871738;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 80)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 126)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
              sum += (float)-0.36574137211;
            } else {
              sum += (float)-0.095858827233;
            }
          } else {
            sum += (float)0.079667761922;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 158)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 24)) {
              sum += (float)0.26189735532;
            } else {
              sum += (float)-0.097111217678;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 112)) {
              sum += (float)-0.19088996947;
            } else {
              sum += (float)0.020947190002;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].qvalue < 56)) {
    if (!(data[8].missing != -1) || (data[8].qvalue < 86)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 56)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 40)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 38)) {
              sum += (float)-0.054851364344;
            } else {
              sum += (float)-0.40119314194;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 10)) {
              sum += (float)-0.038646616042;
            } else {
              sum += (float)0.17680670321;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 26)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 10)) {
              sum += (float)0.12025607377;
            } else {
              sum += (float)-0.12792733312;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
              sum += (float)0.064733617008;
            } else {
              sum += (float)0.29035031796;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 120)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 36)) {
            sum += (float)0.17221833766;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 48)) {
              sum += (float)-0.33675301075;
            } else {
              sum += (float)-0.10417487472;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 70)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 88)) {
              sum += (float)0.3189009726;
            } else {
              sum += (float)0.0073875184171;
            }
          } else {
            sum += (float)-0.070067636669;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 156)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 32)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 60)) {
            sum += (float)0.23578073084;
          } else {
            sum += (float)-0.094491906464;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 188)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 166)) {
              sum += (float)0.26045787334;
            } else {
              sum += (float)0.61770051718;
            }
          } else {
            sum += (float)0.041290789843;
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 140)) {
          sum += (float)-0.1760135293;
        } else {
          sum += (float)0.23264746368;
        }
      }
    }
  } else {
    if (!(data[8].missing != -1) || (data[8].qvalue < 192)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 58)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 124)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 102)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
              sum += (float)-0.0090228300542;
            } else {
              sum += (float)0.26810833812;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 26)) {
              sum += (float)0.29652026296;
            } else {
              sum += (float)-0.13213245571;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 108)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 108)) {
              sum += (float)0.57796007395;
            } else {
              sum += (float)0.057123009115;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.35060831904;
            } else {
              sum += (float)-0.019776144996;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 114)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 116)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 84)) {
              sum += (float)0.09066401422;
            } else {
              sum += (float)-0.10559799522;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 96)) {
              sum += (float)0.30579024553;
            } else {
              sum += (float)0.033241197467;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 132)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 126)) {
              sum += (float)-0.010206256993;
            } else {
              sum += (float)0.39875930548;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 70)) {
              sum += (float)0.16006632149;
            } else {
              sum += (float)-0.13931821287;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 190)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 122)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 190)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 36)) {
              sum += (float)0.11565319449;
            } else {
              sum += (float)0.61631345749;
            }
          } else {
            sum += (float)-0.016471024603;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 124)) {
            sum += (float)-0.20043678582;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 182)) {
              sum += (float)0.00076627696399;
            } else {
              sum += (float)0.29553443193;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 136)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 132)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 216)) {
              sum += (float)0.090004488826;
            } else {
              sum += (float)-0.23077200353;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 190)) {
              sum += (float)-0.3159109354;
            } else {
              sum += (float)0.032685473561;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 198)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 194)) {
              sum += (float)0.21541957557;
            } else {
              sum += (float)-0.16913092136;
            }
          } else {
            sum += (float)0.42918613553;
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].qvalue < 24)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 192)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 86)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 30)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
            sum += (float)0.20257987082;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 74)) {
              sum += (float)-0.052142865956;
            } else {
              sum += (float)-0.19803513587;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 122)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 20)) {
              sum += (float)-0.018949737772;
            } else {
              sum += (float)0.1385923326;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 14)) {
              sum += (float)0.28809261322;
            } else {
              sum += (float)-0.070469461381;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 164)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 96)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 90)) {
              sum += (float)-0.002351801144;
            } else {
              sum += (float)0.2884632647;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 122)) {
              sum += (float)0.12168694288;
            } else {
              sum += (float)-0.11558318883;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 104)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 146)) {
              sum += (float)-0.1696190238;
            } else {
              sum += (float)0.45411857963;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 152)) {
              sum += (float)0.064122438431;
            } else {
              sum += (float)-0.17618969083;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 94)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 134)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 28)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 22)) {
              sum += (float)-0.23530553281;
            } else {
              sum += (float)-0.025828829035;
            }
          } else {
            sum += (float)0.084485471249;
          }
        } else {
          sum += (float)0.17945475876;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 128)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 166)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 138)) {
              sum += (float)0.13717840612;
            } else {
              sum += (float)-0.18166065216;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 110)) {
              sum += (float)0.070609427989;
            } else {
              sum += (float)0.54412215948;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 34)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
              sum += (float)0.017506767064;
            } else {
              sum += (float)0.28627127409;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 224)) {
              sum += (float)-0.16832897067;
            } else {
              sum += (float)0.28268307447;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
      sum += (float)0.25216278434;
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 6)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 140)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 36)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
              sum += (float)-0.06865683198;
            } else {
              sum += (float)0.17654433846;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 22)) {
              sum += (float)-0.34638291597;
            } else {
              sum += (float)-0.02064804174;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 6)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
              sum += (float)0.14488252997;
            } else {
              sum += (float)-0.21471150219;
            }
          } else {
            sum += (float)0.22543132305;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 50)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 10)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 56)) {
              sum += (float)-0.12598291039;
            } else {
              sum += (float)0.18525153399;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 16)) {
              sum += (float)0.066916555166;
            } else {
              sum += (float)0.28372573853;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 154)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 110)) {
              sum += (float)0.22706143558;
            } else {
              sum += (float)0.01777339913;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 106)) {
              sum += (float)-0.24478685856;
            } else {
              sum += (float)0.037656039;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].qvalue < 56)) {
    if (!(data[8].missing != -1) || (data[8].qvalue < 80)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 64)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 40)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 10)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 32)) {
              sum += (float)-0.34222048521;
            } else {
              sum += (float)-0.071741111577;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 18)) {
              sum += (float)-0.036904405802;
            } else {
              sum += (float)0.18734434247;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 26)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 46)) {
              sum += (float)0.17260468006;
            } else {
              sum += (float)-0.055125825107;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 40)) {
              sum += (float)0.28925901651;
            } else {
              sum += (float)0.055494766682;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 98)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 100)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 30)) {
              sum += (float)0.15810270607;
            } else {
              sum += (float)-0.11865147203;
            }
          } else {
            sum += (float)-0.2879422605;
          }
        } else {
          if (!(data[9].missing != -1) || (data[9].qvalue < 12)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 182)) {
              sum += (float)0.26090300083;
            } else {
              sum += (float)-0.011086600833;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 24)) {
              sum += (float)-0.13445648551;
            } else {
              sum += (float)0.14551353455;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 84)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 164)) {
          if (!(data[9].missing != -1) || (data[9].qvalue < 12)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 90)) {
              sum += (float)-0.049392458051;
            } else {
              sum += (float)0.24530614913;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 106)) {
              sum += (float)0.20629251003;
            } else {
              sum += (float)0.45771887898;
            }
          }
        } else {
          sum += (float)0.02323709242;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 70)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 102)) {
            sum += (float)-0.23404420912;
          } else {
            sum += (float)0.014844245277;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
            sum += (float)0.044219560921;
          } else {
            sum += (float)0.2549790442;
          }
        }
      }
    }
  } else {
    if (!(data[8].missing != -1) || (data[8].qvalue < 164)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 84)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 76)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 142)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 54)) {
              sum += (float)-0.11929207295;
            } else {
              sum += (float)0.23852397501;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 64)) {
              sum += (float)0.086480744183;
            } else {
              sum += (float)-0.24232755601;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 70)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 86)) {
              sum += (float)0.48287725449;
            } else {
              sum += (float)0.11639954895;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
              sum += (float)-0.11978592724;
            } else {
              sum += (float)0.267950207;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
          sum += (float)0.34651076794;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 80)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 92)) {
              sum += (float)0.030284803361;
            } else {
              sum += (float)-0.16330042481;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 90)) {
              sum += (float)-0.3001408577;
            } else {
              sum += (float)-0.018824987113;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 118)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 178)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 124)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 172)) {
              sum += (float)0.16614985466;
            } else {
              sum += (float)-0.10509318858;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 52)) {
              sum += (float)-0.058531206101;
            } else {
              sum += (float)-0.25669670105;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 186)) {
            sum += (float)0.89240789413;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 118)) {
              sum += (float)0.38274270296;
            } else {
              sum += (float)-0.21331165731;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 196)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
              sum += (float)-0.091826982796;
            } else {
              sum += (float)0.45957887173;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.11717116833;
            } else {
              sum += (float)-0.18973277509;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 180)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 118)) {
              sum += (float)0.41188451648;
            } else {
              sum += (float)-0.063308149576;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 204)) {
              sum += (float)-0.11767788976;
            } else {
              sum += (float)0.067256487906;
            }
          }
        }
      }
    }
  }

  sum = sum + (float)(-0);
  if (!pred_margin) {
    return pred_transform(sum);
  } else {
    return sum;
  }
}
