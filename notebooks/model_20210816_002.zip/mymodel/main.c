static const int th_len[] = {
  16, 6, 66, 164, 67, 35, 92, 57, 43, 
};
static const int th_begin[] = {
  0, 16, 22, 88, 252, 319, 354, 446, 503, 
};
static const float threshold[] = {
  3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 10.5, 11.5, 12.5, 13.5, 14.5, 15.5, 16.5, 
  17.5, 18.5, 0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 0.061142161, 0.2123111, 0.21644583, 
  0.27667719, 0.34110421, 0.34208447, 0.34579301, 0.36120266, 0.43918574, 
  0.44369352, 0.52785075, 0.56551117, 0.58151007, 0.68232501, 0.71808392, 
  0.75116158, 0.75730211, 0.77931976, 0.7800529, 0.78089452, 0.81295252, 
  0.81769842, 0.82092476, 0.82321513, 0.83097517, 0.84442341, 0.85559821, 
  0.85676777, 0.8572253, 0.86463237, 0.8697505, 0.87326431, 0.87611806, 
  0.87977386, 0.88320804, 0.88520628, 0.88810736, 0.88860434, 0.88862753, 
  0.888686, 0.89270389, 0.89525938, 0.89541513, 0.89879954, 0.90047741, 
  0.90179729, 0.90861392, 0.91775322, 0.9323386, 0.94373679, 0.95256823, 
  0.95384324, 0.96436119, 0.96720546, 0.96951783, 0.97304255, 0.97603321, 
  0.97741437, 0.97748709, 0.97755629, 0.97898299, 0.98115206, 0.987378, 
  0.99125099, 0.99152178, 0.99275303, 4196.6523, 4452.3945, 4464.5391, 
  4643.4619, 4795.9678, 5038.4434, 5046.4336, 5104.2251, 6227.1279, 6775.0352, 
  7328.6899, 7676.749, 7912.7192, 7929.3623, 8377.0645, 8389.0615, 8401.7197, 
  8435.9727, 8436.5859, 8440.3379, 8484.3291, 8562.2646, 8562.3984, 8563.6738, 
  8564.2451, 8610.9316, 8637.2305, 8747.3945, 8758.668, 9389.7012, 9422.1367, 
  9424.6953, 9561.7832, 9567.5371, 9580.9502, 9600.2734, 9778.7852, 9779.125, 
  9840.8105, 10024.605, 10544.961, 10714.199, 11607.885, 11830.957, 11846.491, 
  12081.874, 12395.878, 12482.59, 12613.979, 12627.342, 12632.123, 13320.779, 
  13508.229, 13517.706, 13517.894, 13793.635, 14191.439, 14867.099, 15583.071, 
  16348.267, 17608.189, 17826.236, 17830.793, 17895.949, 17903.947, 17908.293, 
  17908.59, 17922.078, 17970.787, 17970.977, 17977.752, 17991.945, 18022.445, 
  18056.055, 18067.439, 18085.213, 18139.055, 18196.293, 18305.07, 18953.215, 
  20315.436, 20608.16, 20719.586, 20751.57, 20942.789, 22040.365, 22161.141, 
  22392.01, 22394.963, 22636.834, 22667.98, 22737.875, 23061.922, 23069.945, 
  23859.445, 24306.143, 24385.984, 24557.512, 25220.662, 25892.086, 25946.781, 
  25968.387, 26068.215, 26173.258, 27163.148, 27748.195, 27768.988, 28097.906, 
  28283.59, 28318.719, 28738.123, 28863.27, 29135.584, 29135.805, 29398.27, 
  29436.234, 29444.207, 32404.645, 32494.004, 32504.293, 32769.949, 32901.836, 
  32904.633, 33059.176, 33103.359, 33204.898, 33224.68, 33284.891, 33414.129, 
  33424.453, 33578.203, 33632.57, 33724.773, 33761.137, 33816.785, 33833.891, 
  33870.125, 34047.305, 34205.953, 34438.414, 34440.289, 34468.617, 34476.289, 
  34569.57, 34602.648, 34646.133, 34655.742, 34767.352, 34859.328, 34862.281, 
  35435.418, 35663.949, 35672.508, 35689.359, 35764.379, 35890.297, 36160.312, 
  37223.461, 40060.57, 40675.641, 43112.641, 43497.469, 43577.23, 45309.102, 
  0.090723671, 0.11073734, 0.11109956, 0.11597086, 0.11884287, 0.12272927, 
  0.1255687, 0.1359396, 0.15563726, 0.1943607, 0.20315292, 0.20471258, 
  0.20725089, 0.20808357, 0.20933199, 0.22661361, 0.26392764, 0.26824015, 
  0.27317053, 0.27336848, 0.3072542, 0.3185631, 0.32216871, 0.34257525, 
  0.35942936, 0.36394721, 0.44686413, 0.48893952, 0.48907396, 0.50122583, 
  0.52046537, 0.53525871, 0.56943524, 0.58810461, 0.66747892, 0.7082715, 
  0.7097373, 0.77013731, 0.78644371, 0.79053044, 0.82642519, 0.82701099, 
  0.93220484, 0.93556201, 1.0134717, 1.1817471, 1.2502372, 1.3671944, 
  1.8576022, 1.903964, 1.9852427, 2.0824316, 2.2456911, 2.5825849, 2.6581285, 
  3.3143916, 5.3388691, 6.1242676, 6.4294257, 6.7538986, 15.517994, 16.723423, 
  16.877569, 18.214405, 35.315231, 38.96434, 57.762417, 0.10851243, 0.13489638, 
  0.13886034, 0.15297833, 0.16143674, 0.18465395, 0.18616921, 0.19827712, 
  0.20394233, 0.20616888, 0.22056171, 0.22113661, 0.23406672, 0.23672324, 
  0.33321083, 0.3623358, 0.40564406, 0.40805545, 0.50210333, 0.68856502, 
  0.94682539, 1.8179333, 2.0349648, 2.2656181, 2.4574842, 2.6028843, 2.6816721, 
  5.9259443, 6.3816938, 23.35635, 27.670515, 28.198708, 35.273849, 42.23278, 
  86.127777, 0.86000502, 0.90970027, 1.0683886, 1.1037583, 1.1125358, 
  1.1303189, 1.1337547, 1.3012383, 1.3042848, 1.3143113, 1.3237696, 1.3251801, 
  1.4011885, 1.4207594, 1.513351, 1.5182519, 1.5877903, 1.5885384, 1.5889752, 
  1.6675937, 1.6724412, 1.6727939, 1.7023456, 1.7123022, 1.718276, 1.7559266, 
  1.7688251, 1.7856445, 1.825013, 1.8267727, 1.8289812, 1.8323578, 1.8348476, 
  1.835259, 1.836664, 1.8427513, 1.8470649, 1.8472219, 1.8534768, 1.8779252, 
  1.8865496, 1.9241742, 1.924445, 1.9260368, 1.9342816, 1.9344537, 1.9345915, 
  1.9521947, 1.953464, 1.9778806, 1.9786904, 1.9793737, 1.9806025, 1.9870276, 
  1.9888356, 1.9895951, 1.9958665, 2.0279846, 2.0329528, 2.0357807, 2.0401063, 
  2.0421765, 2.0486255, 2.0586138, 2.0630765, 2.0776849, 2.0779066, 2.0792294, 
  2.0991392, 2.1015654, 2.1070926, 2.1113167, 2.111691, 2.1132443, 2.1181521, 
  2.1210294, 2.1422763, 2.1471639, 2.1473439, 2.1550212, 2.1554184, 2.1563413, 
  2.1587503, 2.1638093, 2.1694968, 2.1705644, 2.1757474, 2.1895318, 2.1970077, 
  2.2074308, 2.2443819, 2.2614157, 0.54539156, 0.54551816, 0.58420753, 
  0.62250638, 0.64837003, 0.6646204, 0.84151256, 1.0386398, 1.2910268, 
  1.3806248, 1.4762337, 1.5238035, 1.6268783, 1.7468501, 1.8482418, 1.86145, 
  1.8745422, 1.9106541, 2.4860458, 2.8513465, 2.9370761, 2.9556451, 3.2308245, 
  3.2893562, 3.3699312, 4.5457749, 5.0415974, 5.0690088, 5.2685733, 7.5770655, 
  10.308762, 11.164842, 12.469914, 12.637712, 22.853554, 24.29664, 31.261585, 
  39.537003, 71.407333, 75.355438, 210.34129, 285.9057, 423.92413, 425.00705, 
  769.99103, 1011.1619, 2305.5554, 2509.7876, 4268.5459, 5778.0005, 7569.709, 
  8104.6997, 13097.248, 14593.271, 27353.43, 101962.5, 275908.94, 0.22449347, 
  0.23816338, 0.25888264, 0.27414912, 0.30562931, 0.35047919, 0.35979348, 
  0.39422363, 0.39787647, 0.40279803, 0.41445887, 0.54257751, 0.57334828, 
  0.58091331, 0.7210778, 0.77049482, 0.97423184, 1.1294391, 1.218817, 
  1.2866766, 1.3134547, 1.6055461, 1.9044127, 1.911571, 2.1319761, 8.6722355, 
  10.158951, 17.206388, 17.426476, 59.447845, 69.824966, 77.641434, 139.41, 
  175.13928, 314.45978, 447.52859, 1270.3025, 1306.6968, 1933.0928, 2921.5908, 
  3789.3408, 20302.223, 1292369.1, 
};

#include <stdlib.h>

/*
 * \brief function to convert a feature value into bin index.
 * \param val feature value, in floating-point
 * \param fid feature identifier
 * \return bin index corresponding to given feature value
 */
static inline int quantize(float val, unsigned fid) {
  const size_t offset = th_begin[fid];
  const float* array = &threshold[offset];
  int len = th_len[fid];
  int low = 0;
  int high = len;
  int mid;
  float mval;
  // It is possible th_begin[i] == [total_num_threshold]. This means that
  // all features i, (i+1), ... are not used for any of the splits in the model.
  // So in this case, just return something
  if (offset == 546 || val < array[0]) {
    return -10;
  }
  while (low + 1 < high) {
    mid = (low + high) / 2;
    mval = array[mid];
    if (val == mval) {
      return mid * 2;
    } else if (val < mval) {
      high = mid;
    } else {
      low = mid;
    }
  }
  if (array[low] == val) {
    return low * 2;
  } else if (high == len) {
    return len * 2;
  } else {
    return low * 2 + 1;
  }
}

#include "header.h"

const unsigned char is_categorical[] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 
};

size_t get_num_output_group(void) {
  return 1;
}

size_t get_num_feature(void) {
  return 9;
}

const char* get_pred_transform(void) {
  return "sigmoid";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_global_bias(void) {
  return -0.0;
}

static inline float pred_transform(float margin) {
  const float alpha = (float)1.0;
  return 1.0f / (1 + expf(-alpha * margin));
}
float predict(union Entry* data, int pred_margin) {

  for (int i = 0; i < 9; ++i) {
    if (data[i].missing != -1 && !is_categorical[i]) {
      data[i].qvalue = quantize(data[i].fvalue, i);
    }
  }
  float sum = 0.0f;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 16)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 14)) {
          sum += (float)0.57375746965;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
              sum += (float)-0;
            } else {
              sum += (float)0.47142857313;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
              sum += (float)0.15000000596;
            } else {
              sum += (float)-0.30000001192;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
          sum += (float)0.52500003576;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 142)) {
              sum += (float)0.3789473772;
            } else {
              sum += (float)-0.22500000894;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 274)) {
              sum += (float)-0.47569721937;
            } else {
              sum += (float)0.38181820512;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
        sum += (float)0.59621798992;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 124)) {
              sum += (float)0.54000002146;
            } else {
              sum += (float)0.23636364937;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 78)) {
              sum += (float)0.27272728086;
            } else {
              sum += (float)-0.2160000205;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 28)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 124)) {
              sum += (float)0.45000001788;
            } else {
              sum += (float)-0.040000002831;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 176)) {
              sum += (float)0.56528925896;
            } else {
              sum += (float)0.27272728086;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 36)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 128)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 38)) {
            sum += (float)0.57808220387;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.34015750885;
            } else {
              sum += (float)-0.13186813891;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 32)) {
              sum += (float)0.45365855098;
            } else {
              sum += (float)-0.10807453841;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 14)) {
              sum += (float)0.15000000596;
            } else {
              sum += (float)-0.55781251192;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 64)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 290)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 18)) {
              sum += (float)-0.080672279;
            } else {
              sum += (float)-0.55806273222;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 70)) {
              sum += (float)0.42524272203;
            } else {
              sum += (float)-0.13505534828;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 110)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 318)) {
              sum += (float)-0.16363637149;
            } else {
              sum += (float)0.51428574324;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 80)) {
              sum += (float)0.58079999685;
            } else {
              sum += (float)0.07500000298;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 98)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 60)) {
          sum += (float)0.55254238844;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 100)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 98)) {
              sum += (float)0.41379311681;
            } else {
              sum += (float)-0;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 48)) {
              sum += (float)-0;
            } else {
              sum += (float)-0.38181820512;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 200)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 158)) {
              sum += (float)0.47368425131;
            } else {
              sum += (float)-0.23478262126;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 30)) {
              sum += (float)-0;
            } else {
              sum += (float)0.53684210777;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 128)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 66)) {
              sum += (float)0.48000001907;
            } else {
              sum += (float)0.12000000477;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 46)) {
              sum += (float)0.24000000954;
            } else {
              sum += (float)-0.42857146263;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 42)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 10)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 6)) {
            sum += (float)0.46203097701;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
              sum += (float)0.41284695268;
            } else {
              sum += (float)-0.0010180898244;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 104)) {
            sum += (float)0.4309758842;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 4)) {
              sum += (float)0.38742518425;
            } else {
              sum += (float)-0.010912053287;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 82)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
            sum += (float)0.45519420505;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.27506515384;
            } else {
              sum += (float)-0.12362030894;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 8)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 34)) {
              sum += (float)0.011117145419;
            } else {
              sum += (float)0.41248345375;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)-0.079822167754;
            } else {
              sum += (float)-0.39867377281;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
        sum += (float)0.4638825953;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 92)) {
          sum += (float)0.45668315887;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 30)) {
              sum += (float)0.39992409945;
            } else {
              sum += (float)-0.075575478375;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 132)) {
              sum += (float)0.45098468661;
            } else {
              sum += (float)0.31364554167;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 48)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 58)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 64)) {
            sum += (float)0.50286501646;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 2)) {
              sum += (float)0.43142050505;
            } else {
              sum += (float)0.13489799201;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 282)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 58)) {
              sum += (float)0.5736053586;
            } else {
              sum += (float)-0.34613707662;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 0)) {
              sum += (float)-0.090650469065;
            } else {
              sum += (float)0.37478667498;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 88)) {
          sum += (float)0.49383664131;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 24)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 10)) {
              sum += (float)0.48665419221;
            } else {
              sum += (float)0.21776269376;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 254)) {
              sum += (float)-0.18550996482;
            } else {
              sum += (float)0.41055652499;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 98)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 44)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 40)) {
              sum += (float)0.39007166028;
            } else {
              sum += (float)0.01389716845;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
              sum += (float)-0.37423822284;
            } else {
              sum += (float)0.40159726143;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 322)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
              sum += (float)-0.43347132206;
            } else {
              sum += (float)-0.0027175087016;
            }
          } else {
            sum += (float)0.58492028713;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 132)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 86)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 100)) {
              sum += (float)0.086880929768;
            } else {
              sum += (float)0.38691774011;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 80)) {
              sum += (float)0.19139777124;
            } else {
              sum += (float)-0.26792001724;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 216)) {
            sum += (float)0.4661949873;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 314)) {
              sum += (float)0.036937404424;
            } else {
              sum += (float)0.31585416198;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 48)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 6)) {
          sum += (float)0.40199434757;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 130)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 32)) {
              sum += (float)0.047705907375;
            } else {
              sum += (float)0.40859621763;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 6)) {
              sum += (float)0.35790964961;
            } else {
              sum += (float)-0.10582251847;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 86)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 46)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 28)) {
              sum += (float)0.15334016085;
            } else {
              sum += (float)0.39829233289;
            }
          } else {
            sum += (float)0.060466367751;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 168)) {
              sum += (float)0.16462065279;
            } else {
              sum += (float)-0.26590007544;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 286)) {
              sum += (float)-0.36117085814;
            } else {
              sum += (float)0.41034761071;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 8)) {
          sum += (float)0.40317347646;
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 32)) {
              sum += (float)0.35596430302;
            } else {
              sum += (float)-0.10216004401;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 0)) {
              sum += (float)0.10324210674;
            } else {
              sum += (float)0.37843069434;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 102)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
            sum += (float)0.027922796085;
          } else {
            sum += (float)0.39351311326;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 24)) {
              sum += (float)0.43136289716;
            } else {
              sum += (float)-0.036468863487;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 116)) {
              sum += (float)0.12181211263;
            } else {
              sum += (float)0.38536757231;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 58)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 86)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 68)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.1277140975;
            } else {
              sum += (float)-0.26233333349;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 140)) {
              sum += (float)0.43440976739;
            } else {
              sum += (float)0.23047089577;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 82)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 40)) {
              sum += (float)0.40065968037;
            } else {
              sum += (float)0.6032537818;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 44)) {
              sum += (float)0.38963630795;
            } else {
              sum += (float)-0.049130346626;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 76)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 66)) {
              sum += (float)0.37490206957;
            } else {
              sum += (float)0.023135446012;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 46)) {
              sum += (float)0.2254512161;
            } else {
              sum += (float)0.4681724906;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 256)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
              sum += (float)-0.3097794652;
            } else {
              sum += (float)0.055718142539;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.050574336201;
            } else {
              sum += (float)0.3629489243;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 98)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 2)) {
          sum += (float)0.48372510076;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 322)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
              sum += (float)-0.3678175807;
            } else {
              sum += (float)-0.089145883918;
            }
          } else {
            sum += (float)0.44547018409;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 70)) {
          sum += (float)0.39774721861;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 104)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 102)) {
              sum += (float)0.16546063125;
            } else {
              sum += (float)-0.25833597779;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 146)) {
              sum += (float)0.29450830817;
            } else {
              sum += (float)-0.051590338349;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
      sum += (float)0.36810183525;
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 82)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 170)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 28)) {
              sum += (float)0.39002531767;
            } else {
              sum += (float)0.081320531666;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
              sum += (float)0.27118602395;
            } else {
              sum += (float)-0.28148016334;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 152)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 4)) {
              sum += (float)0.075353890657;
            } else {
              sum += (float)-0.43159177899;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 34)) {
              sum += (float)0.33677148819;
            } else {
              sum += (float)-0.030302869156;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 162)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 186)) {
            sum += (float)0.3544793725;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 194)) {
              sum += (float)-0.6676710844;
            } else {
              sum += (float)0.35139635205;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 88)) {
              sum += (float)0.23755206168;
            } else {
              sum += (float)-0.15942633152;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 166)) {
              sum += (float)0.061222597957;
            } else {
              sum += (float)0.34417173266;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 42)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 126)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)0.33671027422;
            } else {
              sum += (float)0.16928696632;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 128)) {
              sum += (float)-0.057997509837;
            } else {
              sum += (float)0.59278434515;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
            sum += (float)0.45127162337;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 68)) {
              sum += (float)0.10794007033;
            } else {
              sum += (float)-0.32444000244;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 292)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 18)) {
              sum += (float)0.25237432122;
            } else {
              sum += (float)-0.33537751436;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 82)) {
              sum += (float)-0.053543414921;
            } else {
              sum += (float)0.3521809876;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 94)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 308)) {
              sum += (float)0.5702560544;
            } else {
              sum += (float)-0.056135382503;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 320)) {
              sum += (float)-0.1793615371;
            } else {
              sum += (float)0.40883827209;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 110)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 78)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 54)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 94)) {
              sum += (float)0.32995146513;
            } else {
              sum += (float)-0.0032994726207;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 76)) {
              sum += (float)0.40259557962;
            } else {
              sum += (float)0.6713578701;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 42)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 12)) {
              sum += (float)0.37572610378;
            } else {
              sum += (float)0.17938870192;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 154)) {
              sum += (float)0.23411349952;
            } else {
              sum += (float)-0.1861435473;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 68)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 64)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 68)) {
              sum += (float)0.31244170666;
            } else {
              sum += (float)-0.078446157277;
            }
          } else {
            sum += (float)0.51905429363;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 246)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 90)) {
              sum += (float)-0.25665056705;
            } else {
              sum += (float)0.32922539115;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
              sum += (float)-0.033001136035;
            } else {
              sum += (float)0.44995141029;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
      sum += (float)0.34604588151;
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 82)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 170)) {
              sum += (float)0.36592781544;
            } else {
              sum += (float)0.14979192615;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 138)) {
              sum += (float)0.20252226293;
            } else {
              sum += (float)-0.24553841352;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 152)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 4)) {
              sum += (float)0.064815476537;
            } else {
              sum += (float)-0.38523697853;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 34)) {
              sum += (float)0.28468182683;
            } else {
              sum += (float)-0.022002726793;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 100)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 32)) {
            sum += (float)0.34802681208;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
              sum += (float)-0.084038227797;
            } else {
              sum += (float)0.19725522399;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 218)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 90)) {
              sum += (float)0.30423104763;
            } else {
              sum += (float)0.047900471836;
            }
          } else {
            sum += (float)0.35096347332;
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 56)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 90)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 134)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 54)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)0.22649662197;
            } else {
              sum += (float)0.38060426712;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 62)) {
              sum += (float)0.28860837221;
            } else {
              sum += (float)-0.068388476968;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 56)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.023696718737;
            } else {
              sum += (float)0.39326411486;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 234)) {
              sum += (float)-0.064389318228;
            } else {
              sum += (float)0.29980820417;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 22)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)0.26796278358;
            } else {
              sum += (float)-0.09562304616;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 6)) {
              sum += (float)0.34642612934;
            } else {
              sum += (float)0.10355837643;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 298)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 68)) {
              sum += (float)-0.2055092901;
            } else {
              sum += (float)0.31981492043;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.43140920997;
            } else {
              sum += (float)0.11561892182;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 20)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 74)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 52)) {
            sum += (float)-0.050992708653;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 8)) {
              sum += (float)0.46264079213;
            } else {
              sum += (float)0.25870805979;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
            sum += (float)-0.3216676414;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 116)) {
              sum += (float)-0.0044716070406;
            } else {
              sum += (float)0.43127727509;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 80)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
              sum += (float)0.29299724102;
            } else {
              sum += (float)-0.19566442072;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
              sum += (float)0.39314219356;
            } else {
              sum += (float)0.12285257876;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 48)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 112)) {
              sum += (float)-0.14755302668;
            } else {
              sum += (float)0.36335328221;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 292)) {
              sum += (float)-0.30704551935;
            } else {
              sum += (float)0.014229868539;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 48)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 20)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 0)) {
          sum += (float)0.33045557141;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
              sum += (float)0.33214241266;
            } else {
              sum += (float)0.12923388183;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 134)) {
              sum += (float)0.22631016374;
            } else {
              sum += (float)-0.26715022326;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 86)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 20)) {
              sum += (float)0.113369748;
            } else {
              sum += (float)0.32906782627;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 72)) {
              sum += (float)0.19279886782;
            } else {
              sum += (float)-0.12826614082;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
            sum += (float)0.26901212335;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 18)) {
              sum += (float)0.31724083424;
            } else {
              sum += (float)-0.19407004118;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 10)) {
        sum += (float)0.33221960068;
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 80)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 180)) {
            sum += (float)0.32646998763;
          } else {
            sum += (float)0.081766083837;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 104)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
              sum += (float)0.14792922139;
            } else {
              sum += (float)-0.53015089035;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 250)) {
              sum += (float)0.16161869466;
            } else {
              sum += (float)0.33662503958;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 58)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 84)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 72)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 14)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)0.017119206488;
            } else {
              sum += (float)0.36874383688;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
              sum += (float)-0.18217559159;
            } else {
              sum += (float)0.16515365243;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 212)) {
            sum += (float)0.39506867528;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 260)) {
              sum += (float)-0.16989092529;
            } else {
              sum += (float)0.26940134168;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 76)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 34)) {
              sum += (float)0.19885919988;
            } else {
              sum += (float)-0.066255286336;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 88)) {
              sum += (float)0.1824926585;
            } else {
              sum += (float)0.43009209633;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 264)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 76)) {
              sum += (float)-0.20117096603;
            } else {
              sum += (float)0.14983864129;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.00064152415143;
            } else {
              sum += (float)0.30176350474;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 38)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 22)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 36)) {
              sum += (float)0.33700633049;
            } else {
              sum += (float)-0.28486886621;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
              sum += (float)0.55179530382;
            } else {
              sum += (float)0.14578162134;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 2)) {
            sum += (float)0.39652869105;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
              sum += (float)-0.21541132033;
            } else {
              sum += (float)0.29497110844;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 94)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 266)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
              sum += (float)-0.30309909582;
            } else {
              sum += (float)-0.10924629122;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 92)) {
              sum += (float)0.37307888269;
            } else {
              sum += (float)-0.16602577269;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 126)) {
            sum += (float)-0.26094707847;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 74)) {
              sum += (float)0.69691085815;
            } else {
              sum += (float)0.19894330204;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 52)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 26)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 0)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 34)) {
            sum += (float)0.33251395822;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 36)) {
              sum += (float)0.024311086163;
            } else {
              sum += (float)0.17798724771;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 112)) {
            sum += (float)0.34481412172;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 28)) {
              sum += (float)0.24847757816;
            } else {
              sum += (float)-0.0731671229;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 96)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 50)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 46)) {
              sum += (float)0.26552635431;
            } else {
              sum += (float)-0.069557830691;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)0.37363010645;
            } else {
              sum += (float)0.076731517911;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 284)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)-0.0034724734724;
            } else {
              sum += (float)-0.25940510631;
            }
          } else {
            sum += (float)0.33542540669;
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 8)) {
        sum += (float)0.32249671221;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 106)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 42)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 80)) {
              sum += (float)0.277256459;
            } else {
              sum += (float)0.077005624771;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 44)) {
              sum += (float)0.29802545905;
            } else {
              sum += (float)0.50419127941;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 28)) {
              sum += (float)0.29840368032;
            } else {
              sum += (float)-0.11424969137;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 180)) {
              sum += (float)0.27864927053;
            } else {
              sum += (float)0.067330725491;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 48)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 26)) {
              sum += (float)0.29927194118;
            } else {
              sum += (float)-0.033611804247;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 114)) {
              sum += (float)0.20361100137;
            } else {
              sum += (float)0.67505371571;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 28)) {
              sum += (float)0.36283940077;
            } else {
              sum += (float)-0.014746156521;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
              sum += (float)-0.19542957842;
            } else {
              sum += (float)0.036812435836;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 144)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 120)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 78)) {
              sum += (float)0.20102410018;
            } else {
              sum += (float)0.39302381873;
            }
          } else {
            sum += (float)0.55780357122;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 248)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 44)) {
              sum += (float)0.3715903163;
            } else {
              sum += (float)-0.18494470417;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
              sum += (float)0.093539655209;
            } else {
              sum += (float)0.3671361208;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 32)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 112)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 4)) {
              sum += (float)0.34740686417;
            } else {
              sum += (float)-0.13620403409;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
              sum += (float)0.35471230745;
            } else {
              sum += (float)0.042923677713;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 26)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 324)) {
              sum += (float)-0.28143936396;
            } else {
              sum += (float)0.34639295936;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 36)) {
              sum += (float)0.24899834394;
            } else {
              sum += (float)-0.22196337581;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 230)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 208)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 102)) {
              sum += (float)-0.038462460041;
            } else {
              sum += (float)0.27735978365;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 72)) {
              sum += (float)0.84031909704;
            } else {
              sum += (float)0.16882237792;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 316)) {
            sum += (float)-0.25726866722;
          } else {
            sum += (float)0.22189757228;
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
      sum += (float)0.31420949101;
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 160)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 58)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 28)) {
              sum += (float)0.057225767523;
            } else {
              sum += (float)-0.21875955164;
            }
          } else {
            sum += (float)0.29196810722;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
            sum += (float)0.32700717449;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 108)) {
              sum += (float)-0.33139762282;
            } else {
              sum += (float)0.25750762224;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 16)) {
          sum += (float)0.27006241679;
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 52)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 84)) {
              sum += (float)0.14080399275;
            } else {
              sum += (float)-0.4061858952;
            }
          } else {
            sum += (float)0.22941763699;
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 34)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
          sum += (float)0.36843496561;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 22)) {
              sum += (float)0.26485791802;
            } else {
              sum += (float)-0.24185438454;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 100)) {
              sum += (float)-0.077298253775;
            } else {
              sum += (float)0.25328055024;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 292)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 122)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 44)) {
              sum += (float)-0.0054625784978;
            } else {
              sum += (float)-0.25581890345;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 228)) {
              sum += (float)0.081331849098;
            } else {
              sum += (float)-0.281049788;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 52)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 310)) {
              sum += (float)0.44742047787;
            } else {
              sum += (float)-0.14472734928;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 320)) {
              sum += (float)-0.15594080091;
            } else {
              sum += (float)0.3459393084;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 176)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 166)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 142)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 120)) {
              sum += (float)0.19141481817;
            } else {
              sum += (float)0.67799425125;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 36)) {
              sum += (float)0.22519575059;
            } else {
              sum += (float)-0.29454997182;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 70)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 74)) {
              sum += (float)0.19277252257;
            } else {
              sum += (float)0.75330895185;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 62)) {
              sum += (float)0.10758849233;
            } else {
              sum += (float)-0.24608439207;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 242)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 84)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 8)) {
              sum += (float)0.2657559216;
            } else {
              sum += (float)-0.26697030663;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 38)) {
              sum += (float)0.30805969238;
            } else {
              sum += (float)-0.21367247403;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 312)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 24)) {
              sum += (float)-0.11956513673;
            } else {
              sum += (float)0.32741504908;
            }
          } else {
            sum += (float)-0.13238555193;
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
      sum += (float)0.31199017167;
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 16)) {
            sum += (float)0.20313045382;
          } else {
            sum += (float)-0.15317386389;
          }
        } else {
          sum += (float)0.31681868434;
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
          sum += (float)-0.4151366055;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 192)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 184)) {
              sum += (float)0.17254085839;
            } else {
              sum += (float)-0.57149231434;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
              sum += (float)-0.0066630700603;
            } else {
              sum += (float)0.31684178114;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 108)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 72)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 40)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
              sum += (float)0.33400896192;
            } else {
              sum += (float)0.15019251406;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 26)) {
              sum += (float)0.24358457327;
            } else {
              sum += (float)-0.067792743444;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 156)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 90)) {
              sum += (float)0.3057141602;
            } else {
              sum += (float)-0.061509270221;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 174)) {
              sum += (float)0.57417321205;
            } else {
              sum += (float)0.23566937447;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 56)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 58)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
              sum += (float)0.027080746368;
            } else {
              sum += (float)0.33234542608;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 50)) {
              sum += (float)-0.14699368179;
            } else {
              sum += (float)0.14605252445;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 262)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 108)) {
              sum += (float)-0.12993761897;
            } else {
              sum += (float)0.23446406424;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)0.0046880091541;
            } else {
              sum += (float)0.23043274879;
            }
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 30)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 136)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 108)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 62)) {
              sum += (float)-0.084235727787;
            } else {
              sum += (float)0.20272693038;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 122)) {
              sum += (float)0.60428482294;
            } else {
              sum += (float)0.21384584904;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 10)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
              sum += (float)0.092189975083;
            } else {
              sum += (float)0.28243997693;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
              sum += (float)-0.20773290098;
            } else {
              sum += (float)0.12404184788;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 60)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
              sum += (float)0.21939335763;
            } else {
              sum += (float)-0.13440199196;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 52)) {
              sum += (float)0.41139879823;
            } else {
              sum += (float)0.14845943451;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 124)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 72)) {
              sum += (float)-0.096569292247;
            } else {
              sum += (float)-0.23947356641;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 114)) {
              sum += (float)-0.016379166394;
            } else {
              sum += (float)0.30020722747;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
      sum += (float)0.30811649561;
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
        sum += (float)0.30929327011;
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
          sum += (float)-0.39880952239;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 152)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 12)) {
              sum += (float)0.13258317113;
            } else {
              sum += (float)0.30952823162;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 14)) {
              sum += (float)0.2261248529;
            } else {
              sum += (float)-0.13636538386;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 70)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 104)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 82)) {
              sum += (float)0.077339522541;
            } else {
              sum += (float)0.40666949749;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
              sum += (float)0.41466602683;
            } else {
              sum += (float)-0.018874909729;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 30)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 120)) {
              sum += (float)0.0035098914523;
            } else {
              sum += (float)0.27938523889;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 292)) {
              sum += (float)-0.19348101318;
            } else {
              sum += (float)0.16141979396;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 78)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 4)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
              sum += (float)-0.13219310343;
            } else {
              sum += (float)0.50859707594;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
              sum += (float)0.29691201448;
            } else {
              sum += (float)-0.24770905077;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 96)) {
            sum += (float)0.3487868309;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 66)) {
              sum += (float)-0.1019724831;
            } else {
              sum += (float)0.16872826219;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 172)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 86)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 20)) {
              sum += (float)0.089500233531;
            } else {
              sum += (float)0.41268274188;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 70)) {
              sum += (float)-0.23295609653;
            } else {
              sum += (float)0.21964861453;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 168)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 138)) {
              sum += (float)0.21028362215;
            } else {
              sum += (float)0.029441285878;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 94)) {
              sum += (float)0.0124185225;
            } else {
              sum += (float)-0.31485205889;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 252)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 90)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 42)) {
              sum += (float)0.19653265178;
            } else {
              sum += (float)-0.20816397667;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 44)) {
              sum += (float)0.28530797362;
            } else {
              sum += (float)-0.0097925644368;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 102)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 306)) {
              sum += (float)0.31352001429;
            } else {
              sum += (float)-0.064708255231;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 40)) {
              sum += (float)0.17158770561;
            } else {
              sum += (float)-0.23441277444;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
      sum += (float)0.30508267879;
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
        sum += (float)0.29896438122;
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 148)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
            sum += (float)0.21520152688;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 122)) {
              sum += (float)-0.0041485507973;
            } else {
              sum += (float)-0.48070558906;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 102)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
              sum += (float)0.27777838707;
            } else {
              sum += (float)0.11983198673;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 10)) {
              sum += (float)0.16970735788;
            } else {
              sum += (float)-0.31763398647;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 132)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 80)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 92)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 36)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.010663358495;
            } else {
              sum += (float)0.29351043701;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 258)) {
              sum += (float)-0.036050785333;
            } else {
              sum += (float)0.27321988344;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 106)) {
              sum += (float)-0.008864665404;
            } else {
              sum += (float)0.34212353826;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 160)) {
              sum += (float)0.22358764708;
            } else {
              sum += (float)0.48064267635;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 22)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 110)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 60)) {
              sum += (float)0.15458551049;
            } else {
              sum += (float)0.42858114839;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
              sum += (float)0.19972871244;
            } else {
              sum += (float)-0.019044037908;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 296)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 52)) {
              sum += (float)0.076750911772;
            } else {
              sum += (float)-0.12890906632;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.3058848083;
            } else {
              sum += (float)-0.016256464645;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 30)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 48)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
              sum += (float)0.33351635933;
            } else {
              sum += (float)-0.1956743449;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 84)) {
              sum += (float)-0.073619298637;
            } else {
              sum += (float)0.13857977092;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 116)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 64)) {
              sum += (float)-0.10942033678;
            } else {
              sum += (float)-0.25325289369;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 76)) {
              sum += (float)0.32831424475;
            } else {
              sum += (float)-0.025133805349;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 62)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 126)) {
            sum += (float)0.30996900797;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 202)) {
              sum += (float)-0.21854276955;
            } else {
              sum += (float)0.17841972411;
            }
          }
        } else {
          sum += (float)0.36704659462;
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 18)) {
    if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
          sum += (float)0.18664632738;
        } else {
          sum += (float)-0.065511927009;
        }
      } else {
        sum += (float)0.31191307306;
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 2)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
          sum += (float)-0.26936486363;
        } else {
          sum += (float)0.15541271865;
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 148)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 108)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
              sum += (float)0.20462597907;
            } else {
              sum += (float)0.35400897264;
            }
          } else {
            sum += (float)0.024733679369;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
            sum += (float)0.2448785454;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 178)) {
              sum += (float)-0.27359589934;
            } else {
              sum += (float)0.17406448722;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 156)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 104)) {
              sum += (float)0.21733173728;
            } else {
              sum += (float)-0.19809022546;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 278)) {
              sum += (float)-0.058739092201;
            } else {
              sum += (float)0.15408170223;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 130)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
              sum += (float)0.22025246918;
            } else {
              sum += (float)-0.20443916321;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 46)) {
              sum += (float)0.22626537085;
            } else {
              sum += (float)-0.0018624091754;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 78)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 326)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
              sum += (float)0.26660019159;
            } else {
              sum += (float)-0.21792337298;
            }
          } else {
            sum += (float)0.29722559452;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 66)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 20)) {
              sum += (float)0.042906597257;
            } else {
              sum += (float)0.30950891972;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 104)) {
              sum += (float)-0.12920168042;
            } else {
              sum += (float)0.21840567887;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 138)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 120)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 92)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)0.29077345133;
            } else {
              sum += (float)0.14935670793;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 50)) {
              sum += (float)0.24081678689;
            } else {
              sum += (float)-0.12920992076;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 64)) {
            sum += (float)0.22652357817;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 64)) {
              sum += (float)0.36223983765;
            } else {
              sum += (float)0.91650122404;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 236)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 146)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 50)) {
              sum += (float)-0.6766885519;
            } else {
              sum += (float)-0.21512235701;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 46)) {
              sum += (float)0.20854361355;
            } else {
              sum += (float)-0.098114281893;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 68)) {
              sum += (float)0.14868025482;
            } else {
              sum += (float)-0.18834403157;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 96)) {
              sum += (float)0.30166730285;
            } else {
              sum += (float)0.11022634059;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 12)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
      sum += (float)0.30053955317;
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 150)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
          sum += (float)0.06317973882;
        } else {
          sum += (float)0.25892579556;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
          sum += (float)0.18557581306;
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 34)) {
            sum += (float)-0.28653204441;
          } else {
            sum += (float)0.043599348515;
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 84)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 96)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 56)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 8)) {
            sum += (float)0.31274503469;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 16)) {
              sum += (float)0.23369340599;
            } else {
              sum += (float)-0.056501790881;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 42)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 56)) {
              sum += (float)0.36825686693;
            } else {
              sum += (float)0.13599985838;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 86)) {
              sum += (float)0.10068892688;
            } else {
              sum += (float)0.5236851573;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 30)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 60)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 222)) {
              sum += (float)0.34133139253;
            } else {
              sum += (float)-0.027218354866;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 66)) {
              sum += (float)-0.073330543935;
            } else {
              sum += (float)0.091065317392;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 120)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 122)) {
              sum += (float)-0.009912442416;
            } else {
              sum += (float)-0.17700126767;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 38)) {
              sum += (float)-0.13178725541;
            } else {
              sum += (float)0.19630338252;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 114)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 42)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 144)) {
              sum += (float)0.11253731698;
            } else {
              sum += (float)-0.068782441318;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 272)) {
              sum += (float)-0.20186077058;
            } else {
              sum += (float)0.027357865125;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 110)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 74)) {
              sum += (float)0.21408988535;
            } else {
              sum += (float)-0.092498205602;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
              sum += (float)0.27379581332;
            } else {
              sum += (float)-0.036617081612;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 176)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 162)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 130)) {
              sum += (float)0.15078690648;
            } else {
              sum += (float)-0.27882358432;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 66)) {
              sum += (float)0.51420837641;
            } else {
              sum += (float)-0.065433777869;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 244)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 82)) {
              sum += (float)-0.24099731445;
            } else {
              sum += (float)0.21277822554;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
              sum += (float)0.035836331546;
            } else {
              sum += (float)0.29272270203;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].qvalue < 8)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 60)) {
        sum += (float)0.18936605752;
      } else {
        sum += (float)-0.092901393771;
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 12)) {
        sum += (float)0.30436828732;
      } else {
        sum += (float)0.030960468575;
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
        sum += (float)-0.013979041018;
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 10)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 100)) {
            sum += (float)0.30821934342;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
              sum += (float)0.27112621069;
            } else {
              sum += (float)-0.0097008114681;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
            sum += (float)-0.11776360869;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 114)) {
              sum += (float)0.25526431203;
            } else {
              sum += (float)-0.033486548811;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 170)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
              sum += (float)0.33574083447;
            } else {
              sum += (float)-0.069050244987;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 164)) {
              sum += (float)0.075562700629;
            } else {
              sum += (float)0.41353192925;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 196)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 128)) {
              sum += (float)-0.25401833653;
            } else {
              sum += (float)0.077437400818;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 220)) {
              sum += (float)0.134279266;
            } else {
              sum += (float)-0.10661797971;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 26)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 270)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 64)) {
              sum += (float)-0.22375197709;
            } else {
              sum += (float)-0.0089620733634;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
              sum += (float)0.27541381121;
            } else {
              sum += (float)-0.035413116217;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 76)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 154)) {
              sum += (float)0.29828065634;
            } else {
              sum += (float)0.028085550293;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 240)) {
              sum += (float)-0.17037308216;
            } else {
              sum += (float)0.22744709253;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
    sum += (float)0.29637292027;
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 158)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
        sum += (float)0.3298664093;
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 268)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 226)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
              sum += (float)0.19230087101;
            } else {
              sum += (float)-0.0066139730625;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
              sum += (float)-0.2671597898;
            } else {
              sum += (float)0.17411914468;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 54)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 302)) {
              sum += (float)0.3564735055;
            } else {
              sum += (float)-0.043377488852;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 320)) {
              sum += (float)-0.044880922884;
            } else {
              sum += (float)0.31298685074;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 30)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 32)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
              sum += (float)-0.195489645;
            } else {
              sum += (float)0.12938171625;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)0.31835407019;
            } else {
              sum += (float)-0.24589452147;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 288)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 24)) {
              sum += (float)0.041429869831;
            } else {
              sum += (float)-0.23850911856;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 40)) {
              sum += (float)0.32140746713;
            } else {
              sum += (float)-0.14184650779;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 172)) {
          sum += (float)-0.010567699559;
        } else {
          sum += (float)0.27495896816;
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 60)) {
        sum += (float)0.12893892825;
      } else {
        sum += (float)-0.067619867623;
      }
    } else {
      sum += (float)0.30665302277;
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 26)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 10)) {
        sum += (float)0.31686788797;
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 118)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 54)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 48)) {
              sum += (float)0.042110458016;
            } else {
              sum += (float)0.2966851294;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 294)) {
              sum += (float)-0.030055005103;
            } else {
              sum += (float)0.14088901877;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 324)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
              sum += (float)0.20408032835;
            } else {
              sum += (float)-0.1048341319;
            }
          } else {
            sum += (float)0.29124155641;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 118)) {
        sum += (float)0.29354774952;
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 190)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 182)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 98)) {
              sum += (float)0.10529232025;
            } else {
              sum += (float)-0.29795300961;
            }
          } else {
            sum += (float)-0.41205593944;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 242)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 210)) {
              sum += (float)0.27774211764;
            } else {
              sum += (float)-0.23508886993;
            }
          } else {
            sum += (float)0.30393701792;
          }
        }
      }
    }
  }
  if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 54)) {
        sum += (float)0.1233605817;
      } else {
        sum += (float)-0.065339013934;
      }
    } else {
      sum += (float)0.3024764359;
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 50)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 126)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 124)) {
              sum += (float)0.072739072144;
            } else {
              sum += (float)-0.25075954199;
            }
          } else {
            sum += (float)0.31037768722;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 110)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
              sum += (float)-0.26863235235;
            } else {
              sum += (float)-0.070632301271;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
              sum += (float)0.2773733139;
            } else {
              sum += (float)-0.0070568895899;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 118)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 66)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 54)) {
              sum += (float)-0.046447329223;
            } else {
              sum += (float)-0.19073213637;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 214)) {
              sum += (float)0.31253322959;
            } else {
              sum += (float)-0.18651382625;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 52)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 118)) {
              sum += (float)0.47982820868;
            } else {
              sum += (float)0.060683276504;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 58)) {
              sum += (float)-0.078181602061;
            } else {
              sum += (float)0.19960218668;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 74)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 26)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
              sum += (float)0.17142336071;
            } else {
              sum += (float)-0.26533198357;
            }
          } else {
            sum += (float)0.23929437995;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 62)) {
              sum += (float)0.26246771216;
            } else {
              sum += (float)0.55372202396;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 78)) {
              sum += (float)-0.10462453216;
            } else {
              sum += (float)0.20785677433;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].qvalue < 4)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 96)) {
            sum += (float)0.32080149651;
          } else {
            sum += (float)0.098180316389;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 198)) {
              sum += (float)0.056545898318;
            } else {
              sum += (float)0.30845525861;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 92)) {
              sum += (float)-0.022016573697;
            } else {
              sum += (float)0.21116688848;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
    sum += (float)0.28820696473;
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 164)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 70)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 60)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
            sum += (float)0.29475095868;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
              sum += (float)-0.31449195743;
            } else {
              sum += (float)0.065751753747;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
            sum += (float)-0.098439469934;
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 90)) {
              sum += (float)0.16580834985;
            } else {
              sum += (float)0.67890626192;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 112)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 94)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 50)) {
              sum += (float)0.35196104646;
            } else {
              sum += (float)-0.096174821258;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
              sum += (float)-0.30209422112;
            } else {
              sum += (float)0.16073736548;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 62)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 150)) {
              sum += (float)-0.14388532937;
            } else {
              sum += (float)0.15463718772;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
              sum += (float)-0.048294324428;
            } else {
              sum += (float)0.064041621983;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].qvalue < 182)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 88)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 30)) {
              sum += (float)-0.11342134327;
            } else {
              sum += (float)0.26739764214;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 300)) {
              sum += (float)-0.17027489841;
            } else {
              sum += (float)0.11367891729;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 174)) {
            sum += (float)0.0010216155788;
          } else {
            sum += (float)0.27820432186;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 40)) {
            sum += (float)0.21550902724;
          } else {
            sum += (float)-0.19854110479;
          }
        } else {
          sum += (float)0.46049645543;
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].qvalue < 8)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
        sum += (float)0.16126269102;
      } else {
        sum += (float)-0.061077732593;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 2)) {
        sum += (float)0.29167321324;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 26)) {
          sum += (float)-0.042005714029;
        } else {
          sum += (float)0.24985025823;
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].qvalue < 112)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 318)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 220)) {
              sum += (float)0.014041483402;
            } else {
              sum += (float)-0.10597609729;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 32)) {
              sum += (float)0.058068040758;
            } else {
              sum += (float)-0.16517931223;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 136)) {
              sum += (float)0.22282625735;
            } else {
              sum += (float)0.040847536176;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 68)) {
              sum += (float)-0.2082542628;
            } else {
              sum += (float)0.12037189305;
            }
          }
        }
      } else {
        sum += (float)0.30335617065;
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 84)) {
        sum += (float)0.30733212829;
      } else {
        sum += (float)0.060871530324;
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
    sum += (float)0.27980899811;
  } else {
    if (!(data[3].missing != -1) || (data[3].qvalue < 280)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 224)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 204)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 178)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
              sum += (float)-0.043157055974;
            } else {
              sum += (float)0.063283003867;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 188)) {
              sum += (float)-0.34614306688;
            } else {
              sum += (float)-0.060513403267;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 206)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 44)) {
              sum += (float)0.68587464094;
            } else {
              sum += (float)0.14131705463;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
              sum += (float)-0.05791676417;
            } else {
              sum += (float)0.27874276042;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 238)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 116)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 106)) {
              sum += (float)-0.31173858047;
            } else {
              sum += (float)-0.067292489111;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 232)) {
              sum += (float)0.11564923078;
            } else {
              sum += (float)-0.21622921526;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 276)) {
              sum += (float)-0.039862044156;
            } else {
              sum += (float)-0.31686505675;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 140)) {
              sum += (float)0.28878682852;
            } else {
              sum += (float)0.082666821778;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].qvalue < 74)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 304)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 106)) {
            sum += (float)0.4011271596;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 120)) {
              sum += (float)0.25941103697;
            } else {
              sum += (float)-0.056654702872;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
            sum += (float)-0.19497087598;
          } else {
            sum += (float)0.063079863787;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 320)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 78)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 130)) {
              sum += (float)0.22904494405;
            } else {
              sum += (float)-0.27036124468;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 56)) {
              sum += (float)0.10077212006;
            } else {
              sum += (float)-0.2439340651;
            }
          }
        } else {
          sum += (float)0.27675011754;
        }
      }
    }
  }

  sum = sum + (float)(-0);
  if (!pred_margin) {
    return pred_transform(sum);
  } else {
    return sum;
  }
}
