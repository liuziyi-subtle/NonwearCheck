static const int th_len[] = {
  66, 10, 49, 71, 98, 82, 47, 42, 63, 12, 
};
static const int th_begin[] = {
  0, 66, 76, 125, 196, 294, 376, 423, 465, 528, 
};
static const float threshold[] = {
  -0.14174989, -0.088678226, -0.085427016, -0.075014152, -0.06778349, 
  -0.060579188, -0.059447579, -0.040771943, 0.0015516158, 0.022452153, 
  0.048475109, 0.048735268, 0.063272186, 0.080906607, 0.12282525, 0.12493911, 
  0.13222396, 0.13289297, 0.14658155, 0.16841048, 0.16983783, 0.19647273, 
  0.20626944, 0.2105035, 0.21317694, 0.21436128, 0.22466072, 0.22543952, 
  0.25054601, 0.25101158, 0.25158334, 0.25674146, 0.28910139, 0.3006846, 
  0.31411031, 0.34569424, 0.38594651, 0.38993728, 0.39606571, 0.43795773, 
  0.45282084, 0.45940316, 0.46676588, 0.46909082, 0.47655487, 0.50111824, 
  0.53201044, 0.54298019, 0.56788629, 0.57542914, 0.58058977, 0.68846089, 
  0.72636867, 0.72763062, 0.73097181, 0.73291755, 0.73635542, 0.73775542, 
  0.74556524, 0.75506324, 0.76049113, 0.77077115, 0.79649687, 0.82714176, 
  0.91053402, 0.97695053, 7.5, 8.5, 9.5, 10.5, 11.5, 12.5, 13.5, 14.5, 15.5, 
  16.5, 0.120736, 0.32788315, 0.33934054, 0.34825197, 0.37692171, 0.38651231, 
  0.40312293, 0.45103574, 0.46394193, 0.47230276, 0.48593992, 0.49553263, 
  0.54027486, 0.54103446, 0.55463219, 0.55465263, 0.56477731, 0.57800889, 
  0.58732283, 0.60692072, 0.62827599, 0.64564407, 0.70525801, 0.75838721, 
  0.76783973, 0.78393501, 0.79495585, 0.79871321, 0.80386794, 0.8224721, 
  0.82873094, 0.84578961, 0.8553468, 0.85547698, 0.86538136, 0.8716042, 
  0.88466823, 0.88524795, 0.89397728, 0.894023, 0.89681035, 0.89992732, 
  0.90072572, 0.90181357, 0.91142243, 0.91201174, 0.92000741, 0.93209857, 
  0.95372415, 0.0022121863, 0.0043632039, 0.0059650643, 0.0061010467, 
  0.0061357515, 0.0093567576, 0.012281943, 0.012344128, 0.013187131, 
  0.013225337, 0.01572305, 0.015847061, 0.015962396, 0.01979975, 0.023965795, 
  0.028355421, 0.028715309, 0.033233713, 0.040442429, 0.043879114, 0.044308715, 
  0.056515113, 0.0567973, 0.05842495, 0.059305862, 0.066483147, 0.069862202, 
  0.070161328, 0.074569434, 0.075829089, 0.19106546, 0.21026501, 0.36059043, 
  0.38853377, 0.52562451, 0.56243312, 0.64890385, 0.65075636, 0.7613126, 
  0.81730413, 0.94463348, 0.94469106, 1.2123013, 1.2251062, 1.4921238, 
  1.6753838, 1.8109593, 2.1626782, 2.6778359, 2.7546959, 3.0591111, 3.1644459, 
  3.2075822, 5.0511599, 5.5450001, 5.6007514, 5.6014967, 5.7865696, 5.966526, 
  13.538322, 14.016577, 16.253834, 17.332359, 22.949697, 24.186998, 35.719997, 
  36.868404, 49.970291, 50.638882, 4066.3904, 4270.9746, 0.026663398, 
  0.037803415, 0.070177622, 0.07170774, 0.07861761, 0.083248243, 0.083566502, 
  0.084774628, 0.085037827, 0.09266638, 0.097156733, 0.10589713, 0.10622865, 
  0.11446118, 0.11514995, 0.12417233, 0.13194838, 0.13275494, 0.13508973, 
  0.14241125, 0.14531624, 0.16020797, 0.16237861, 0.16853078, 0.16982259, 
  0.18972424, 0.19019789, 0.19782013, 0.20557258, 0.23595855, 0.24790001, 
  0.25032747, 0.25139445, 0.25879654, 0.26489812, 0.26821679, 0.2759791, 
  0.27607635, 0.28990108, 0.33016494, 0.33622974, 0.34786338, 0.35961929, 
  0.37211657, 0.38645017, 0.39008859, 0.43140694, 0.45163649, 0.46774703, 
  0.4721505, 0.48298305, 0.48324284, 0.48662332, 0.51779509, 0.52607429, 
  0.53721493, 0.57114083, 0.60725516, 0.72377515, 0.72651613, 0.74107373, 
  0.75634444, 0.76351738, 0.76866746, 0.81029308, 0.83590043, 0.86163473, 
  0.87958515, 0.93999386, 1.1260433, 1.1409662, 1.2504381, 1.2600017, 
  1.2626792, 1.2812999, 1.2827947, 1.3076196, 1.3302059, 1.3421389, 1.3579278, 
  1.4158546, 1.4176385, 1.4178395, 1.5331522, 1.7092524, 1.8358328, 1.8890153, 
  2.1892371, 2.7448139, 3.1094279, 3.1383734, 3.5449467, 3.5545275, 11.474058, 
  13.517672, 41.656834, 46.690681, 60.771816, 0.86371922, 1.0556297, 1.1061306, 
  1.120404, 1.1264415, 1.1598978, 1.265352, 1.2902832, 1.3045094, 1.3349204, 
  1.3400115, 1.3844155, 1.3941818, 1.4034047, 1.4130166, 1.4171658, 1.4172429, 
  1.4245996, 1.4528465, 1.4820738, 1.487507, 1.4933589, 1.5563178, 1.6331801, 
  1.6962557, 1.696558, 1.7522715, 1.7673705, 1.8098351, 1.8301618, 1.843394, 
  1.8606743, 1.8686454, 1.8806171, 1.9119051, 1.9158142, 1.9160714, 1.9246095, 
  1.9436634, 1.9444773, 1.9720231, 1.9780003, 1.9806342, 1.9815381, 1.9909601, 
  1.9950123, 2.001159, 2.0018632, 2.0153203, 2.0288224, 2.0307178, 2.0315125, 
  2.0335491, 2.0338945, 2.0346422, 2.0384622, 2.063776, 2.0732372, 2.0746202, 
  2.075002, 2.076272, 2.0818553, 2.0827932, 2.085186, 2.1050291, 2.1064401, 
  2.1105199, 2.1108584, 2.1147838, 2.1148682, 2.1201041, 2.128952, 2.1613159, 
  2.1810358, 2.1832037, 2.1853397, 2.2049577, 2.2106659, 2.2134788, 2.2323909, 
  2.2559466, 2.2568147, 0.26804763, 0.33412871, 0.38521969, 0.41284615, 
  0.45695859, 0.47190118, 0.52698576, 0.55192733, 0.61579561, 0.64686036, 
  0.69308221, 0.8158406, 1.1209502, 1.1261277, 1.1728089, 1.1750846, 1.2284808, 
  1.4158609, 1.4192151, 1.9417984, 2.0450544, 2.1573381, 3.0645523, 3.4254961, 
  3.4511499, 3.7439284, 4.7266817, 4.8021421, 4.8043633, 5.0188627, 5.756217, 
  5.9860525, 5.9878139, 6.2235899, 6.3620872, 7.4727874, 7.4961443, 7.5542498, 
  7.696804, 8.0575504, 8.3370514, 8.5507298, 9.1113968, 9.4432278, 13.276316, 
  15.356647, 88.69278, 0.29693371, 0.35722861, 0.36552274, 0.36758333, 
  0.44539285, 0.45163769, 0.45443451, 0.46608695, 0.48886418, 0.51194441, 
  0.52035356, 0.54717648, 0.57467496, 0.64337873, 0.65649366, 0.8036077, 
  0.8036381, 0.80852067, 0.82409525, 0.84231573, 0.94608331, 1.219553, 
  1.2345092, 1.4431, 1.8801391, 2.1922498, 2.2222273, 2.8018374, 2.8788478, 
  4.571619, 4.6264262, 4.8396988, 5.6189165, 6.6988192, 11.672928, 12.038966, 
  14.149128, 15.039479, 15.900272, 19.495007, 20.655367, 52.670895, 0.65041435, 
  0.78767365, 0.9217723, 0.92476028, 0.93174958, 1.0017135, 1.1792388, 
  1.2511361, 1.9849448, 3.2152081, 3.4851813, 3.5421267, 3.646503, 3.7057958, 
  4.4487753, 4.5908661, 4.6881418, 4.7031155, 5.3024678, 5.9630508, 6.0096064, 
  6.3809772, 6.7091846, 6.9358339, 7.4148731, 7.5474157, 9.4440918, 10.115011, 
  14.723837, 15.615349, 15.671938, 16.288776, 16.71611, 16.911165, 19.519184, 
  29.257, 29.744186, 30.582615, 37.709293, 43.918606, 45.613266, 45.652454, 
  69.922928, 72.688705, 72.699127, 78.080109, 135.92784, 138.3801, 138.43356, 
  141.26463, 141.59607, 157.59196, 160.12123, 168.29582, 229.14133, 254.09543, 
  272.60883, 356.95261, 508.21692, 616.28369, 684.11633, 845.7326, 888.53613, 
  0.01171875, 0.02734375, 0.04296875, 0.05859375, 0.06640625, 0.09765625, 
  0.10546875, 0.11328125, 0.12890625, 0.14453125, 0.16796875, 0.19140625, 
};

#include <stdlib.h>

/*
 * \brief function to convert a feature value into bin index.
 * \param val feature value, in floating-point
 * \param fid feature identifier
 * \return bin index corresponding to given feature value
 */
static inline int quantize(float val, unsigned fid) {
  const size_t offset = th_begin[fid];
  const float* array = &threshold[offset];
  int len = th_len[fid];
  int low = 0;
  int high = len;
  int mid;
  float mval;
  // It is possible th_begin[i] == [total_num_threshold]. This means that
  // all features i, (i+1), ... are not used for any of the splits in the model.
  // So in this case, just return something
  if (offset == 540 || val < array[0]) {
    return -10;
  }
  while (low + 1 < high) {
    mid = (low + high) / 2;
    mval = array[mid];
    if (val == mval) {
      return mid * 2;
    } else if (val < mval) {
      high = mid;
    } else {
      low = mid;
    }
  }
  if (array[low] == val) {
    return low * 2;
  } else if (high == len) {
    return len * 2;
  } else {
    return low * 2 + 1;
  }
}

#include "header.h"

const unsigned char is_categorical[] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
};

size_t get_num_output_group(void) {
  return 1;
}

size_t get_num_feature(void) {
  return 10;
}

const char* get_pred_transform(void) {
  return "sigmoid";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_global_bias(void) {
  return -0.0;
}

static inline float pred_transform(float margin) {
  const float alpha = (float)1.0;
  return 1.0f / (1 + expf(-alpha * margin));
}
float predict(union Entry* data, int pred_margin) {

  for (int i = 0; i < 10; ++i) {
    if (data[i].missing != -1 && !is_categorical[i]) {
      data[i].qvalue = quantize(data[i].fvalue, i);
    }
  }
  float sum = 0.0f;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if (!(data[4].missing != -1) || (data[4].qvalue < 40)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 20)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
          sum += (float)0.46666669846;
        } else {
          sum += (float)-0.12000000477;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 88)) {
          sum += (float)0.12000000477;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 10)) {
            sum += (float)-0.15000000596;
          } else {
            sum += (float)-0.53684210777;
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 76)) {
          sum += (float)0.59714287519;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 24)) {
            sum += (float)0.5345454812;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 8)) {
              sum += (float)-0.32307696342;
            } else {
              sum += (float)0.15000000596;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 10)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 112)) {
            sum += (float)0.27272728086;
          } else {
            sum += (float)-0.375;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            sum += (float)-0;
          } else {
            sum += (float)0.53684210777;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 34)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 76)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 30)) {
              sum += (float)0.38181820512;
            } else {
              sum += (float)0.066666670144;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 194)) {
              sum += (float)-0.47878786922;
            } else {
              sum += (float)0.15000000596;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 174)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 26)) {
              sum += (float)0.47796612978;
            } else {
              sum += (float)-0.054545458406;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
              sum += (float)-0.26153847575;
            } else {
              sum += (float)0.27692309022;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 16)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 78)) {
              sum += (float)0.1894736886;
            } else {
              sum += (float)-0.51111114025;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 82)) {
              sum += (float)-0.58025765419;
            } else {
              sum += (float)-0.48107036948;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 24)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 46)) {
              sum += (float)-0.40540543199;
            } else {
              sum += (float)0.085714295506;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 118)) {
              sum += (float)-0.49206349254;
            } else {
              sum += (float)0.375;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 18)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 120)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 20)) {
            sum += (float)0.12000000477;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 110)) {
              sum += (float)0.58293843269;
            } else {
              sum += (float)0.39375001192;
            }
          }
        } else {
          sum += (float)0.066666670144;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 152)) {
            sum += (float)0.48433735967;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 10)) {
              sum += (float)0.52000004053;
            } else {
              sum += (float)-0.18857143819;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 66)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 50)) {
              sum += (float)-0.10909091681;
            } else {
              sum += (float)0.39428573847;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 62)) {
              sum += (float)-0.45985403657;
            } else {
              sum += (float)-0.066666670144;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 44)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
          sum += (float)0.44058540463;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 34)) {
            sum += (float)-0.088647171855;
          } else {
            sum += (float)0.32814589143;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 76)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
            sum += (float)0.14014182985;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 4)) {
              sum += (float)-0.059769637883;
            } else {
              sum += (float)-0.48411503434;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 120)) {
            sum += (float)0.41126194596;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 26)) {
              sum += (float)0.15578445792;
            } else {
              sum += (float)-0.23856620491;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 32)) {
        sum += (float)0.46253412962;
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 66)) {
            sum += (float)0.35382929444;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 126)) {
              sum += (float)-0.034174036235;
            } else {
              sum += (float)-0.34582936764;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 68)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 10)) {
              sum += (float)0.10931871831;
            } else {
              sum += (float)0.47549661994;
            }
          } else {
            sum += (float)-0.018073216081;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 30)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 140)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 32)) {
              sum += (float)-0.2798062861;
            } else {
              sum += (float)0.22870030999;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 20)) {
              sum += (float)0.43471631408;
            } else {
              sum += (float)0.16914057732;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 192)) {
              sum += (float)-0.37673407793;
            } else {
              sum += (float)0.071468606591;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 12)) {
              sum += (float)0.20343287289;
            } else {
              sum += (float)-0.23443906009;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 0)) {
            sum += (float)0.24298213422;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 80)) {
              sum += (float)-0.45052328706;
            } else {
              sum += (float)-0.35656815767;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 84)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 72)) {
              sum += (float)-0.17472711205;
            } else {
              sum += (float)-0.41785821319;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 172)) {
              sum += (float)0.38934737444;
            } else {
              sum += (float)-0.20906554163;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 36)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 6)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 4)) {
            sum += (float)-0.0010713258525;
          } else {
            sum += (float)0.45203241706;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 84)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 60)) {
              sum += (float)0.063133314252;
            } else {
              sum += (float)0.43062141538;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 70)) {
              sum += (float)-0.24162493646;
            } else {
              sum += (float)0.23643003404;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 62)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 44)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 42)) {
              sum += (float)0.1236929372;
            } else {
              sum += (float)0.4520740211;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 126)) {
              sum += (float)0.37832885981;
            } else {
              sum += (float)-0.084486410022;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 136)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 48)) {
              sum += (float)-0.24740639329;
            } else {
              sum += (float)0.40753793716;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 18)) {
              sum += (float)0.012389661744;
            } else {
              sum += (float)-0.45430520177;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 46)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 8)) {
          sum += (float)0.38245427608;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 128)) {
            sum += (float)0.28055244684;
          } else {
            sum += (float)-0.10487156361;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 76)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 58)) {
            sum += (float)0.26864099503;
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 4)) {
              sum += (float)0.036700408906;
            } else {
              sum += (float)-0.41176584363;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 120)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 6)) {
              sum += (float)0.052939757705;
            } else {
              sum += (float)0.35888400674;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 26)) {
              sum += (float)0.12780544162;
            } else {
              sum += (float)-0.21281807125;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 32)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 80)) {
          sum += (float)0.40212827921;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
            sum += (float)0.37033507228;
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 146)) {
              sum += (float)0.2381696254;
            } else {
              sum += (float)-0.41223022342;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 124)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 102)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 0)) {
              sum += (float)0.12053584307;
            } else {
              sum += (float)0.43546709418;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 22)) {
              sum += (float)0.26700979471;
            } else {
              sum += (float)-0.04391245544;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 156)) {
              sum += (float)-0.35021093488;
            } else {
              sum += (float)-0.10164618492;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 60)) {
              sum += (float)0.30002251267;
            } else {
              sum += (float)-0.21662515402;
            }
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 48)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 120)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 46)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 104)) {
              sum += (float)0.29147732258;
            } else {
              sum += (float)-0.1993561089;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 18)) {
              sum += (float)0.53587198257;
            } else {
              sum += (float)0.097016133368;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 12)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 34)) {
              sum += (float)-0.097872540355;
            } else {
              sum += (float)0.38330373168;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 2)) {
              sum += (float)0.31349426508;
            } else {
              sum += (float)-0.30562141538;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 106)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 8)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 88)) {
              sum += (float)-0.012403843924;
            } else {
              sum += (float)-0.37894648314;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
              sum += (float)-0.29975482821;
            } else {
              sum += (float)-0.38809242845;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 120)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 118)) {
              sum += (float)0.57594311237;
            } else {
              sum += (float)-0.29825079441;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
              sum += (float)-0.35671964288;
            } else {
              sum += (float)-0.038469638675;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 16)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 26)) {
          sum += (float)-0.17556880414;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 112)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 106)) {
              sum += (float)0.40681675076;
            } else {
              sum += (float)0.1161601916;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 110)) {
              sum += (float)-0.15565036237;
            } else {
              sum += (float)0.37344303727;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 42)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 42)) {
              sum += (float)0.37506374717;
            } else {
              sum += (float)0.06566465646;
            }
          } else {
            sum += (float)0.41379123926;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 132)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 108)) {
              sum += (float)0.099364437163;
            } else {
              sum += (float)-0.20726130903;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 18)) {
              sum += (float)-0.34537142515;
            } else {
              sum += (float)0.050316527486;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 42)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 18)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 150)) {
          sum += (float)0.34886604548;
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 0)) {
            sum += (float)0.24181954563;
          } else {
            sum += (float)-0.11885095388;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 76)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 6)) {
            sum += (float)0.094678856432;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 4)) {
              sum += (float)-0.031482189894;
            } else {
              sum += (float)-0.3642052412;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 110)) {
            sum += (float)0.29762968421;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 46)) {
              sum += (float)-0.1409226656;
            } else {
              sum += (float)0.20169119537;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 74)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 36)) {
          sum += (float)0.36730375886;
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 126)) {
              sum += (float)0.20495784283;
            } else {
              sum += (float)-0.258746773;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 144)) {
              sum += (float)0.3644964695;
            } else {
              sum += (float)0.0083397766575;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 14)) {
          sum += (float)0.33695417643;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 140)) {
            sum += (float)0.23200033605;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 8)) {
              sum += (float)-0.27970099449;
            } else {
              sum += (float)-0.072449319065;
            }
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
      if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 0)) {
          sum += (float)0.27431079745;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 74)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 54)) {
              sum += (float)-0.20380027592;
            } else {
              sum += (float)-0.35482737422;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 90)) {
              sum += (float)0.58202129602;
            } else {
              sum += (float)-0.30219581723;
            }
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 102)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 22)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 108)) {
              sum += (float)0.42115014791;
            } else {
              sum += (float)-0.28749957681;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 14)) {
              sum += (float)-0.010119223967;
            } else {
              sum += (float)-0.30207356811;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 184)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 124)) {
              sum += (float)0.38249877095;
            } else {
              sum += (float)-0.27368086576;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 92)) {
              sum += (float)-0.16384424269;
            } else {
              sum += (float)0.37967839837;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 10)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 36)) {
          sum += (float)-0.082453891635;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 94)) {
            sum += (float)0.38016992807;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 74)) {
              sum += (float)-0.3069010973;
            } else {
              sum += (float)0.29540133476;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 74)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 134)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 32)) {
              sum += (float)0.42325422168;
            } else {
              sum += (float)0.2041195482;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 4)) {
              sum += (float)0.30084380507;
            } else {
              sum += (float)-0.15978893638;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 54)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 58)) {
              sum += (float)-0.034640073776;
            } else {
              sum += (float)-0.34218725562;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 118)) {
              sum += (float)0.32337933779;
            } else {
              sum += (float)-0.17821405828;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 2)) {
        sum += (float)0.26190793514;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 88)) {
          sum += (float)-0.30258524418;
        } else {
          sum += (float)0.18055477738;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 86)) {
          sum += (float)0.34657239914;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 12)) {
            sum += (float)0.29468470812;
          } else {
            sum += (float)-0.12669056654;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 94)) {
            sum += (float)0.26628834009;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
              sum += (float)-0.45725688338;
            } else {
              sum += (float)0.025040071458;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 72)) {
            sum += (float)0.33324658871;
          } else {
            sum += (float)0.014020401053;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 78)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 18)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 78)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 12)) {
              sum += (float)0.41542956233;
            } else {
              sum += (float)0.014567933977;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
              sum += (float)0.12149448693;
            } else {
              sum += (float)-0.32123222947;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 62)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 72)) {
              sum += (float)0.46522814035;
            } else {
              sum += (float)-0.24988786876;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
              sum += (float)-0.18345794082;
            } else {
              sum += (float)-0.32568415999;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 166)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 62)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 48)) {
              sum += (float)-0.059665083885;
            } else {
              sum += (float)-0.26275345683;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 116)) {
              sum += (float)0.64743161201;
            } else {
              sum += (float)0.0096530020237;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 104)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 70)) {
              sum += (float)-0.28480100632;
            } else {
              sum += (float)0.0042309914716;
            }
          } else {
            sum += (float)-0.35864308476;
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 38)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 160)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 0)) {
            sum += (float)0.13067351282;
          } else {
            sum += (float)0.35799521208;
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 94)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 44)) {
              sum += (float)0.12615022063;
            } else {
              sum += (float)-0.32561263442;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 140)) {
              sum += (float)0.31408038735;
            } else {
              sum += (float)0.03716475144;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 38)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 24)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 48)) {
              sum += (float)0.12370746583;
            } else {
              sum += (float)-0.25522595644;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 106)) {
              sum += (float)0.29527661204;
            } else {
              sum += (float)-0.035499505699;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 40)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 26)) {
              sum += (float)-0.17979605496;
            } else {
              sum += (float)0.37842744589;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 42)) {
              sum += (float)-0.28044998646;
            } else {
              sum += (float)-0.097828693688;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 2)) {
        sum += (float)0.23560474813;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 88)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 122)) {
            sum += (float)-0.074671044946;
          } else {
            sum += (float)-0.29513901472;
          }
        } else {
          sum += (float)0.15604175627;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 86)) {
          sum += (float)0.33191663027;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 12)) {
            sum += (float)0.27111017704;
          } else {
            sum += (float)-0.10652128607;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 94)) {
            sum += (float)0.24208267033;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
              sum += (float)-0.39303529263;
            } else {
              sum += (float)0.018872955814;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 72)) {
            sum += (float)0.31546440721;
          } else {
            sum += (float)0.0117943082;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 62)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 34)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 114)) {
              sum += (float)0.36647903919;
            } else {
              sum += (float)-0.024363471195;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 128)) {
              sum += (float)-0.027854971588;
            } else {
              sum += (float)-0.27067893744;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 60)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 82)) {
              sum += (float)-0.24852369726;
            } else {
              sum += (float)0.14426846802;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 4)) {
              sum += (float)-0.11987110227;
            } else {
              sum += (float)-0.32171142101;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 162)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 58)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 86)) {
              sum += (float)0.10571823269;
            } else {
              sum += (float)-0.27156853676;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 114)) {
              sum += (float)0.70789039135;
            } else {
              sum += (float)-0.13584516943;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 104)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 70)) {
              sum += (float)-0.25671517849;
            } else {
              sum += (float)0.0012644883245;
            }
          } else {
            sum += (float)-0.33832749724;
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 78)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 82)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 38)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 114)) {
              sum += (float)0.11957176775;
            } else {
              sum += (float)-0.21160031855;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 8)) {
              sum += (float)-0.0096437167376;
            } else {
              sum += (float)0.39320600033;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 46)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 158)) {
              sum += (float)0.25915580988;
            } else {
              sum += (float)-0.15830610693;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)-0.28568565845;
            } else {
              sum += (float)-0.11682796478;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 100)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 182)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 90)) {
              sum += (float)0.15864895284;
            } else {
              sum += (float)0.37383657694;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 122)) {
              sum += (float)-0.36905309558;
            } else {
              sum += (float)0.1949981302;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 16)) {
            sum += (float)0.25307866931;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 148)) {
              sum += (float)0.093839906156;
            } else {
              sum += (float)-0.35238927603;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 38)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
      if (!(data[3].missing != -1) || (data[3].qvalue < 2)) {
        sum += (float)0.22763887048;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 84)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 14)) {
            sum += (float)-0.070211537182;
          } else {
            sum += (float)-0.27018249035;
          }
        } else {
          sum += (float)0.13452075422;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 24)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 160)) {
          sum += (float)0.32097709179;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 0)) {
            sum += (float)0.17413720489;
          } else {
            sum += (float)-0.032052852213;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 66)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 96)) {
              sum += (float)0.089182987809;
            } else {
              sum += (float)-0.25963884592;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 28)) {
              sum += (float)-0.060896571726;
            } else {
              sum += (float)0.23546436429;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 72)) {
            sum += (float)0.30098953843;
          } else {
            sum += (float)0.009921467863;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 92)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 30)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 54)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 28)) {
              sum += (float)-0.29193094373;
            } else {
              sum += (float)0.14698143303;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 24)) {
              sum += (float)0.58608561754;
            } else {
              sum += (float)0.07487706095;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 144)) {
              sum += (float)-0.18857760727;
            } else {
              sum += (float)-0.30587723851;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 90)) {
              sum += (float)-0.15319177508;
            } else {
              sum += (float)0.40483176708;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 28)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 96)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 46)) {
              sum += (float)-0.30981969833;
            } else {
              sum += (float)0.58584755659;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 68)) {
              sum += (float)-0.028234260157;
            } else {
              sum += (float)-0.31513422728;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
            sum += (float)0.086361564696;
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 76)) {
              sum += (float)-0.3109177947;
            } else {
              sum += (float)-0.24525991082;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 54)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 56)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 96)) {
              sum += (float)0.34212702513;
            } else {
              sum += (float)-0.11217911541;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 64)) {
              sum += (float)-0.03766541183;
            } else {
              sum += (float)-0.25986903906;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 108)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 138)) {
              sum += (float)0.34076631069;
            } else {
              sum += (float)0.031742684543;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 134)) {
              sum += (float)-0.3331155777;
            } else {
              sum += (float)-0.0061117992736;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 116)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 40)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 36)) {
              sum += (float)0.19939136505;
            } else {
              sum += (float)-0.18627893925;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 2)) {
              sum += (float)0.0070044179447;
            } else {
              sum += (float)0.32179531455;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 40)) {
            sum += (float)0.30636504292;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 78)) {
              sum += (float)-0.0027753533795;
            } else {
              sum += (float)-0.36174729466;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 34)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 10)) {
        sum += (float)0.1600381434;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 74)) {
          sum += (float)-0.2297745049;
        } else {
          sum += (float)0.037427607924;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
        sum += (float)0.31520920992;
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 94)) {
            sum += (float)0.24823918939;
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 26)) {
              sum += (float)-0.24838656187;
            } else {
              sum += (float)0.1039249897;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 148)) {
            sum += (float)0.30005276203;
          } else {
            sum += (float)0.038822844625;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 92)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 30)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 30)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 62)) {
              sum += (float)0.23076029122;
            } else {
              sum += (float)-0.26551678777;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 38)) {
              sum += (float)0.30325198174;
            } else {
              sum += (float)-0.084626533091;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 72)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 86)) {
              sum += (float)0.015860589221;
            } else {
              sum += (float)-0.26390215755;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 84)) {
              sum += (float)-0.1289459914;
            } else {
              sum += (float)0.22030007839;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 28)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 86)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 56)) {
              sum += (float)-0.29106411338;
            } else {
              sum += (float)0.43289133906;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 138)) {
              sum += (float)-0.098739676178;
            } else {
              sum += (float)-0.31372132897;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 76)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 92)) {
              sum += (float)-0.2654505372;
            } else {
              sum += (float)0.32708349824;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 76)) {
              sum += (float)-0.30840605497;
            } else {
              sum += (float)-0.21556282043;
            }
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 88)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 74)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 24)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 68)) {
              sum += (float)0.32582783699;
            } else {
              sum += (float)-0.11694207042;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 56)) {
              sum += (float)0.38448736072;
            } else {
              sum += (float)-0.052364423871;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 36)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 54)) {
              sum += (float)0.034932274371;
            } else {
              sum += (float)0.32254528999;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 52)) {
              sum += (float)-0.2431217581;
            } else {
              sum += (float)-0.091225974262;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 170)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 114)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 20)) {
              sum += (float)0.30071011186;
            } else {
              sum += (float)0.63258808851;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 92)) {
              sum += (float)-0.095527909696;
            } else {
              sum += (float)0.32226276398;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 116)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 122)) {
              sum += (float)-0.045667950064;
            } else {
              sum += (float)-0.30520510674;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 138)) {
              sum += (float)0.31563353539;
            } else {
              sum += (float)-0.080642983317;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 4)) {
        sum += (float)0.28867974877;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 94)) {
          sum += (float)0.22426770627;
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 44)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 16)) {
              sum += (float)0.0008256334113;
            } else {
              sum += (float)-0.30946159363;
            }
          } else {
            sum += (float)0.1931258142;
          }
        }
      }
    } else {
      sum += (float)0.30891937017;
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 4)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 112)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 68)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 30)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 52)) {
              sum += (float)-0.21020941436;
            } else {
              sum += (float)0.21870595217;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 32)) {
              sum += (float)-0.095842815936;
            } else {
              sum += (float)-0.26529347897;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 112)) {
            sum += (float)0.78221541643;
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 58)) {
              sum += (float)-0.19325070083;
            } else {
              sum += (float)0.071421787143;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 58)) {
          sum += (float)0.20508542657;
        } else {
          sum += (float)-0.3093854785;
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
        if (!(data[6].missing != -1) || (data[6].qvalue < 60)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 54)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 22)) {
              sum += (float)0.3525775969;
            } else {
              sum += (float)-0.049838263541;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 80)) {
              sum += (float)-0.049699213356;
            } else {
              sum += (float)-0.23548349738;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 98)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 60)) {
              sum += (float)-0.14331266284;
            } else {
              sum += (float)0.17549812794;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 110)) {
              sum += (float)-0.071347974241;
            } else {
              sum += (float)-0.29292330146;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 118)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 60)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 64)) {
              sum += (float)0.25107294321;
            } else {
              sum += (float)-0.10476300865;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 122)) {
              sum += (float)0.30542868376;
            } else {
              sum += (float)-0.094195537269;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 84)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 34)) {
              sum += (float)0.16048948467;
            } else {
              sum += (float)-0.25496336818;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 10)) {
              sum += (float)0.0027411193587;
            } else {
              sum += (float)0.24095854163;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 16)) {
      sum += (float)0.30363321304;
    } else {
      if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 52)) {
          if (!(data[2].missing != -1) || (data[2].qvalue < 48)) {
            sum += (float)0.027671372518;
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 24)) {
              sum += (float)-0.049039047211;
            } else {
              sum += (float)-0.3554751277;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 14)) {
            sum += (float)-0.016867080703;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 0)) {
              sum += (float)0.061054613441;
            } else {
              sum += (float)0.22941499949;
            }
          }
        }
      } else {
        sum += (float)0.27641823888;
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 8)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
          sum += (float)0.39970698953;
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 80)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 6)) {
              sum += (float)0.048873912543;
            } else {
              sum += (float)0.2554101944;
            }
          } else {
            sum += (float)-0.21077641845;
          }
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 114)) {
          if (!(data[0].missing != -1) || (data[0].qvalue < 126)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 68)) {
              sum += (float)-0.24360652268;
            } else {
              sum += (float)-0.10942783207;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 62)) {
              sum += (float)-0.018625715747;
            } else {
              sum += (float)-0.3078443408;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 130)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 124)) {
              sum += (float)0.66382014751;
            } else {
              sum += (float)-0.038098074496;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 22)) {
              sum += (float)-0.24008768797;
            } else {
              sum += (float)0.20156750083;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 116)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 62)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 48)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 10)) {
              sum += (float)0.21150615811;
            } else {
              sum += (float)-0.22297854722;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 132)) {
              sum += (float)0.186782673;
            } else {
              sum += (float)-0.078513801098;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 98)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 26)) {
              sum += (float)-0.014122803695;
            } else {
              sum += (float)0.33645063639;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 56)) {
              sum += (float)-0.18249613047;
            } else {
              sum += (float)0.097709439695;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 18)) {
          sum += (float)0.14588607848;
        } else {
          sum += (float)-0.29090389609;
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
    if (!(data[2].missing != -1) || (data[2].qvalue < 52)) {
      if (!(data[9].missing != -1) || (data[9].qvalue < 20)) {
        sum += (float)0.30411198735;
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 2)) {
          sum += (float)0.19125239551;
        } else {
          sum += (float)0.0042814542539;
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 18)) {
        sum += (float)0.26139575243;
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 10)) {
          sum += (float)0.042912691832;
        } else {
          sum += (float)-0.23901955783;
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 2)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 100)) {
        if (!(data[7].missing != -1) || (data[7].qvalue < 28)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 22)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 30)) {
              sum += (float)-0.24301047623;
            } else {
              sum += (float)0.14664202929;
            }
          } else {
            sum += (float)0.39607080817;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 78)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 130)) {
              sum += (float)0.023380838335;
            } else {
              sum += (float)-0.23100231588;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 132)) {
              sum += (float)0.25090518594;
            } else {
              sum += (float)-0.098614193499;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
          sum += (float)0.21422979236;
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 2)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 78)) {
              sum += (float)0.35494467616;
            } else {
              sum += (float)-0.2504234314;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 66)) {
              sum += (float)-0.28379136324;
            } else {
              sum += (float)-0.17290860415;
            }
          }
        }
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 4)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 176)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 6)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 20)) {
              sum += (float)0.3188958168;
            } else {
              sum += (float)-0.23036231101;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 116)) {
              sum += (float)0.43574377894;
            } else {
              sum += (float)-0.015117964707;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].qvalue < 64)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 0)) {
              sum += (float)-0.058718089014;
            } else {
              sum += (float)0.50448846817;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 94)) {
              sum += (float)-0.28537124395;
            } else {
              sum += (float)-0.03692593053;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 14)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 186)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 158)) {
              sum += (float)-0.24022035301;
            } else {
              sum += (float)0.12424580008;
            }
          } else {
            sum += (float)0.23808695376;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 116)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 32)) {
              sum += (float)0.2633356154;
            } else {
              sum += (float)-0.019376635551;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 28)) {
              sum += (float)0.053205050528;
            } else {
              sum += (float)-0.26970395446;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
      sum += (float)0.30102154613;
    } else {
      if (!(data[2].missing != -1) || (data[2].qvalue < 44)) {
        sum += (float)0.26522454619;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 40)) {
          sum += (float)-0.29365241528;
        } else {
          sum += (float)0.094522915781;
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 116)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 60)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 70)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 72)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 40)) {
              sum += (float)0.23075181246;
            } else {
              sum += (float)0.0089961672202;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].qvalue < 26)) {
              sum += (float)0.17629265785;
            } else {
              sum += (float)-0.19553433359;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 88)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 72)) {
              sum += (float)-0.16144667566;
            } else {
              sum += (float)0.1742246151;
            }
          } else {
            if (!(data[9].missing != -1) || (data[9].qvalue < 2)) {
              sum += (float)0.068901903927;
            } else {
              sum += (float)-0.25204569101;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 84)) {
          if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 50)) {
              sum += (float)0.78633701801;
            } else {
              sum += (float)0.071653530002;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 66)) {
              sum += (float)0.023132428527;
            } else {
              sum += (float)0.36268272996;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 82)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 94)) {
              sum += (float)-0.015495426953;
            } else {
              sum += (float)-0.26652598381;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 104)) {
              sum += (float)0.52568632364;
            } else {
              sum += (float)-0.032253857702;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 52)) {
        sum += (float)0.2558952868;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 2)) {
          sum += (float)0.067685544491;
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 90)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 58)) {
              sum += (float)-0.21901530027;
            } else {
              sum += (float)0.13189525902;
            }
          } else {
            sum += (float)-0.2956238091;
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
    if (!(data[0].missing != -1) || (data[0].qvalue < 126)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 72)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 164)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 68)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 70)) {
              sum += (float)0.075711734593;
            } else {
              sum += (float)-0.13273772597;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 98)) {
              sum += (float)0.38541594148;
            } else {
              sum += (float)-0.095772497356;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 18)) {
            sum += (float)0.32102072239;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 112)) {
              sum += (float)-0.27476131916;
            } else {
              sum += (float)-0.073508642614;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 178)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 66)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 142)) {
              sum += (float)0.16894891858;
            } else {
              sum += (float)-0.1216820702;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 102)) {
              sum += (float)0.65490943193;
            } else {
              sum += (float)0.20637269318;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 98)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 96)) {
              sum += (float)-0.30193442106;
            } else {
              sum += (float)-0.0099609680474;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 126)) {
              sum += (float)0.34466466308;
            } else {
              sum += (float)-0.065631978214;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 92)) {
        sum += (float)-0.0065892222337;
      } else {
        sum += (float)-0.29018494487;
      }
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].qvalue < 56)) {
      if (!(data[2].missing != -1) || (data[2].qvalue < 74)) {
        sum += (float)0.29811242223;
      } else {
        sum += (float)-0.010540395975;
      }
    } else {
      if (!(data[9].missing != -1) || (data[9].qvalue < 6)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 168)) {
          sum += (float)0.32637512684;
        } else {
          sum += (float)0.055361717939;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 20)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 130)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 34)) {
              sum += (float)0.023738706484;
            } else {
              sum += (float)0.31880366802;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 74)) {
              sum += (float)-0.24359987676;
            } else {
              sum += (float)0.25254309177;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].qvalue < 70)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 58)) {
              sum += (float)-0.21058136225;
            } else {
              sum += (float)-0.047152023762;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 122)) {
              sum += (float)0.19921310246;
            } else {
              sum += (float)-0.08094047755;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 22)) {
    if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
      sum += (float)0.29608270526;
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 136)) {
        sum += (float)0.24892967939;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 38)) {
          sum += (float)-0.27677026391;
        } else {
          sum += (float)0.077835820615;
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].qvalue < 0)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 60)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 146)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 16)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 38)) {
              sum += (float)0.013866465539;
            } else {
              sum += (float)-0.17304396629;
            }
          } else {
            sum += (float)0.56247323751;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 78)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 0)) {
              sum += (float)-0.0092599326745;
            } else {
              sum += (float)-0.27275705338;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 88)) {
              sum += (float)0.30343872309;
            } else {
              sum += (float)-0.13785642385;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 8)) {
          sum += (float)0.31631654501;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 90)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 0)) {
              sum += (float)-0.034261818975;
            } else {
              sum += (float)-0.25202837586;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 118)) {
              sum += (float)0.35207727551;
            } else {
              sum += (float)-0.11817645282;
            }
          }
        }
      }
    } else {
      if (!(data[8].missing != -1) || (data[8].qvalue < 108)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 106)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 80)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 102)) {
              sum += (float)0.030949173495;
            } else {
              sum += (float)-0.10754032433;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 76)) {
              sum += (float)0.076184786856;
            } else {
              sum += (float)0.42405164242;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 104)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 2)) {
              sum += (float)0.11041425914;
            } else {
              sum += (float)-0.28152143955;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 124)) {
              sum += (float)0.1404042542;
            } else {
              sum += (float)-0.26521268487;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 82)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 128)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 94)) {
              sum += (float)0.39000293612;
            } else {
              sum += (float)0.00054990558419;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 120)) {
              sum += (float)-0.24127620459;
            } else {
              sum += (float)0.088887378573;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 188)) {
            sum += (float)0.61819005013;
          } else {
            sum += (float)0.091997027397;
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
    sum += (float)0.29294198751;
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 126)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 12)) {
        if (!(data[5].missing != -1) || (data[5].qvalue < 86)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 68)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 40)) {
              sum += (float)0.011711582541;
            } else {
              sum += (float)0.35225445032;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 8)) {
              sum += (float)0.19199074805;
            } else {
              sum += (float)-0.12359566242;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 56)) {
              sum += (float)-0.31858682632;
            } else {
              sum += (float)-0.14619092643;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 118)) {
              sum += (float)0.14202569425;
            } else {
              sum += (float)-0.17608557642;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 64)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 124)) {
              sum += (float)0.0087854359299;
            } else {
              sum += (float)-0.15442807972;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 180)) {
              sum += (float)0.14199230075;
            } else {
              sum += (float)-0.037044648081;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 154)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 22)) {
              sum += (float)0.31852668524;
            } else {
              sum += (float)0.11749178171;
            }
          } else {
            sum += (float)-0.17232584953;
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].qvalue < 92)) {
        if (!(data[8].missing != -1) || (data[8].qvalue < 14)) {
          sum += (float)-0.17457589507;
        } else {
          sum += (float)0.18613195419;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 6)) {
          sum += (float)-0.010734041221;
        } else {
          sum += (float)-0.28348827362;
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
    sum += (float)0.28931537271;
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 128)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 104)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 70)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 4)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 78)) {
              sum += (float)-0.048040501773;
            } else {
              sum += (float)0.35621824861;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 34)) {
              sum += (float)0.13225898147;
            } else {
              sum += (float)0.44965049624;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].qvalue < 32)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 12)) {
              sum += (float)-0.035707056522;
            } else {
              sum += (float)0.17420139909;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 42)) {
              sum += (float)-0.11099407077;
            } else {
              sum += (float)0.025623101741;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].qvalue < 50)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 38)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 28)) {
              sum += (float)-0.1398383081;
            } else {
              sum += (float)0.80112785101;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
              sum += (float)-0.25939536095;
            } else {
              sum += (float)-0.026498444378;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].qvalue < 100)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 36)) {
              sum += (float)0.013132282533;
            } else {
              sum += (float)0.44682317972;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 90)) {
              sum += (float)0.014197352342;
            } else {
              sum += (float)-0.20531220734;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 24)) {
        sum += (float)-0.033644556999;
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 130)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 64)) {
            sum += (float)-0.16952183843;
          } else {
            sum += (float)-0.0025323000737;
          }
        } else {
          sum += (float)-0.28775566816;
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
    sum += (float)0.28497421741;
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 130)) {
      if (!(data[5].missing != -1) || (data[5].qvalue < 134)) {
        if (!(data[4].missing != -1) || (data[4].qvalue < 150)) {
          if (!(data[8].missing != -1) || (data[8].qvalue < 50)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 32)) {
              sum += (float)0.12797689438;
            } else {
              sum += (float)-0.064219176769;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 72)) {
              sum += (float)0.42960596085;
            } else {
              sum += (float)0.08034016192;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 100)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 108)) {
              sum += (float)-0.06911739707;
            } else {
              sum += (float)-0.28159457445;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].qvalue < 184)) {
              sum += (float)0.20875844359;
            } else {
              sum += (float)-0.0076091340743;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 66)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 30)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 20)) {
              sum += (float)0.14835783839;
            } else {
              sum += (float)-0.20921243727;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 48)) {
              sum += (float)0.51127576828;
            } else {
              sum += (float)-0.0023101619445;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 28)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 64)) {
              sum += (float)-0.096802614629;
            } else {
              sum += (float)0.38023418188;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 162)) {
              sum += (float)-0.23916092515;
            } else {
              sum += (float)0.10001607984;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].qvalue < 44)) {
        sum += (float)-0.071823850274;
      } else {
        sum += (float)-0.28080880642;
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 30)) {
    if (!(data[1].missing != -1) || (data[1].qvalue < 12)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 6)) {
        sum += (float)-0.24476034939;
      } else {
        if (!(data[2].missing != -1) || (data[2].qvalue < 70)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 44)) {
            sum += (float)0.215222314;
          } else {
            sum += (float)0.042731456459;
          }
        } else {
          sum += (float)-0.024612804875;
        }
      }
    } else {
      sum += (float)0.28258797526;
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 116)) {
      if (!(data[8].missing != -1) || (data[8].qvalue < 28)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 80)) {
          if (!(data[7].missing != -1) || (data[7].qvalue < 36)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 50)) {
              sum += (float)-0.074235625565;
            } else {
              sum += (float)0.20939932764;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 12)) {
              sum += (float)0.059353824705;
            } else {
              sum += (float)-0.19219599664;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 30)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 20)) {
              sum += (float)0.05365947634;
            } else {
              sum += (float)0.58103942871;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 12)) {
              sum += (float)-0.25639545918;
            } else {
              sum += (float)0.12913417816;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 80)) {
          if (!(data[6].missing != -1) || (data[6].qvalue < 50)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 70)) {
              sum += (float)0.20475694537;
            } else {
              sum += (float)-0.11277514696;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 142)) {
              sum += (float)0.23474681377;
            } else {
              sum += (float)0.60783392191;
            }
          }
        } else {
          if (!(data[8].missing != -1) || (data[8].qvalue < 72)) {
            if (!(data[0].missing != -1) || (data[0].qvalue < 32)) {
              sum += (float)0.0049430746585;
            } else {
              sum += (float)-0.25655084848;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 100)) {
              sum += (float)0.26082193851;
            } else {
              sum += (float)-0.017296073958;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 56)) {
        sum += (float)0.11557092518;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 90)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 154)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 54)) {
              sum += (float)-0.076740309596;
            } else {
              sum += (float)0.41116610169;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 22)) {
              sum += (float)-0.031974762678;
            } else {
              sum += (float)-0.23959971964;
            }
          }
        } else {
          sum += (float)-0.2897952795;
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 50)) {
    if (!(data[5].missing != -1) || (data[5].qvalue < 106)) {
      if (!(data[0].missing != -1) || (data[0].qvalue < 54)) {
        if (!(data[0].missing != -1) || (data[0].qvalue < 46)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 82)) {
            sum += (float)0.27667954564;
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 10)) {
              sum += (float)-0.14560075104;
            } else {
              sum += (float)0.19168624282;
            }
          }
        } else {
          sum += (float)-0.13095843792;
        }
      } else {
        sum += (float)0.29458022118;
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 14)) {
        if (!(data[2].missing != -1) || (data[2].qvalue < 88)) {
          sum += (float)0.30447900295;
        } else {
          sum += (float)-0.065586313605;
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 2)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 152)) {
            if (!(data[3].missing != -1) || (data[3].qvalue < 22)) {
              sum += (float)-0.081696853042;
            } else {
              sum += (float)-0.29410466552;
            }
          } else {
            sum += (float)-0.070116437972;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 42)) {
            sum += (float)0.28934678435;
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 18)) {
              sum += (float)-0.2447912246;
            } else {
              sum += (float)0.22815841436;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].qvalue < 102)) {
      if (!(data[7].missing != -1) || (data[7].qvalue < 74)) {
        if (!(data[9].missing != -1) || (data[9].qvalue < 8)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 98)) {
            if (!(data[5].missing != -1) || (data[5].qvalue < 84)) {
              sum += (float)0.10541111976;
            } else {
              sum += (float)0.63550955057;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)-0.2490580827;
            } else {
              sum += (float)0.078463375568;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 96)) {
            if (!(data[8].missing != -1) || (data[8].qvalue < 64)) {
              sum += (float)-0.078013688326;
            } else {
              sum += (float)0.19889070094;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 86)) {
              sum += (float)-0.23813821375;
            } else {
              sum += (float)-0.065434582531;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].qvalue < 56)) {
          if (!(data[4].missing != -1) || (data[4].qvalue < 190)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 76)) {
              sum += (float)0.16194416583;
            } else {
              sum += (float)-0.13856334984;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].qvalue < 16)) {
              sum += (float)0.51498353481;
            } else {
              sum += (float)-0.023029318079;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 70)) {
            if (!(data[1].missing != -1) || (data[1].qvalue < 8)) {
              sum += (float)-0.25310629606;
            } else {
              sum += (float)0.093508183956;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].qvalue < 136)) {
              sum += (float)0.35252213478;
            } else {
              sum += (float)-0.039238583297;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 36)) {
        sum += (float)0.25857424736;
      } else {
        if (!(data[5].missing != -1) || (data[5].qvalue < 14)) {
          sum += (float)0.088602080941;
        } else {
          if (!(data[6].missing != -1) || (data[6].qvalue < 80)) {
            if (!(data[4].missing != -1) || (data[4].qvalue < 90)) {
              sum += (float)-0.10747198015;
            } else {
              sum += (float)-0.29061064124;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 86)) {
              sum += (float)0.21265433729;
            } else {
              sum += (float)-0.19299955666;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].qvalue < 78)) {
    if (!(data[7].missing != -1) || (data[7].qvalue < 52)) {
      if (!(data[4].missing != -1) || (data[4].qvalue < 6)) {
        sum += (float)0.26647916436;
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 6)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 12)) {
            if (!(data[6].missing != -1) || (data[6].qvalue < 4)) {
              sum += (float)-0.11021758616;
            } else {
              sum += (float)0.32990819216;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].qvalue < 52)) {
              sum += (float)0.24568548799;
            } else {
              sum += (float)-0.17356690764;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 46)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 42)) {
              sum += (float)0.11046616733;
            } else {
              sum += (float)0.50671231747;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 32)) {
              sum += (float)-0.089187085629;
            } else {
              sum += (float)0.22726753354;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].qvalue < 68)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 64)) {
          sum += (float)-0.091628059745;
        } else {
          sum += (float)0.20489756763;
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].qvalue < 66)) {
          sum += (float)0.52349001169;
        } else {
          sum += (float)0.11346493661;
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].qvalue < 58)) {
      if (!(data[6].missing != -1) || (data[6].qvalue < 16)) {
        if (!(data[3].missing != -1) || (data[3].qvalue < 52)) {
          sum += (float)-0.15224349499;
        } else {
          if (!(data[7].missing != -1) || (data[7].qvalue < 48)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 14)) {
              sum += (float)0.08681089431;
            } else {
              sum += (float)0.59785723686;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].qvalue < 8)) {
              sum += (float)0.27552393079;
            } else {
              sum += (float)-0.15993258357;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].qvalue < 156)) {
          if (!(data[5].missing != -1) || (data[5].qvalue < 50)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 40)) {
              sum += (float)-0.030568325892;
            } else {
              sum += (float)0.23894304037;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 44)) {
              sum += (float)-0.17419070005;
            } else {
              sum += (float)-0.013866762631;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].qvalue < 14)) {
            if (!(data[7].missing != -1) || (data[7].qvalue < 82)) {
              sum += (float)-0.23559659719;
            } else {
              sum += (float)0.068177223206;
            }
          } else {
            sum += (float)0.086535707116;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].qvalue < 82)) {
        if (!(data[1].missing != -1) || (data[1].qvalue < 16)) {
          sum += (float)0.36059626937;
        } else {
          sum += (float)0.021878894418;
        }
      } else {
        if (!(data[8].missing != -1) || (data[8].qvalue < 76)) {
          if (!(data[3].missing != -1) || (data[3].qvalue < 92)) {
            if (!(data[2].missing != -1) || (data[2].qvalue < 26)) {
              sum += (float)0.3018873632;
            } else {
              sum += (float)-0.12123091519;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].qvalue < 92)) {
              sum += (float)-0.31065511703;
            } else {
              sum += (float)-0.040255930275;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].qvalue < 110)) {
            if (!(data[9].missing != -1) || (data[9].qvalue < 16)) {
              sum += (float)0.022760137916;
            } else {
              sum += (float)0.37880295515;
            }
          } else {
            if (!(data[8].missing != -1) || (data[8].qvalue < 96)) {
              sum += (float)-0.24670137465;
            } else {
              sum += (float)0.048373673111;
            }
          }
        }
      }
    }
  }

  sum = sum + (float)(-0);
  if (!pred_margin) {
    return pred_transform(sum);
  } else {
    return sum;
  }
}
